"""Per-position counts from a BAM with pysam only: an alternative to `bam-readcount -q 20 -b 20 -w 0` (step 2).

Why it exists: `samtools` and `bam-readcount` cannot run inside a web browser, while pysam (htslib) is available in Pyodide.
This module lets Browser Mode accept BAM files. It is NOT used by `srasel run`, which still counts with bam-readcount.

What it reproduces (the rules were derived with tests/regression/test_counts_oracle.py, the edge-case battery
tests/regression/test_bamcount_edge.py and real BAMs, see docs/BAM_COUNTER.md):
  * reads with flag 0x4, 0x100, 0x200 or 0x400 never enter the pileup (not counted, positions not printed, no buffer node);
    reads with MAPQ < min_mapq are not counted (supplementary 0x800 is NOT skipped);
  * a base counts only if its base quality >= min_baseq; no overlap correction, no orphan filtering; strand = read strand;
    a read without stored qualities (QUAL '*', 0xFF in the BAM) counts as quality 255; a '=' in SEQ goes to the '=' entry;
  * an insertion is reported at the anchor base (`+SEQ`), a deletion at the first deleted reference position (`-SEQ`);
    a deleted read adds to the depth there; both need the anchor base to pass the base-quality filter; `M P I` is an insertion;
  * positions covered only by reads that fail the filters, by the inner part of a deletion or by an `N` (reference skip) are printed
    with depth 0;
  * means are printed as single-precision floats with two decimals, like bam-readcount.
The BAM must be coordinate-sorted (ValueError otherwise; `srasel run` sorts it first, and the buffer rule below depends on that order).

Output: one line per covered position, in bam-readcount's layout. SRASel's step 3-5 only read the reference base, the depth,
the per-base counts and the indel counts (`engine.parse_readcount_line`); the columns that bam-readcount fills with other
statistics (avg_se_mapping_quality and avg_num_mismatches_as_fraction are the ones bam-readcount 1.0.1 really fills; position-in-read,
q2 and clipping columns are 0.00 in its output too) are written as 0.00 here, so this file is NOT a byte-for-byte copy of
bam-readcount's output.

Needs numpy and pysam. `count_bam()` takes the reference sequences as {contig: str} (case as in the FASTA).
"""
from __future__ import annotations

import heapq
import struct
from pathlib import Path

import numpy as np

SKIP_FLAGS = 0x4 | 0x100 | 0x200 | 0x400        # unmapped, secondary, QC-fail, duplicate (bam-readcount also skips these)
MAX_BUFFER = 8000                                # maxcnt of the samtools 0.1.x pileup buffer used by bam-readcount
BASES = "ACGTN="                                 # index 5: '=' in SEQ (bam-readcount reports it in its own '=' entry)
_ZERO_TAIL = "0.00:0.00:0.00:0:0.00:0.00:0.00"   # columns 8-14 of a bam-readcount entry (not used by SRASel)
_ZERO_ENTRY = f"0:0.00:0.00:0.00:0:0:{_ZERO_TAIL}"

# ASCII code of the read base -> index in BASES (anything that is not A/C/G/T/=, including IUPAC codes, goes to N)
_CODE = np.full(256, 4, dtype=np.int8)
for _i, _b in enumerate("ACGT"):
    _CODE[ord(_b)] = _i
    _CODE[ord(_b.lower())] = _i
_CODE[ord("=")] = 5


def _f2(total: int, n: int) -> str:
    """bam-readcount prints the mean as a single-precision float with two decimals (a double gives 58.98 where it prints 58.97)."""
    return f"{struct.unpack('f', struct.pack('f', total / n))[0]:.2f}"


class _Contig:
    def __init__(self, length: int):
        self.plus = np.zeros((len(BASES), length), dtype=np.int64)
        self.minus = np.zeros((len(BASES), length), dtype=np.int64)
        self.sum_mq = np.zeros((len(BASES), length), dtype=np.int64)
        self.sum_bq = np.zeros((len(BASES), length), dtype=np.int64)
        self.touched = np.zeros(length, dtype=bool)          # some accepted read has an aligned base here (even if Q < min_baseq)
        self.ins = {}                                          # (pos0, seq) -> [n, plus, minus, sum_mq]
        self.dele = {}


def _add_indel(table, key, minus, mq):
    e = table.get(key)
    if e is None:
        e = table[key] = [0, 0, 0, 0]
    e[0] += 1
    e[2 if minus else 1] += 1
    e[3] += mq


def resolve_contig(chrom, refs, alias=None):
    """Contig of `refs` ({contig: sequence}) that a BAM contig name stands for, by the first rules of `srasel run` (engine.resolve_contig):
    the user's alias BAM=REF, the exact name, then the same name without version (NC_045512 = NC_045512.2) when exactly one contig fits.
    None if nothing fits (match_header then tries the length rule of engine.match_contigs)."""
    t = (alias or {}).get(chrom, chrom)
    if t in refs:
        return t
    cand = [c for c in refs if c.split(".")[0] == t.split(".")[0]]
    return cand[0] if len(cand) == 1 else None


def match_header(bam_path, refs, alias=None):
    """Pair the contigs of the BAM header with the reference: {name in BAM: contig of refs}.
    Same rule as `srasel run` (engine.match_contigs): --alias BAM=REF, the exact name, the name without version, or (when it is the only
    contig of that length on both sides) the same length with another name. Raises ValueError, with what to do, when the BAM was not
    aligned to this reference (same checks, in short, as `srasel run` makes with samtools)."""
    import pysam
    from collections import Counter
    alias = dict(alias or {})
    try:
        with pysam.AlignmentFile(str(bam_path), "rb", check_sq=False) as bam:
            sq = list(zip(bam.references, bam.lengths))
    except OSError as e:
        raise _damaged(bam_path, e) from e
    if not sq:
        raise ValueError(f"{Path(str(bam_path)).name} has no @SQ header lines, so it is not an aligned BAM. "
                         "What to do: align the reads to the reference first (the BAM must be coordinate-sorted and aligned).")
    res = {name: resolve_contig(name, refs, alias) for name, length in sq}
    ref_lens = Counter(len(s) for s in refs.values())
    sq_lens = Counter(length for _, length in sq)
    for name, length in sq:
        if res[name] is None:
            cand = [c for c, s in refs.items() if len(s) == length]
            if len(cand) == 1 and ref_lens[length] == 1 and sq_lens[length] == 1:
                res[name] = cand[0]
    out = {}
    for name, length in sq:
        c = res[name]
        if c is None:
            names = list(refs)           # all of them (up to 12): with a segmented virus the user must see whether every segment was loaded
            shown = ", ".join(names[:12]) + (f", … ({len(names)} in total)" if len(names) > 12 else "")
            raise ValueError(f"The contig '{name}' of {Path(str(bam_path)).name} is not in the reference (reference contigs, {len(names)}: "
                             f"{shown}). What to do: load the reference the reads were aligned to. If they were aligned to your own "
                             "consensus, load the annotated GenBank of that consensus (for example reference/references.gb, written by "
                             "`srasel run --consensus`), not the GenBank of a related genome: its contigs have other names. If only the name "
                             "of the contig differs, give it as an alias: BAM_NAME=REFERENCE_NAME.")
        if len(refs[c]) != length:
            raise ValueError(f"Contig {name} is {length} bp in {Path(str(bam_path)).name} but {len(refs[c])} bp in the reference. "
                             "What to do: use the reference you aligned to (the positions would not match otherwise).")
        out[name] = c
    return out


def count_bam(bam_path, refs, min_mapq: int = 20, min_baseq: int = 20, progress=None, contig_map=None):
    """Count a BAM. refs = {contig: sequence}. Returns ({contig: _Contig}, n_reads_used).
    The BAM is read from start to end, so no .bai index is needed. contig_map = match_header() (BAM name -> contig of refs).
    A truncated or corrupt BAM raises ValueError (never a partial table: bam-readcount itself prints a partial table and exits 0)."""
    try:
        return _count_bam(bam_path, refs, min_mapq, min_baseq, progress, contig_map)
    except OSError as e:
        raise _damaged(bam_path, e) from e


def _damaged(bam_path, e):
    """OSError of htslib on an existing file -> ValueError with what to do (a missing file stays an OSError)."""
    if not Path(str(bam_path)).is_file():
        return e
    # htslib reports a damaged block at open (no EOF marker), while reading, or only when the file is closed ("Closing failed")
    return ValueError(f"{Path(str(bam_path)).name} could not be read to the end, so it is truncated or corrupt ({e}). "
                      "What to do: copy or download the BAM again (samtools quickcheck must accept it).")


def _count_bam(bam_path, refs, min_mapq, min_baseq, progress, contig_map):
    import pysam
    tallies = {c: _Contig(len(s)) for c, s in refs.items()}
    used = 0
    live, last_tid, last_pos = [], -1, -1                       # pileup buffer of the old samtools inside bam-readcount (see MAX_BUFFER)
    with pysam.AlignmentFile(str(bam_path), "rb", check_sq=False) as bam:
        names = list(bam.references)
        for i, a in enumerate(bam.fetch(until_eof=True)):
            if progress and i % 50000 == 0:
                progress(i)
            # flags 0x4/0x100/0x200/0x400 are dropped BEFORE the pileup buffer (they take no buffer node and print no position;
            # edge cases deep_dups_in_buffer / deep_secondary_in_buffer / flags of the battery)
            if a.flag & SKIP_FLAGS or a.reference_id < 0 or a.cigartuples is None:
                continue
            # bam-readcount uses the samtools/htslib pileup buffer, which drops a read when it starts at the current pileup position
            # (= the start of the previous read kept) while more than MAX_BUFFER nodes are allocated (amplicon data: thousands of reads
            # start at the same primer position). The dropped read is not counted anywhere. Reproduced so that deep positions agree.
            if a.reference_id != last_tid:
                if a.reference_id < last_tid:
                    raise ValueError(_UNSORTED.format(name=Path(str(bam_path)).name, read=a.query_name))
                live, last_tid, last_pos = [], a.reference_id, -1
            elif a.reference_start < last_pos:
                raise ValueError(_UNSORTED.format(name=Path(str(bam_path)).name, read=a.query_name))
            while live and live[0] < a.reference_start:            # nodes whose read ended before this start are already freed
                heapq.heappop(live)
            if a.reference_start == last_pos and len(live) + 1 > MAX_BUFFER:      # +1: the buffer also holds one spare node
                continue
            heapq.heappush(live, a.reference_end)
            last_pos = a.reference_start
            contig = names[a.reference_id]
            contig = contig_map.get(contig, contig) if contig_map else contig
            t = tallies.get(contig)
            if t is None:
                continue
            ct = a.cigartuples
            seq = a.query_sequence
            if a.mapping_quality < min_mapq or seq is None:
                # not counted, but bam-readcount still prints the positions such reads cover (with depth 0)
                rp = a.reference_start
                for op, n in ct:
                    if op in (0, 2, 3, 7, 8):
                        t.touched[rp:rp + n] = True
                        rp += n
                continue
            qual = a.query_qualities
            codes = _CODE[np.frombuffer(seq.encode("ascii"), dtype=np.uint8)]
            # no stored qualities (QUAL '*' = 0xFF bytes): bam-readcount reads them as 255, so the bases count (edge case no_base_qualities)
            qarr = np.full(len(seq), 255, dtype=np.uint8) if qual is None else np.asarray(qual, dtype=np.uint8)
            mq, minus = a.mapping_quality, a.is_reverse
            side = t.minus if minus else t.plus
            ref_seq = refs[contig]
            qp, rp = 0, a.reference_start
            used += 1
            for j, (op, n) in enumerate(ct):
                if op in (0, 7, 8):                                   # M, =, X
                    t.touched[rp:rp + n] = True
                    q = qarr[qp:qp + n]
                    ok = np.nonzero(q >= min_baseq)[0]
                    if ok.size:
                        b = codes[qp:qp + n][ok]
                        pos = rp + ok
                        side[b, pos] += 1
                        t.sum_mq[b, pos] += mq
                        t.sum_bq[b, pos] += q[ok]
                    ind = _indel_after(ct, j)
                    if ind and q[n - 1] >= min_baseq:
                        if ind > 0:                                    # insertion after the anchor base (last base of this block)
                            _add_indel(t.ins, (rp + n - 1, seq[qp + n:qp + n + ind]), minus, mq)
                        else:                                          # deletion: reported at the first deleted position
                            _add_indel(t.dele, (rp + n, ref_seq[rp + n:rp + n - ind]), minus, mq)
                    qp += n
                    rp += n
                elif op in (1, 4):                                     # I, S
                    qp += n
                elif op in (2, 3):                                     # D, N: positions printed (depth 0 unless other reads count there)
                    t.touched[rp:rp + n] = True
                    rp += n
    return tallies, used


_UNSORTED = ("{name} is not sorted by coordinate (read {read} is out of order). bam-readcount stops counting at that read and "
             "`srasel run` sorts the BAM first. What to do: sort it (samtools sort -o sorted.bam {name}) and load the sorted file.")


def _indel_after(ct, j):
    """Indel reported at the last base of the aligned block ct[j], as htslib's pileup (resolve_cigar2) sets `indel`:
    +len for a following I, -len for a following D, and for a following P the total length of the I operations after it
    (up to the next D/M/N/=/X). 0 = none."""
    if j + 1 >= len(ct):
        return 0
    op2, l2 = ct[j + 1]
    if op2 == 2:
        return -l2
    if op2 == 1:
        return l2
    if op2 == 6:
        tot = 0
        for op3, l3 in ct[j + 2:]:
            if op3 == 1:
                tot += l3
            elif op3 in (0, 2, 3, 7, 8):
                break
        return tot
    return 0


def _entry(label, n, plus, minus, sum_mq, sum_bq):
    if n == 0:
        return f"{label}:{_ZERO_ENTRY}"
    return f"{label}:{n}:{_f2(sum_mq, n)}:{_f2(sum_bq, n)}:0.00:{plus}:{minus}:{_ZERO_TAIL}"


def write_readcount(tallies, refs, out, order=None):
    """Write `tallies` in bam-readcount's layout. Returns the number of positions written."""
    npos = 0
    for contig in (order or list(refs)):
        t, seq = tallies.get(contig), refs[contig]
        if t is None:
            continue
        depth_b = t.plus.sum(axis=0) + t.minus.sum(axis=0)
        dele_by_pos = {}
        for (p, s), e in t.dele.items():
            dele_by_pos.setdefault(p, []).append((s, e))
        ins_by_pos = {}
        for (p, s), e in t.ins.items():
            ins_by_pos.setdefault(p, []).append((s, e))
        depth = depth_b.copy()
        for p, lst in dele_by_pos.items():
            depth[p] += sum(e[0] for _, e in lst)
        for p in np.nonzero(t.touched | (depth > 0))[0]:
            parts = [contig, str(p + 1), seq[p], str(int(depth[p]))]
            for k in (5, 0, 1, 2, 3, 4):                           # bam-readcount's order: =, A, C, G, T, N
                n = int(t.plus[k, p] + t.minus[k, p])
                parts.append(_entry(BASES[k], n, int(t.plus[k, p]), int(t.minus[k, p]), int(t.sum_mq[k, p]), int(t.sum_bq[k, p])))
            for s, e in sorted(ins_by_pos.get(int(p), [])):
                parts.append(f"+{s}:{e[0]}:{_f2(e[3], e[0])}:0.00:0.00:{e[1]}:{e[2]}:{_ZERO_TAIL}")
            for s, e in sorted(dele_by_pos.get(int(p), [])):
                parts.append(f"-{s}:{e[0]}:{_f2(e[3], e[0])}:0.00:0.00:{e[1]}:{e[2]}:{_ZERO_TAIL}")
            out.write("\t".join(parts) + "\n")
            npos += 1
    return npos


def bam_to_readcount(bam_path, refs, out_path, min_mapq: int = 20, min_baseq: int = 20, progress=None, order=None, check=True, alias=None):
    """BAM -> bam-readcount-style table at `out_path`. Returns (positions written, reads used).
    check=True first verifies that the BAM header fits the reference (ValueError otherwise); alias = {BAM contig: reference contig}."""
    cmap = match_header(bam_path, refs, alias) if check else None
    tallies, used = count_bam(bam_path, refs, min_mapq, min_baseq, progress, cmap)
    with open(out_path, "w") as fo:
        n = write_readcount(tallies, refs, fo, order)
    return n, used


def read_fasta(path):
    """{contig: sequence}; the contig name is the first word of the header (as samtools / bam-readcount see it).
    The case is kept: bam-readcount prints the reference base and the deleted bases as they are in the FASTA (a soft-masked
    `acg` stays lower case; edge case reference_case_iupac). The reference.fna that SRASel writes is upper case."""
    refs, name = {}, None
    for line in open(path):
        if line.startswith(">"):
            name = line[1:].split()[0]
            refs[name] = []
        elif name is not None:
            refs[name].append(line.strip())
    return {k: "".join(v) for k, v in refs.items()}


def main(argv=None) -> int:
    """`srasel count-bam BAM --fasta ref.fna --out table.txt`"""
    import argparse
    import sys
    ap = argparse.ArgumentParser(prog="srasel count-bam", description=(
        "Per-position counts of a BAM with pysam (no bam-readcount needed), in the layout of `bam-readcount -q 20 -b 20 -w 0`. "
        "Alternative to step 2 of `srasel run`; the same method Browser Mode uses. See docs/BAM_COUNTER.md."))
    ap.add_argument("bam", help="BAM file (an index is not needed)")
    ap.add_argument("--fasta", required=True, help="reference FASTA the reads were aligned to (contig names must match the BAM)")
    ap.add_argument("--out", required=True, help="output table (…_RG_readcount.txt)")
    ap.add_argument("--min-mapq", type=int, default=20, help="minimum mapping quality (bam-readcount -q, default 20)")
    ap.add_argument("--min-baseq", type=int, default=20, help="minimum base quality (bam-readcount -b, default 20)")
    a = ap.parse_args(argv)
    try:
        import pysam  # noqa: F401
    except ModuleNotFoundError:
        print("srasel count-bam: missing dependency 'pysam'. Install it with: pip install -e '.[pysam]' (from the repository folder)", file=sys.stderr)
        return 3
    refs = read_fasta(a.fasta)
    tmp = Path(str(a.out) + ".part")
    try:
        n, used = bam_to_readcount(a.bam, refs, tmp, a.min_mapq, a.min_baseq)
    except (ValueError, OSError) as e:                     # not a BAM, truncated/corrupt, unsorted, other reference: no table at all
        tmp.unlink(missing_ok=True)
        if isinstance(e, OSError) and not Path(a.bam).is_file():
            raise
        hint = "" if "What to do" in str(e) else ("\n  What to do: check that it is a complete, coordinate-sorted BAM aligned to this FASTA "
                                                   "(samtools quickcheck / samtools sort).")
        print(f"srasel count-bam: {a.bam} could not be counted, no table written: {e}{hint}", file=sys.stderr)
        return 2
    tmp.replace(a.out)
    print(f"{a.out}: {n} positions from {used} reads")
    return 0
