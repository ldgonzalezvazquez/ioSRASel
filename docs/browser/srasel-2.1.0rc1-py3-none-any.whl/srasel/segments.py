"""Join the files of a SEGMENTED virus into the ONE FASTA and the ONE gene list that `srasel run --fasta --genes` takes.

Why this exists: the engine (and so the command line) takes a single FASTA and a single gene list for the whole genome; the `contig`
column of the list says which segment each gene is in. The local web page and Browser Mode let a person give one FASTA / one gene
list PER SEGMENT, so they join the files here before calling the engine. Nothing is interpreted scientifically: the files are only put
one after the other, in the order given, with the checks below so that a mistake is reported with the name of the file, not as a
confusing failure later. The command line is not changed (join the files yourself with `cat`, see README, "Segmented viruses").

Pure Python (standard library only) so that it also runs inside Pyodide. `tests/unit/test_segments.py` proves that the joined files give
the same genes as reading every file on its own with the engine's `read_gene_list`.
"""
from __future__ import annotations

from typing import List, Sequence, Tuple

# the engine's own header aliases of a gene table (engine.read_gene_list); a test compares both so they cannot drift apart
_ALIAS = {"chrom": "contig", "seqid": "contig", "name": "gene", "from": "start", "to": "end", "stop": "end"}
_REQUIRED = ("contig", "gene", "start", "end", "strand")


class SegmentError(ValueError):
    """A problem with the files given for the segments; the message says which file and what to do."""


def _lines(text: str) -> List[str]:
    return text.replace("\r\n", "\n").replace("\r", "\n").lstrip("﻿").split("\n")


def merge_fastas(files: Sequence[Tuple[str, str]]) -> str:
    """``files`` = [(file name, text)], in the order of the segments. Returns one FASTA with every record, in that order."""
    if not files:
        raise SegmentError("No FASTA file was given.")
    out: List[str] = []
    seen = {}                                                       # sequence name -> file where it was first seen
    for name, text in files:
        n_rec = 0
        for ln in _lines(text):
            if ln.startswith(">"):
                seq_name = ln[1:].split()[0] if ln[1:].split() else ""
                if not seq_name:
                    raise SegmentError(f"{name}: a sequence has no name (a line with only “>”). Give every sequence a name, the same one your BAMs use.")
                if seq_name in seen:
                    where = "the same file" if seen[seq_name] == name else seen[seq_name]
                    raise SegmentError(f"The sequence name “{seq_name}” appears twice ({where} and {name}). "
                                       "Each segment needs its own name; the same segment must not be given twice.")
                seen[seq_name] = name
                n_rec += 1
            if ln.strip():
                out.append(ln.rstrip())
        if n_rec == 0:
            raise SegmentError(f"{name} contains no FASTA sequence (no line starting with “>”).")
    return "\n".join(out) + "\n"


def _is_gff(name: str, text: str) -> bool:
    return name.lower().endswith((".gff", ".gff3")) or text.lstrip().startswith("##gff")      # as engine.read_gene_list


def merge_gene_lists(files: Sequence[Tuple[str, str]]) -> Tuple[str, str]:
    """``files`` = [(file name, text)]. Returns (text, "tsv" or "gff3"): one gene list that holds the genes of every file.

    Tables (tab-separated, with a header): the columns are joined by NAME, so the files do not need the same columns or order
    (a column that a file lacks is left empty for its rows, which the engine reads as "default"). GFF3 files are put one after the other.
    A table and a GFF3 cannot be mixed."""
    if not files:
        raise SegmentError("No gene list was given.")
    gff = [_is_gff(n, t) for n, t in files]
    if any(gff) and not all(gff):
        raise SegmentError("The gene lists mix a GFF3 file and a table. Give all of them in the same format.")
    if all(gff):
        out: List[str] = []
        for _, text in files:
            for ln in _lines(text):
                if not ln.strip():
                    continue
                if ln.startswith("##gff-version") and any(x.startswith("##gff-version") for x in out):
                    continue                                        # one version line is enough
                out.append(ln.rstrip("\n"))
        return "\n".join(out) + "\n", "gff3"

    cols: List[str] = []
    rows: List[dict] = []
    for name, text in files:
        lines = [x for x in _lines(text) if x.strip() and not x.lstrip().startswith("#")]      # as engine.read_gene_list
        if not lines:
            raise SegmentError(f"{name} is empty: it has no header and no genes.")
        head = [_ALIAS.get(h.strip().lower(), h.strip().lower()) for h in lines[0].split("\t")]
        miss = [c for c in _REQUIRED if c not in head]
        if miss:
            raise SegmentError(f"The gene list {name} is missing the column(s): {', '.join(miss)} (header found: {', '.join(head)}). "
                               "Use the header: contig, gene, start, end, strand (optional: type, product, codon_start, transl_table), separated by tabs.")
        if len(lines) == 1:
            raise SegmentError(f"The gene list {name} has a header but no gene rows.")
        for c in head:
            if c not in cols:
                cols.append(c)
        for ln in lines[1:]:
            rows.append(dict(zip(head, [x.strip() for x in ln.split("\t")])))
    ordered = [c for c in _REQUIRED if c in cols] + [c for c in cols if c not in _REQUIRED]
    out = ["\t".join(ordered)] + ["\t".join(r.get(c, "") for c in ordered) for r in rows]
    return "\n".join(out) + "\n", "tsv"
