#!/usr/bin/env python3
"""
srasel.py · SRASel 2.0 in a SINGLE file (consolidation of the original scripts without changing their logic)

    srasel run                 ...   full pipeline from BAM (formerly srasel_run.py)
    srasel prepare-reference   ...   step 0   (formerly prepare_reference.py)
    srasel transfer-annotation ...   step 0b  (formerly transfer_annotation.py)
    srasel integrity           ...   step 3   (formerly integrity_control.py)
    srasel build-tables        ...   step 4   (formerly built_time_mutation_tsv.py)
    srasel annotate            ...   step 5   (formerly annotate_patient_tables.py)
    srasel selection           ...   step 6   (formerly SRASel.py)
    srasel report              ...   step 7   (formerly srasel_report.py)

Each subcommand keeps the arguments and help (`-h`) of the original script. Steps 1-2 (align and count) use samtools and bam-readcount.
External dependencies: Biopython, numpy, pandas, scipy, joblib, matplotlib, tqdm; samtools, bam-readcount and minimap2 on the PATH.
"""
from __future__ import annotations

import os
os.environ.setdefault("MKL_VERBOSE", "NO")
from collections import Counter
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from dataclasses import field
from datetime import date
from datetime import datetime
from datetime import timedelta
from pathlib import Path
from typing import Dict
from typing import List
from typing import NoReturn
from typing import Optional
from typing import Tuple
import argparse
import csv
import datetime as dt
import collections
import hashlib
import itertools
import json
import math
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
import warnings
import zlib

from Bio import Align
from Bio import Entrez
from Bio import SeqIO
from Bio.Align import substitution_matrices
from Bio.Data import CodonTable
from Bio.Data import IUPACData
from Bio.Seq import Seq
from Bio.SeqFeature import CompoundLocation
from Bio.SeqFeature import FeatureLocation
from Bio.SeqFeature import SeqFeature
from Bio.SeqRecord import SeqRecord
from joblib import Parallel
from joblib import delayed
from scipy.ndimage import gaussian_filter1d
from tqdm.auto import tqdm
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

if __name__ != "__main__":
    # With `python srasel.py`, joblib/loky sends the functions of __main__ BY VALUE, with the globals PERM_SEED and ZERO_FILL
    # already set. When this file is imported as a module (package, `python -m srasel`) it would send them by reference and the
    # parallel workers would see PERM_SEED=None and ZERO_FILL=True, silently ignoring --seed and --legacy-no-zero-fill.
    try:
        import cloudpickle as _cloudpickle                       # the one loky uses when installed (joblib >= 1.5)
    except ImportError:
        from joblib.externals import cloudpickle as _cloudpickle  # older joblib: its own copy
    _cloudpickle.register_pickle_by_value(sys.modules[__name__])


# ════════════════════════════════════════════════════════════════════════════════════════════════════
# Common genomics functions (reading model, CDS, GenBank)
# ════════════════════════════════════════════════════════════════════════════════════════════════════
#!/usr/bin/env python3



CONTIG_GAP = 2000                      # empty positions between contigs
ACC_RE = re.compile(r"^[A-Za-z]{1,6}_?\d+(\.\d+)?$")
COMP = {"A": "T", "C": "G", "G": "C", "T": "A", "N": "N"}

# ───────────────────────── messages ─────────────────────────────────────────
def disclaimer(msg: str) -> None:
    """Warning that does NOT stop the program but that the user must read."""
    print(f"[WARNING] {msg}", file=sys.stderr)


def fail(what: str, why: str, fix: str = "") -> "NoReturn":
    """Error that DOES stop the program, always with the reason."""
    msg = f"\n[ERROR] {what}\n  Because: {why}"
    if fix:
        msg += f"\n  What to do: {fix}"
    print(msg + "\n", file=sys.stderr)
    raise SystemExit(2)


# ───────────────────────── genetic codes ────────────────────────────────
_TABLES: Dict[int, Dict[str, str]] = {}


def codon_table(table_id: int = 1) -> Dict[str, str]:
    """{DNA codon → aa (1 letter, '*' = stop)} for an NCBI /transl_table."""
    if table_id not in _TABLES:
        try:
            t = CodonTable.unambiguous_dna_by_id[table_id]
        except KeyError:
            fail(f"Unknown genetic code (transl_table={table_id})",
                 "Biopython does not have that table.",
                 "Check /transl_table of the CDS in the GenBank record.")
        d = dict(t.forward_table)
        for s in t.stop_codons:
            d[s] = "*"
        _TABLES[table_id] = d
    return _TABLES[table_id]


def translate_codon(codon: str, table_id: int = 1) -> str:
    """Translates a codon already oriented in the reading direction. Unusual bases → 'X'."""
    return codon_table(table_id).get(codon.upper(), "X")


def revcomp_base(b: str) -> str:
    return COMP.get(b.upper(), "N")


# ───────────────────────── download / reading ───────────────────────────────
def fetch_genbank(accession: str, cache_dir: Path, email: Optional[str],
                  api_key: Optional[str] = None, offline: bool = False,
                  retries: int = 3) -> Path:
    """Downloads <accession> from NCBI (nuccore, gbwithparts) into the cache and returns the file."""
    cache_dir.mkdir(parents=True, exist_ok=True)
    f = cache_dir / f"{accession}.gb"
    if f.exists() and f.stat().st_size > 0:
        return f
    if offline:
        fail(f"{accession} is not in the cache ({cache_dir})",
             "--offline was requested and it was never downloaded.",
             "Download it with internet access (login node; the compute nodes "
             "of CESGA may have no outbound access) or pass the local .gb.")
    if not email:
        fail("Missing --email to query NCBI",
             "NCBI requires a contact email in Entrez.",
             "Add --email you@email or use --refs with local .gb files.")
    Entrez.email = email
    if api_key:
        Entrez.api_key = api_key
    last = None
    for k in range(retries):
        try:
            h = Entrez.efetch(db="nuccore", id=accession, rettype="gbwithparts", retmode="text")
            txt = h.read()
            if isinstance(txt, bytes):
                txt = txt.decode()
            if not txt.lstrip().startswith("LOCUS"):
                fail(f"NCBI did not return a GenBank record for '{accession}'",
                     f"unexpected response: {txt[:80]!r}",
                     "Check the accession (correct version? e.g., NC_045512.2).")
            f.write_text(txt)
            time.sleep(0.4)           # courtesy to NCBI (limit 3 queries/s without an API key)
            return f
        except SystemExit:
            raise
        except Exception as e:        # network, HTTP 429/5xx…
            last = e
            time.sleep(2 * (k + 1))
    fail(f"Could not download {accession} from NCBI after {retries} attempts",
         f"{type(last).__name__}: {last}",
         "If it is HTTP 400, NCBI does not recognize that accession (misspelled or without version, e.g., NC_045512.2?). "
         "If it is a network problem, check the connection or download the .gb by hand and pass it with --refs file.gb.")


def _split_raw_genbank(text: str) -> List[str]:
    """Splits a multi-record GenBank file into raw records (ending in '//')."""
    out, cur = [], []
    for ln in text.splitlines():
        cur.append(ln)
        if ln.strip() == "//":
            out.append("\n".join(cur) + "\n")
            cur = []
    if any(l.strip() for l in cur):
        out.append("\n".join(cur) + "\n//\n")
    return out


def load_references(specs: List[str], cache_dir: Path, email: Optional[str],
                    api_key: Optional[str] = None, offline: bool = False
                    ) -> Tuple[list, List[str]]:
    """
    specs: NCBI accessions and/or paths to .gb files (may contain several records).
    Returns (SeqRecord records, raw GenBank texts in the same order).
    """
    records, raws = [], []
    for spec in specs:
        spec = spec.strip()
        if not spec:
            continue
        p = Path(spec)
        if p.is_file():
            text = p.read_text()
        elif ACC_RE.match(spec):
            text = fetch_genbank(spec, cache_dir, email, api_key, offline).read_text()
        else:
            fail(f"Cannot understand the reference '{spec}'",
                 "it is not an existing file nor does it look like an NCBI accession.",
                 "Use an accession (NC_045512.2) or the path to a .gb.")
        for raw in _split_raw_genbank(text):
            from io import StringIO
            try:
                rec = SeqIO.read(StringIO(raw), "genbank")
            except Exception as ex:
                fail(f"Could not read a GenBank record from '{spec}'",
                     f"Biopython said: {type(ex).__name__}: {str(ex)[:150]}",
                     "Check that the file is a complete GenBank file and is not truncated (each record must end with //).")
            try:
                seq_txt = str(rec.seq)
            except Exception:
                fail(f"Record {rec.id} contains no sequence",
                     "the GenBank file has no ORIGIN section (annotation only).",
                     "Download the complete record (rettype=gbwithparts) or use another .gb.")
            m_len = re.search(r"^LOCUS\s+\S+\s+(\d+)\s+(?:bp|nt)\b", raw, re.M)
            if m_len and int(m_len.group(1)) != len(seq_txt):
                fail(f"Record {rec.id} is incomplete: LOCUS declares {m_len.group(1)} nt and the sequence read has {len(seq_txt)}",
                     "the GenBank file is truncated or is an interrupted download.",
                     "Download it again (rettype=gbwithparts) and check that it ends with //.")
            if not seq_txt:
                fail(f"Record {rec.id} has an empty sequence", "there are no bases under ORIGIN.",
                     "Use a complete GenBank file.")
            records.append(rec)
            raws.append(raw)
    if not records:
        fail("No reference was loaded", "the --refs list is empty.",
             "Pass at least one accession or .gb.")
    ids = [r.id for r in records]
    dup = {i for i in ids if ids.count(i) > 1}
    if dup:
        fail(f"Repeated contigs in the reference: {sorted(dup)}",
             "two records share the same identifier and their positions would overwrite each other.",
             "Remove the duplicate from --refs.")
    for r in records:
        s = str(r.seq).upper()
        bad = sum(1 for c in s if c not in "ACGT")
        if bad / max(len(s), 1) > 0.01:
            disclaimer(f"{r.id}: {100*bad/len(s):.1f}% differ from ACGT (N/ambiguous). "
                       "At those positions the reference base will not be compared.")
    return records, raws


def assign_offsets(records) -> List[dict]:
    """One dict per contig with contig, length, offset (global coordinates)."""
    out, off = [], 0
    for r in records:
        out.append(dict(contig=r.id, length=len(r), offset=off,
                        topology=r.annotations.get("topology", "linear"),
                        description=r.description))
        off += len(r) + CONTIG_GAP
    return out


def write_contigs(contigs: List[dict], path: Path) -> None:
    with path.open("w") as fh:
        fh.write("contig\tlength\toffset\ttopology\tdescription\n")
        for c in contigs:
            fh.write(f"{c['contig']}\t{c['length']}\t{c['offset']}\t{c['topology']}\t{c['description']}\n")


def read_contigs(path: Path) -> List[dict]:
    if not Path(path).is_file():
        fail(f"{path} does not exist", "step 0 (srasel prepare-reference) has not been run or the path is different.",
             "Run srasel prepare-reference or pass the correct --ref-dir/--contigs.")
    rows = []
    with open(path) as fh:
        hdr = fh.readline().rstrip("\n").split("\t")
        for ln in fh:
            v = ln.rstrip("\n").split("\t")
            d = dict(zip(hdr, v))
            d["length"], d["offset"] = int(d["length"]), int(d["offset"])
            rows.append(d)
    return rows


def resolve_contig(chrom: str, contigs: List[dict], alias: Optional[Dict[str, str]] = None
                   ) -> Optional[dict]:
    """
    Matches the contig name of a bam-readcount with the reference:
    exact → user alias → without version (NC_045512 ≡ NC_045512.2).
    There is NO "guessing" when there are several contigs: None is returned and the caller fails.
    """
    by_id = {c["contig"]: c for c in contigs}
    if alias and chrom in alias:
        chrom = alias[chrom]
    if chrom in by_id:
        return by_id[chrom]
    base = chrom.split(".")[0]
    cand = [c for c in contigs if c["contig"].split(".")[0] == base]
    return cand[0] if len(cand) == 1 else None


def to_global(contig: dict, pos: int) -> int:
    return contig["offset"] + pos


def from_global(gpos: int, contigs: List[dict]) -> Tuple[Optional[str], Optional[int]]:
    for c in contigs:
        if c["offset"] < gpos <= c["offset"] + c["length"]:
            return c["contig"], gpos - c["offset"]
    return None, None


# ───────────────────────── CDS model ────────────────────────────────────
@dataclass
class CDS:
    cds_id: str
    contig: str
    offset: int
    gene: str
    product: str
    strand: int
    table: int
    codons: List[Tuple[int, int, int]]         # triplets in contig coords., READING ORDER
    protein: str
    nparts: int
    slippage: bool
    spliced_gap: bool                           # there is a gap between parts (intron / +1 frameshift)
    overlap_join: bool                          # some position is read twice (−1 frameshift)
    codon_start: int
    partial5: bool
    partial3: bool
    status: str = "unverified"   # ok | ok_alt_start | ok_exception | PARTIAL (only validated prefix) | MISMATCH | unverified
    notes: List[str] = field(default_factory=list)

    @property
    def aa_len(self) -> int:
        return len(self.codons)


_COMPLEMENT_TT = str.maketrans("ACGT", "TGCA")


def _codon_seq(seq: str, trip: Tuple[int, int, int], strand: int) -> str:
    s = "".join(seq[p - 1] for p in trip)
    return s.translate(_COMPLEMENT_TT) if strand == -1 else s


def _parse_transl_except(vals: List[str]) -> Dict[int, str]:
    """'(pos:8712..8714,aa:Trp)' → {8712: 'W', 8713: 'W', 8714: 'W'} (by genomic position)."""
    out = {}
    for v in vals:
        m = re.search(r"pos:(?:complement\()?(\d+)(?:\.\.(\d+))?\)?,\s*aa:([A-Za-z]+)", v)
        if not m:
            continue
        a, b, aa = int(m.group(1)), int(m.group(2) or m.group(1)), m.group(3)
        letter = "*" if aa.upper() == "TERM" else IUPACData.protein_letters_3to1.get(aa.capitalize(), "X")
        for p in range(a, b + 1):
            out[p] = letter
    return out


def _positions_in_order(parts, strand_hint: int) -> List[int]:
    pos: List[int] = []
    for part in parts:
        if getattr(part, "ref", None):
            raise ValueError(f"part in another record ({part.ref}); not supported")
        r = list(range(int(part.start) + 1, int(part.end) + 1))
        pos += r[::-1] if part.strand == -1 else r
    return pos


def _translate_model(seq: str, pos: List[int], strand: int, table: int,
                     codon_start: int, exc: Dict[int, str]):
    pos = pos[codon_start - 1:]
    trips = [tuple(pos[i:i + 3]) for i in range(0, len(pos) - 2, 3)]
    prot = []
    used_exc = False
    for t in trips:
        aa = translate_codon(_codon_seq(seq, t, strand), table)
        hit = [exc[p] for p in t if p in exc]
        if hit:
            aa, used_exc = hit[0], True
        prot.append(aa)
    return trips, "".join(prot), used_exc, len(pos) % 3


def build_cds_models(rec, warn=disclaimer) -> List[CDS]:
    """All the CDSs of a record, reconstructed and validated against /translation."""
    seq = str(rec.seq).upper()
    models: List[CDS] = []
    name_count: Dict[str, int] = {}
    for n, ft in enumerate(f for f in rec.features if f.type == "CDS"):
        q = ft.qualifiers
        if "pseudo" in q or "pseudogene" in q:
            warn(f"{rec.id}: pseudo CDS (feature {n}) ignored: it is a pseudogene according to NCBI.")
            continue
        gene = (q.get("gene") or q.get("locus_tag") or q.get("product") or [f"CDS{n+1}"])[0]
        if "gene" not in q:
            warn(f"{rec.id}: CDS #{n+1} has no /gene; it is named '{gene}' "
                 f"(from {'locus_tag' if 'locus_tag' in q else 'product' if 'product' in q else 'order'}).")
        gene = re.sub(r"[|;,\s]+", "_", gene)
        product = (q.get("product") or [""])[0]
        k = name_count.get(gene, 0) + 1
        name_count[gene] = k
        cds_id = f"{rec.id}:{gene}#{k}"
        strands = {p.strand for p in ft.location.parts}
        if len(strands) != 1 or None in strands:
            warn(f"{cds_id}: mixed or undefined strand ({strands}); CDS omitted.")
            continue
        strand = ft.location.parts[0].strand
        table = int((q.get("transl_table") or ["1"])[0])
        cs = int((q.get("codon_start") or ["1"])[0])
        exc = _parse_transl_except(q.get("transl_except", []))
        parts = list(ft.location.parts)
        ref_prot = (q.get("translation") or [None])[0]

        best = None
        for order_name, plist in (("as is", parts), ("reversed", parts[::-1])):
            try:
                pos = _positions_in_order(plist, strand)
            except ValueError as e:
                warn(f"{cds_id}: {e}; CDS omitted.")
                best = "skip"
                break
            trips, prot, used_exc, rem = _translate_model(seq, pos, strand, table, cs, exc)
            cand = (order_name, pos, trips, prot, used_exc, rem)
            if ref_prot is None:
                best = best or cand
                break
            if prot.rstrip("*") == ref_prot.rstrip("*") or \
               (prot[1:].rstrip("*") == ref_prot[1:].rstrip("*") and ref_prot[:1] == "M"):
                best = cand
                break
            best = best or cand          # if none validates, keep the first one and warn
        if best == "skip":
            continue
        order_name, pos, trips, prot, used_exc, rem = best

        notes = []
        if order_name == "reversed":
            notes.append("the parts of the join came in reverse order; they were reordered.")
        if cs != 1:
            notes.append(f"/codon_start={cs}: the first {cs-1} nt are ignored (partial codon).")
        partial5 = "<" in str(ft.location)
        partial3 = ">" in str(ft.location)
        if rem and not partial3:
            notes.append(f"length (after codon_start) not a multiple of 3 (remainder {rem}) and the CDS is not "
                         "marked as partial at 3': the last nt do not form a codon and are ignored.")
        if exc:
            notes.append("has /transl_except (e.g., selenocysteine, stop read as aa): applied.")
        if "exception" in q:
            notes.append(f"/exception={q['exception'][0]!r}")

        # validation against the protein deposited by NCBI
        if ref_prot is None:
            internal = "*" in prot[:-1]
            status = "MISMATCH" if internal else "unverified"
            notes.append("no /translation: cannot be compared with NCBI"
                         + ("; there are internal stops!" if internal else "; no internal stops."))
        elif prot.rstrip("*") == ref_prot.rstrip("*"):
            status = "ok_exception" if used_exc else "ok"
        elif prot[1:].rstrip("*") == ref_prot[1:].rstrip("*") and ref_prot[:1] == "M":
            status = "ok_alt_start"
            notes.append(f"alternative start codon ({_codon_seq(seq, trips[0], strand)}→M).")
        else:
            first = next((i for i, (a, b) in enumerate(zip(prot, ref_prot)) if a != b),
                         min(len(prot), len(ref_prot)))
            notes.append(f"the reconstructed protein differs from /translation from aa {first+1} "
                         f"(len {len(prot.rstrip('*'))} vs {len(ref_prot)}).")
            # Only the VALIDATED prefix is reliable: what comes after is not annotated (false amino acids
            # would be worse than none). If NCBI declares /exception (RNA editing, artificial frameshift…)
            # the mismatch is a known limitation of the record (PARTIAL); otherwise, it is a failure (MISMATCH).
            trips = trips[:first]
            prot = prot[:first]
            if "exception" in q:
                status = "PARTIAL"
                notes.append(f"/exception={q['exception'][0]!r}: the mRNA translated by NCBI is not a copy "
                             f"of the genome (e.g., nt are inserted) and the record does not indicate the point with a "
                             f"join. ONLY the first {first} codons (validated) are annotated; the rest is not annotated.")
            else:
                status = "MISMATCH"
                notes.append(f"no /exception explains it. Only the first {first} validated codons are annotated.")
        spliced = any(int(parts[i + 1].start) - int(parts[i].end) > 0 for i in range(len(parts) - 1)) \
            if strand == 1 else \
            any(int(parts[i].start) - int(parts[i + 1].end) > 0 for i in range(len(parts) - 1))
        models.append(CDS(
            cds_id=cds_id, contig=rec.id, offset=0, gene=gene, product=product,
            strand=strand, table=table, codons=trips, protein=prot,
            nparts=len(parts), slippage="ribosomal_slippage" in q,
            spliced_gap=spliced, overlap_join=len(pos) != len(set(pos)),
            codon_start=cs, partial5=partial5, partial3=partial3, status=status, notes=notes))
        if status == "MISMATCH":
            warn(f"{cds_id}: does NOT validate against NCBI /translation → {' '.join(notes)} "
                 "The amino acid annotations of this CDS are NOT reliable.")
        elif status == "PARTIAL":
            warn(f"{cds_id}: PARTIAL validation against NCBI /translation → {' '.join(notes)}")
    return models


# ───────────────────────── annotation by position ───────────────────────────
# One annotation = (cds_id, gene, strand, codon_pos, aa_idx, (g1,g2,g3), table)  [GLOBAL coords]
Annot = Tuple[str, str, int, int, int, Tuple[int, int, int], int]


def position_annotations(models_by_contig: Dict[str, List[CDS]], contigs: List[dict]
                         ) -> Dict[int, List[Annot]]:
    """
    pos_global → list of annotations, one per (CDS, codon) containing that base.
    Only IDENTICAL annotations are merged (same triplet, strand, code, gene name AND index
    of amino acid): e.g., ORF1a and ORF1ab (both "ORF1ab") read identically up to the slippage site.
    Both are kept when they are different proteins that coincide in frame (gag-pol and gag) or
    isoforms of the same gene with different numbering (HBV: large/middle/small S, which start
    at different ATGs: the same codon is aa 226, 171 or 37 depending on the isoform).
    A single base can have several valid annotations:
      · overlapping genes in another frame (gag-pol/gag, tat/rev/env…)
      · ribosomal slippage bases (13468 in SARS-CoV-2: read as the 3rd of one codon and the 1st of the next)
    """
    off = {c["contig"]: c["offset"] for c in contigs}
    out: Dict[int, List[Annot]] = {}
    seen: Dict[int, set] = {}
    for contig, models in models_by_contig.items():
        o = off[contig]
        for m in models:
            for ai, trip in enumerate(m.codons, 1):
                g = tuple(o + p for p in trip)
                key = (m.strand, g, m.table, m.gene, ai)
                for cp, p in enumerate(g, 1):
                    s = seen.setdefault(p, set())
                    if key in s:
                        continue
                    s.add(key)
                    out.setdefault(p, []).append((m.cds_id, m.gene, m.strand, cp, ai, g, m.table))
    return out


def legacy_columns(annots: List[Annot]) -> Tuple[str, str, str]:
    """
    Legacy columns gene / codon_pos / aa_idx (read by the HTML).
    Same rule as SRASel 1.x: one (cp, aa) pair per gene, except for the (3,x),(1,y) pattern
    of a ribosomal slippage, which keeps both. Now the reading order is already correct
    on the − strand as well.
    """
    per_gene: Dict[str, List[Tuple[int, int]]] = {}
    for _, gene, _, cp, ai, _, _ in annots:
        lst = per_gene.setdefault(gene, [])
        if all(c != cp for c, _ in lst):
            lst.append((cp, ai))
    genes, cps, ais = [], [], []
    for g, lst in per_gene.items():
        keep = lst if (len(lst) == 2 and lst[0][0] == 3 and lst[1][0] == 1) else [lst[0]]
        genes.append(g)
        cps += [str(c) for c, _ in keep]
        ais += [str(a) for _, a in keep]
    return ",".join(genes), ",".join(cps), ",".join(ais)


def encode_annots(annots: List[Annot]) -> str:
    """cds_id|gene|strand|cp|aa|g1-g2-g3|table ;…  (column cds_codons of *_genes.tsv)"""
    return ";".join(f"{c}|{g}|{s}|{cp}|{ai}|{t[0]}-{t[1]}-{t[2]}|{tb}"
                    for c, g, s, cp, ai, t, tb in annots)


def decode_annots(cell: str) -> List[Annot]:
    if not cell:
        return []
    out = []
    for item in cell.split(";"):
        c, g, s, cp, ai, t, tb = item.split("|")
        a, b, d = (int(x) for x in t.split("-"))
        out.append((c, g, int(s), int(cp), int(ai), (a, b, d), int(tb)))
    return out


# ───────────────────────── features for the HTML ─────────────────────────────
FEATURE_COLS = ["contig", "type", "name", "short_name", "product", "strand", "contig_start", "contig_end",
                "global_start", "global_end", "parent_cds", "aa_start", "aa_end", "n_parts", "location",
                "wraps_origin", "note"]
_NSP_PROD_RE = re.compile(r"\b(nsp\d+)\b", re.I)
_NSP_NOTE_RE = re.compile(r"^\s*(nsp\d+)", re.I)      # only if the note STARTS with it: 'nsp5A_3CLpro…' → nsp5


def _short_name(product: str, note: str, gene: str) -> str:
    """
    nsp1…nsp16 if NCBI indicates it: in /product, or at the START of /note. It is not searched anywhere in the
    note because it mentions neighbors ('mediates cleavages downstream of nsp4', 'former nsp1').
    Otherwise, the product without 'protein/peptide'.
    """
    m = _NSP_PROD_RE.search(product or "") or _NSP_NOTE_RE.match(note or "")
    if m:
        return m.group(1).lower()
    base = re.sub(r"\b(protein|peptide)\b", "", (product or gene or "").lower()).strip()
    return re.sub(r"\s+", " ", base) or (gene or "")


def feature_rows(rec, models: List[CDS], offset: int = 0) -> List[dict]:
    """
    Table of features (gene, CDS, mat_peptide, UTR…) with nt ranges (contig and global) and, for the
    mature peptides, the amino acid range within their parent CDS. This is what the HTML needs
    to label genes/proteins WITHOUT fixed SARS-CoV-2 lists.
    """
    cds_pos: Dict[str, Dict[int, int]] = {}
    for m in models:
        d: Dict[int, int] = {}
        for ai, trip in enumerate(m.codons, 1):
            for p in trip:
                d.setdefault(p, ai)
        cds_pos[m.cds_id] = d

    rows: List[dict] = []
    models_iter = iter(models)
    by_order = {}
    # the models are built in the same order as the CDS features (minus omitted pseudogenes)
    cds_feats = [f for f in rec.features if f.type == "CDS"]
    for m in models:
        by_order[m.cds_id] = m

    def span(ft):
        return int(ft.location.start) + 1, int(ft.location.end)

    for ft in rec.features:
        if ft.type not in ("gene", "CDS", "mat_peptide", "sig_peptide", "5'UTR", "3'UTR"):
            continue
        q = ft.qualifiers
        gene = (q.get("gene") or q.get("locus_tag") or [""])[0]
        product = (q.get("product") or [""])[0]
        note = " ".join(q.get("note", []))[:160]
        s, e = span(ft)
        parts = list(ft.location.parts)
        # EXACT location in contig coordinates (1-based, inclusive), in reading order
        loc_txt = ",".join(f"{int(p.start) + 1}..{int(p.end)}" for p in parts)
        # CDSs that cross the origin of a circular genome: their parts are not monotonic in reading order
        starts = [int(p.start) for p in parts]
        wraps = any((b < a) if ft.location.strand != -1 else (b > a) for a, b in zip(starts, starts[1:]))
        row = dict(contig=rec.id, type=ft.type, name=gene or product, product=product,
                   short_name=_short_name(product, note, gene), strand="+" if ft.location.strand != -1 else "-",
                   contig_start=s, contig_end=e, global_start=s + offset, global_end=e + offset,
                   parent_cds="", aa_start="", aa_end="", n_parts=len(parts), location=loc_txt,
                   wraps_origin=wraps, note=note)
        if ft.type == "mat_peptide" or ft.type == "sig_peptide":
            pos = []
            for part in ft.location.parts:
                pos += list(range(int(part.start) + 1, int(part.end) + 1))
            best = None
            for m in models:
                d = cds_pos[m.cds_id]
                hit = [d[p] for p in pos if p in d]
                if len(hit) == len(pos):               # the CDS contains the WHOLE peptide
                    best = (m, min(hit), max(hit)); break
                if hit and best is None:
                    best = (m, min(hit), max(hit))      # partial containment: keep the best so far
            if best:
                row.update(parent_cds=best[0].cds_id, aa_start=best[1], aa_end=best[2])
        rows.append(row)
    return rows


def write_features(rows: List[dict], path: Path) -> None:
    seen = set()
    with Path(path).open("w") as fh:
        fh.write("\t".join(FEATURE_COLS) + "\n")
        for r in rows:
            key = (r["contig"], r["type"], r["location"], r["name"], r["product"], r["parent_cds"])
            if key in seen:         # e.g., nsp1…nsp10 appear under both pp1a AND pp1ab with the same coordinates
                continue
            seen.add(key)
            fh.write("\t".join(str(r[c]).replace("\t", " ").replace("\n", " ") for c in FEATURE_COLS) + "\n")


# ════════════════════════════════════════════════════════════════════════════════════════════════════
# Step 0 · reference preparation (NCBI)
# ════════════════════════════════════════════════════════════════════════════════════════════════════
PREPARE_REFERENCE_DOC = r"""
srasel prepare-reference – STEP 0 of SRASel 2.0
───────────────────────────────────────────
Prepares the reference of ANY virus (including segmented ones) from NCBI.

    srasel prepare-reference --refs NC_045512.2 --email you@email --outdir reference
    srasel prepare-reference --refs NC_005302.1,NC_005300.2,NC_005301.3 --email you@email
    srasel prepare-reference --refs my_virus.gb            # without internet

Writes to --outdir:
    references.gb        raw GenBank of all contigs (read by step 5)
    reference.fna        FASTA with the SAME contig names → use it to ALIGN and for
                         bam-readcount (-f), so reference, reads and annotation agree
    contigs.tsv          contig, length, global offset, topology
    cds_model.tsv        each CDS: strand, parts, slippage, genetic code, validation status
    features.tsv         genes, CDS and mature peptides (nsp…) with nt and aa ranges (for the HTML)
    REFERENCE_REPORT.txt warnings and limitations detected in this reference

Each CDS is reconstructed and TRANSLATED; if it does not match NCBI /translation a warning is issued
(or the run aborts with --strict).
"""

#!/usr/bin/env python3



def main_prepare_reference():
    ap = argparse.ArgumentParser(description=PREPARE_REFERENCE_DOC, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--refs", required=True, nargs="+",
                    help="NCBI accessions and/or .gb files (separated by space or comma). "
                         "Segmented virus: one accession per segment.")
    ap.add_argument("--email", help="email for Entrez (required if downloading)")
    ap.add_argument("--api-key", help="NCBI API key (optional, higher quota)")
    ap.add_argument("--outdir", default="reference", type=Path)
    ap.add_argument("--cache-dir", default=None, type=Path,
                    help="download cache (default: <outdir>/gb_cache)")
    ap.add_argument("--offline", action="store_true", help="do not query NCBI; only cache/local files")
    ap.add_argument("--strict", action="store_true",
                    help="abort if any CDS does not validate against NCBI /translation")
    args = ap.parse_args()

    specs = [s for a in args.refs for s in a.split(",") if s.strip()]
    args.outdir.mkdir(parents=True, exist_ok=True)
    cache = args.cache_dir or (args.outdir / "gb_cache")

    report = []

    def note(msg):
        report.append(msg)
        disclaimer(msg)

    records, raws = load_references(specs, cache, args.email, args.api_key, args.offline)
    contigs = assign_offsets(records)
    models_by_contig = {}
    for rec in records:
        models_by_contig[rec.id] = build_cds_models(rec, warn=note)
    if not any(models_by_contig.values()):       # [input check 2026-11-18] a reference without any CDS used to fail at step 6 (matplotlib legend)
        fail("The reference has no genes (no CDS feature in any record)",
             "SRASel places every position in a protein; with no gene there is nothing to annotate.",
             "use a GenBank that annotates its genes, or give --fasta with a gene list (--genes)")

    # ── output files ────────────────────────────────────────────────────
    (args.outdir / "references.gb").write_text("".join(raws))
    # header name = ONLY the id (no description) so that bam-readcount/BWA see the same contig
    with (args.outdir / "reference.fna").open("w") as fh:
        for r in records:
            s = str(r.seq).upper()
            fh.write(f">{r.id}\n" + "\n".join(s[i:i + 70] for i in range(0, len(s), 70)) + "\n")
    write_contigs(contigs, args.outdir / "contigs.tsv")
    # genes / CDS / mature peptides with nt and aa ranges → to label proteins in the HTML
    feats = []
    for rec, c in zip(records, contigs):
        feats += feature_rows(rec, models_by_contig[rec.id], c["offset"])
    write_features(feats, args.outdir / "features.tsv")

    n_bad = 0
    with (args.outdir / "cds_model.tsv").open("w") as fh:
        fh.write("cds_id\tcontig\tgene\tproduct\tstrand\tparts\tslippage\tspliced_gap\toverlap_join\t"
                 "transl_table\tcodon_start\tn_aa\tstatus\tnotes\n")
        for contig, ms in models_by_contig.items():
            for m in ms:
                n_bad += m.status == "MISMATCH"
                fh.write("\t".join(map(str, [
                    m.cds_id, m.contig, m.gene, m.product, "+" if m.strand == 1 else "-", m.nparts,
                    m.slippage, m.spliced_gap, m.overlap_join, m.table, m.codon_start,
                    m.aa_len, m.status, " ".join(m.notes)])) + "\n")

    # ── summary and limitations SPECIFIC to this reference ─────────────────
    all_models = [m for ms in models_by_contig.values() for m in ms]
    lines = ["=" * 78, "SRASel 2.0 · reference prepared", "=" * 78]
    for c in contigs:
        n = len(models_by_contig[c["contig"]])
        lines.append(f"  {c['contig']:14s} {c['length']:>8d} nt  offset={c['offset']:>8d}  "
                     f"{c['topology']:8s} {n:3d} CDS  {c['description'][:48]}")
    lines.append(f"  Total CDS: {len(all_models)}   validated against /translation: "
                 f"{sum(m.status.startswith('ok') for m in all_models)}   "
                 f"without /translation: {sum(m.status == 'unverified' for m in all_models)}   "
                 f"partial: {sum(m.status == 'PARTIAL' for m in all_models)}   "
                 f"do NOT validate: {n_bad}")

    caveats = []
    if len(contigs) > 1:
        caveats.append(f"Segmented/multi-contig virus ({len(contigs)}): SRASel uses GLOBAL coordinates "
                       f"(offset + position, gap of {CONTIG_GAP}). The output tables include the "
                       "columns 'contig' and 'contig_pos' with the actual position within each segment.")
    if any(c["topology"] == "circular" for c in contigs):
        caveats.append("There are CIRCULAR contigs: bam-readcount treats the reference as linear, so the "
                       "reads that cross the origin are not counted correctly and the CDSs that cross the origin "
                       "will have low coverage in that region.")
    if any(m.strand == -1 for m in all_models):
        caveats.append("There are CDSs on the − strand: variants are always reported on the strand of the reference "
                       "(+); the amino acid change is computed on the reverse complement.")
    if any(m.slippage or m.overlap_join for m in all_models):
        caveats.append("There are ribosomal slippage sites (/ribosomal_slippage or overlapping parts): the bases of the "
                       "slippage site have TWO valid readings; SRASel evaluates both and reports one as the primary.")
    if any(m.spliced_gap for m in all_models):
        caveats.append("There are CDSs with separate parts (splicing or frameshift): a codon can span the junction. "
                       "SRASel uses the three actual nt of the codon, not 'three consecutive positions'.")
    n_ov = sum(1 for _ in _overlaps(models_by_contig, contigs))
    if n_ov:
        caveats.append(f"{n_ov} positions belong to more than one CDS in different frames (overlapping genes). "
                       "The column 'aa_change' uses the first CDS (GenBank order) and 'other_frames' "
                       "lists the effect on the others.")
    if any(m.status == "PARTIAL" for m in all_models):
        caveats.append("There are CDSs with PARTIAL validation (RNA editing or another /exception that the record does not model): "
                       "only their first validated codons are annotated; see cds_model.tsv.")
    if any(m.status == "unverified" for m in all_models):
        caveats.append("There are CDSs without /translation: their frame could not be checked against NCBI.")
    lines += ["", "LIMITATIONS / THINGS TO KEEP IN MIND:"] + [f"  · {c}" for c in caveats]
    lines += ["", "Note: the reference to which the reads were ALIGNED must be reference.fna (or have "
              "an identical sequence and the same contig names). Step 4 checks this base by base."]
    txt = "\n".join(lines)
    (args.outdir / "REFERENCE_REPORT.txt").write_text(txt + "\n\nWARNINGS DURING PREPARATION:\n"
                                                      + "\n".join(report) + "\n")
    print(txt)
    if n_bad and args.strict:
        fail(f"{n_bad} CDSs do not validate against NCBI /translation",
                "the reconstruction of the reading frame does not reproduce the deposited protein.",
                "Check cds_model.tsv (notes column). Without --strict the program continues, but those CDSs "
                "will give unreliable amino acids.")


def _overlaps(models_by_contig, contigs):
    ann = position_annotations(models_by_contig, contigs)
    for p, lst in ann.items():
        if len(lst) > 1:
            yield p


# ════════════════════════════════════════════════════════════════════════════════════════════════════
# Step 0b · annotation transfer to a consensus
# ════════════════════════════════════════════════════════════════════════════════════════════════════
TRANSFER_ANNOTATION_DOC = r"""
srasel transfer-annotation – annotation of your OWN CONSENSUS from an NCBI reference (SRASel 2.0)
─────────────────────────────────────────────────────────────────────────────────────────────────────
When reads are aligned to a sequence that is NOT the reference (a patient consensus, a
specific lineage, your own assembly), the NCBI gene and codon coordinates are no longer valid. This step
aligns your own sequence with the annotated reference and TRANSFERS each CDS (gene, strand, ribosomal slippage,
splice junctions), and checks that the resulting protein is valid.

    srasel transfer-annotation --query my_consensus.fna --source NC_001802.1 --outdir ref_consensus
    srasel prepare-reference --refs ref_consensus/annotated.gb --outdir reference     # normal step 0

Writes to --outdir:
    annotated.gb          GenBank of your own sequence with the transferred CDSs (input to step 0)
    transfer_report.tsv   per CDS: coordinates, no. of aa, identity with the NCBI protein, reason if discarded
    coord_map.tsv         own position → position in the canonical reference (0 = no equivalent: insertion)
    aa_map.tsv            own amino acid → amino acid in the canonical reference (the usual numbering,
                          e.g., HXB2 in HIV or Wuhan-Hu-1 in SARS-CoV-2)

A CDS is transferred only if its protein has no internal stops and resembles the NCBI one (--min-identity).
The rest are NOT annotated (better no annotation than a broken reading frame) and are explained in the report.
Transferred CDSs are written WITHOUT /translation: they have not been validated by NCBI, only by this check.
"""

#!/usr/bin/env python3



CIGAR_RE = re.compile(r"(\d+)([MIDNSHP=X])")
SKIP_QUALS = {"translation", "protein_id", "db_xref", "transl_except", "exception", "gene_synonym", "locus_tag"}


# ───────────────────────── alignment ─────────────────────────
def find_minimap2(arg):
    for c in (arg, shutil.which("minimap2"), str(Path.home() / "miniconda3/envs/srasel-real/bin/minimap2")):
        if c and Path(c).exists():
            return c
    fail("minimap2 not found", "it is used to align your sequence with the annotated reference.",
            "Install it (conda install -c bioconda minimap2) or pass --minimap2 /path/minimap2")


def align_maps(qrec, srecs, mm2):
    """Aligns your own sequence to the references; returns (ref_contig, s2q, q2s, coverage)."""
    with tempfile.TemporaryDirectory() as td:
        sf, qf = Path(td) / "s.fna", Path(td) / "q.fna"
        SeqIO.write(srecs, sf, "fasta"); SeqIO.write([qrec], qf, "fasta")
        r = subprocess.run([mm2, "-ax", "asm20", "--eqx", "-t", "2", str(sf), str(qf)], capture_output=True, text=True)
    if r.returncode:
        fail("minimap2 failed", r.stderr[-300:], "Check that the FASTA/GenBank files are valid.")
    hits = []
    for ln in r.stdout.splitlines():
        if ln.startswith("@"):
            continue
        f = ln.split("\t")
        flag = int(f[1])
        if flag & 4 or flag & 256:
            continue
        hits.append((f[2], flag, int(f[3]), f[5]))
    if not hits:
        fail(f"'{qrec.id}' does not align to the reference", "the sequences are too different (another virus?).",
                "Check that --source is the correct virus; for very different viruses use a closer reference.")
    best = max({h[0] for h in hits}, key=lambda c: sum(sum(int(n) for n, op in CIGAR_RE.findall(h[3]) if op in "=XM")
                                                       for h in hits if h[0] == c))
    if any(h[1] & 16 for h in hits if h[0] == best):
        fail(f"'{qrec.id}' is on the opposite strand to the reference",
                "SRASel needs both sequences in the same orientation to transfer the coordinates.",
                "Convert it to its reverse complement (for example with Biopython: seq.reverse_complement()).")
    L, S = len(qrec.seq), len(next(r for r in srecs if r.id == best).seq)
    s2q, q2s = [0] * (S + 2), [0] * (L + 2)
    for ctg, flag, pos, cig in sorted((h for h in hits if h[0] == best), key=lambda h: h[1] & 2048):
        rp = pos
        ops = CIGAR_RE.findall(cig)
        qp = 1 + sum(int(n) for n, op in ops[:1] if op in "SH")
        for n, op in ops:
            n = int(n)
            if op in "=XM":
                for k in range(n):
                    if s2q[rp + k] == 0 and q2s[qp + k] == 0:
                        s2q[rp + k], q2s[qp + k] = qp + k, rp + k
                rp += n; qp += n
            elif op == "I":
                qp += n
            elif op in "DN":
                rp += n
    cov = sum(1 for x in q2s[1:L + 1] if x) / L
    return best, s2q, q2s, cov


# ───────────────────────── CDS transfer ─────────────────────────
def lift_part(a, b, s2q):
    """Interval [a,b] (1-based) of the reference → interval in your own sequence + bases lost at the start/end."""
    i = a
    while i <= b and s2q[i] == 0:
        i += 1
    j = b
    while j >= a and s2q[j] == 0:
        j -= 1
    if i > j:
        return None
    return s2q[i], s2q[j], i - a, b - j


_ALN = Align.PairwiseAligner()
_ALN.substitution_matrix = substitution_matrices.load("BLOSUM62")
_ALN.open_gap_score, _ALN.extend_gap_score, _ALN.mode = -10, -0.5, "global"
_ALPHA = set(_ALN.substitution_matrix.alphabet)


def _align(a, b):
    """Global protein alignment. A codon with an ambiguous base (IUPAC: M, Y, R…) is translated to B, Z, J or X; those
    not in the BLOSUM62 alphabet (e.g., J) are treated as X so as not to abort. Positions do not change."""
    fix = lambda t: "".join(c if c in _ALPHA else "X" for c in t)
    return _ALN.align(fix(a), fix(b))[0]


def protein_of(ft, seq, cs, table, exc=None):
    """Protein of the CDS; `exc` = {position (1-based): aa} applies /transl_except (stop read as aa, selenocysteine…)."""
    if exc:
        strand = ft.location.parts[0].strand
        pos = _positions_in_order(list(ft.location.parts), strand)
        return _translate_model(str(seq).upper(), pos, strand, table, cs, exc)[1]
    nt = str(ft.extract(seq))[cs - 1:]
    return str(Seq(nt[: len(nt) // 3 * 3]).translate(table=table))


def exc_qualifier(exc, strand):
    """{pos: aa} → /transl_except values in coordinates of your own sequence."""
    out, run = [], []
    for p in sorted(exc):
        if run and (p != run[-1] + 1 or exc[p] != exc[run[0]]):
            out.append(run); run = []
        run.append(p)
    if run:
        out.append(run)
    res = []
    for r in out:
        aa = exc[r[0]]
        name = "TERM" if aa == "*" else IUPACData.protein_letters_1to3.get(aa, "OTHER").upper() if aa in IUPACData.protein_letters_1to3 else "OTHER"
        name = {"TRP": "Trp", "SEC": "Sec", "PYL": "Pyl", "TERM": "TERM", "OTHER": "OTHER"}.get(name, name.capitalize())
        rng = f"{r[0]}..{r[-1]}" if len(r) > 1 else f"{r[0]}"
        res.append(f"(pos:{'complement(' + rng + ')' if strand == -1 else rng},aa:{name})")
    return res


def trim_location(loc, nt_keep):
    """Keeps the first nt_keep nt of the CDS in reading order (+ or − strand)."""
    out, left, strand = [], nt_keep, loc.parts[0].strand
    for part in loc.parts:
        n = int(part.end) - int(part.start)
        if left <= 0:
            break
        take = min(n, left)
        out.append(FeatureLocation(int(part.start), int(part.start) + take, strand=strand) if strand != -1
                   else FeatureLocation(int(part.end) - take, int(part.end), strand=strand))
        left -= take
    return out[0] if len(out) == 1 else CompoundLocation(out)


def extend_to_stop(new, qrec, cs, table, exc=None, max_codons=150):
    """If the last codon of your CDS is not a stop (the reference ended earlier, e.g., HXB2 Tat with a premature
    stop), extends the CDS in its same frame up to the first stop of YOUR sequence."""
    parts = list(new.location.parts)
    strand = parts[0].strand
    last = parts[-1] if strand != -1 else parts[0]      # the 3' reading end
    for k in range(1, max_codons + 1):
        d = 3 * k
        if strand != -1:
            e = int(last.end) + d
            if e > len(qrec.seq):
                return None
            ext = parts[:-1] + [FeatureLocation(int(last.start), e, strand=strand)]
        else:
            st = int(last.start) - d
            if st < 0:
                return None
            ext = [FeatureLocation(st, int(last.end), strand=strand)] + parts[1:]
        cand = SeqFeature(ext[0] if len(ext) == 1 else CompoundLocation(ext), type="CDS")
        cand.qualifiers = dict(new.qualifiers)
        pq = protein_of(cand, qrec.seq, cs, table, exc)
        if "*" in pq:
            return cand if pq.index("*") == len(pq) - 1 and pq.count("*") == 1 else None
    return None


def transfer_cds(ft, srec, qrec, s2q, min_identity):
    """→ (SeqFeature | None, report row, aa_map). Never raises: returns the reason if discarded."""
    q = ft.qualifiers
    name = (q.get("gene") or q.get("product") or ["CDS"])[0]
    row = dict(cds=name, product=(q.get("product") or [""])[0], src_loc=str(ft.location), status="", reason="",
               q_loc="", n_aa=0, identity="")
    src_exc = [f"{k}={'; '.join(q[k])[:60]}" for k in ("exception", "transl_except") if k in q]
    exc_src = _parse_transl_except(q.get("transl_except", []))
    parts = list(ft.location.parts)
    strands = {p.strand for p in parts}
    if len(strands) != 1:
        row.update(status="discarded", reason="parts on different strands (trans-splicing): not supported")
        return None, row, []
    strand = parts[0].strand
    lifted, lost_first, lost_last = [], 0, 0
    for k, p in enumerate(parts):
        r = lift_part(int(p.start) + 1, int(p.end), s2q)
        if r is None:
            row.update(status="discarded", reason=f"part {k + 1} of the CDS has no equivalent in your sequence "
                                                   "(deleted or unaligned region)")
            return None, row, []
        qs, qe, ls, le = r
        lifted.append((qs, qe))
        if k == 0:
            lost_first = ls if strand != -1 else le          # bases lost at the 5' reading end
        if k == len(parts) - 1:
            lost_last = le if strand != -1 else ls
    cs0 = int((q.get("codon_start") or ["1"])[0])
    # if your sequence does not cover the start of the CDS, the phase is readjusted so that the first complete codon is the correct one
    cs = 1 + ((cs0 - 1 - lost_first) % 3)
    table = int((q.get("transl_table") or ["1"])[0])
    ps = (q.get("translation") or [protein_of(ft, srec.seq, cs0, table, exc_src)])[0].rstrip("*")
    # /transl_except of the reference: it is transferred to your sequence (if its codon aligns) and applied when translating
    exc_q = {s2q[p_]: aa for p_, aa in exc_src.items() if 0 < p_ < len(s2q) and s2q[p_]}

    # candidates: the parts as transferred and, if 1-2 nt are left over between two parts (e.g., the “artificial frameshift”
    # of HXB2 in vpr, which a functional consensus does not need), the variant with that gap closed
    cands = [lifted]
    for k in range(len(lifted) - 1):
        gap = lifted[k + 1][0] - lifted[k][1] - 1
        if 1 <= gap <= 2:
            alt = list(lifted); alt[k + 1] = (lifted[k][1] + 1, lifted[k + 1][1])
            cands.append(alt)
    best = None
    for cand in cands:
        loc = [FeatureLocation(a_ - 1, b_, strand=strand) for a_, b_ in cand]
        nloc = loc[0] if len(loc) == 1 else CompoundLocation(loc)
        new = SeqFeature(nloc, type="CDS")
        new.qualifiers = {k: v for k, v in q.items() if k not in SKIP_QUALS}
        new.qualifiers["codon_start"] = [str(cs)]
        pq = protein_of(new, qrec.seq, cs, table, exc_q)
        body = pq[:-1] if pq.endswith("*") else pq
        stops = body.count("*")
        pairs, matches, ident = [], 0, 0.0
        if body and not stops:
            aln = _align(body, ps)
            for (a0, a1), (b0, b1) in zip(*aln.aligned):
                for k in range(a1 - a0):
                    pairs.append((a0 + k + 1, b0 + k + 1))
                    matches += body[a0 + k] == ps[b0 + k]
            ident = matches / max(len(body), len(ps))
        score = (stops == 0 and bool(body), ident, -stops)
        if best is None or score > best[0]:
            best = (score, new, nloc, body, stops, ident, pairs, cand is not lifted)
    _, new, nloc, body, stops, ident, pairs, closed = best
    extended = 0
    if not stops and body and not lost_last and protein_of(ft, srec.seq, cs0, table, exc_src).endswith("*") \
            and not protein_of(new, qrec.seq, cs, table, exc_q).endswith("*"):
        ext = extend_to_stop(new, qrec, cs, table, exc_q)
        if ext is not None:
            pq2 = protein_of(ext, qrec.seq, cs, table, exc_q)
            extended = len(pq2) - 1 - len(body)
            new, nloc, body = ext, ext.location, pq2[:-1]
            aln = _align(body, ps)
            pairs, matches = [], 0
            for (a0, a1), (b0, b1) in zip(*aln.aligned):
                for k in range(a1 - a0):
                    pairs.append((a0 + k + 1, b0 + k + 1))
                    matches += body[a0 + k] == ps[b0 + k]
            ident = matches / max(len(body), len(ps))
    row["q_loc"] = str(nloc)
    row["n_aa"] = len(body)
    truncated = 0
    if stops:
        # internal stop: it may be real (read-through of a stop, e.g., opal in Sindbis or amber in TMV; nonsense
        # mutation) or a frame error (indel not a multiple of 3, RNA editing site). What precedes the stop is reliable:
        # it is annotated ONLY up to the stop (inclusive), if at least half of the NCBI protein remains.
        k0 = body.index("*")
        if k0 >= 0.5 * len(ps) and k0 >= 30:
            new = SeqFeature(trim_location(new.location, cs - 1 + 3 * (k0 + 1)), type="CDS", qualifiers=dict(new.qualifiers))
            nloc = new.location
            body, truncated, stops = body[:k0], len(ps) - k0, 0
            row["q_loc"], row["n_aa"] = str(nloc), len(body)
            aln = _align(body, ps[:k0 + 40])
            pairs, matches = [], 0
            for (a0, a1), (b0, b1) in zip(*aln.aligned):
                for k in range(a1 - a0):
                    pairs.append((a0 + k + 1, b0 + k + 1))
                    matches += body[a0 + k] == ps[b0 + k]
            ident = matches / len(body)
        else:
            row.update(status="discarded", reason=f"the protein of your sequence has an internal stop at aa {k0 + 1} of {len(ps)}: "
                                                   f"less than half of the protein remains, the reading frame is broken "
                                                   f"(indel not a multiple of 3 or frame incorrectly transferred)")
            return None, row, []
    if not body:
        row.update(status="discarded", reason="empty protein")
        return None, row, []
    row["identity"] = f"{ident:.3f}"
    if ident < min_identity:
        row.update(status="discarded", reason=f"the protein has only {100 * ident:.0f}% amino acid identity to the NCBI one "
                                               f"(threshold {100 * min_identity:.0f}%): misaligned or very different region?")
        return None, row, []
    notes = [f"annotation transferred from {srec.id}; protein identity with the NCBI one {100 * ident:.1f}%"]
    if src_exc:
        notes.append("the reference has an exception (" + ", ".join(src_exc) + "): it was checked in your sequence that the protein has no stops")
    if truncated:
        notes.append(f"truncated at aa {len(body) + 1}: internal stop in your sequence (read-through of a stop in the reference, nonsense mutation or frameshift); the following {truncated} aa are not annotated")
    if extended:
        notes.append(f"the CDS was extended {extended} aa beyond the end of the reference up to the first stop of your sequence")
    if closed:
        notes.append("the 1-2 nt gap between parts present in the reference was closed (your sequence does not need it)")
    if lost_first or lost_last:
        notes.append(f"partial: your sequence does not cover {lost_first} nt of the start and {lost_last} nt of the end of the CDS")
    if len(body) != len(ps):
        notes.append(f"length {len(body)} aa versus {len(ps)} aa in NCBI")
    inside = {p_: aa for p_, aa in exc_q.items() if any(int(pt.start) < p_ <= int(pt.end) for pt in new.location.parts)}
    if inside:
        new.qualifiers["transl_except"] = exc_qualifier(inside, strand)
    new.qualifiers["note"] = ["; ".join(notes + q.get("note", []))]
    row.update(status="transferred" if not (lost_first or lost_last or truncated) else ("transferred (truncated)" if truncated else "transferred (partial)"),
               reason="; ".join(notes[1:]))
    return new, row, pairs


def transfer_other(ft, s2q):
    """gene / mat_peptide / sig_peptide / UTR: only the coordinates are transferred."""
    parts = list(ft.location.parts)
    loc = []
    for p in parts:
        r = lift_part(int(p.start) + 1, int(p.end), s2q)
        if r is None:
            return None
        loc.append(FeatureLocation(r[0] - 1, r[1], strand=p.strand))
    new = SeqFeature(loc[0] if len(loc) == 1 else CompoundLocation(loc), type=ft.type)
    new.qualifiers = {k: v for k, v in ft.qualifiers.items() if k not in SKIP_QUALS}
    return new


def main_transfer_annotation():
    ap = argparse.ArgumentParser(description=TRANSFER_ANNOTATION_DOC, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--query", required=True, type=Path, help="FASTA (or GenBank) with YOUR sequence: consensus, lineage, assembly")
    ap.add_argument("--source", required=True, nargs="+", help="NCBI accession(s) or .gb of the ANNOTATED reference (one contig per segment)")
    ap.add_argument("--outdir", required=True, type=Path)
    ap.add_argument("--email"); ap.add_argument("--offline", action="store_true")
    ap.add_argument("--cache-dir", type=Path, default=None)
    ap.add_argument("--min-identity", type=float, default=0.6, help="minimum protein identity to accept a CDS (default 0.6)")
    ap.add_argument("--min-coverage", type=float, default=0.5, help="minimum fraction of your sequence aligned (default 0.5)")
    ap.add_argument("--minimap2", default=None)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    mm2 = find_minimap2(args.minimap2)

    fmt = "genbank" if args.query.suffix in (".gb", ".gbk") else "fasta"
    qrecs = list(SeqIO.parse(str(args.query), fmt))
    if not qrecs:
        fail(f"{args.query} contains no sequences", "the file is empty or is not FASTA/GenBank.", "Check the file.")
    srecs, _ = load_references([s for a in args.source for s in a.split(",") if s],
                                  args.cache_dir or (args.outdir / "gb_cache"), args.email, None, args.offline)
    for r in qrecs:
        r.seq = Seq(str(r.seq).upper())
        r.annotations["molecule_type"] = "DNA"

    out_recs, report, aamap, cmap = [], [], [], []
    for qrec in qrecs:
        best, s2q, q2s, cov = align_maps(qrec, srecs, mm2)
        srec = next(r for r in srecs if r.id == best)
        print(f"{qrec.id}: {len(qrec.seq)} nt  ↔  {best} ({len(srec.seq)} nt)  coverage {100 * cov:.1f}%")
        if cov < args.min_coverage:
            fail(f"of the positions of '{qrec.id}', only {100 * cov:.0f}% do align with {best}",
                    "the sequence is from another virus or is heavily rearranged.", "Check --source or lower --min-coverage.")
        out = SeqRecord(qrec.seq, id=qrec.id, name=qrec.id[:16],
                        description=f"{qrec.description}; annotation transferred from {srec.id}")
        out.annotations["molecule_type"] = "DNA"
        for p, s in enumerate(q2s[1:len(qrec.seq) + 1], 1):
            cmap.append((qrec.id, p, srec.id if s else "", s))
        for ft in srec.features:
            if ft.type == "CDS":
                if "pseudo" in ft.qualifiers or "pseudogene" in ft.qualifiers:
                    continue
                new, row, pairs = transfer_cds(ft, srec, qrec, s2q, args.min_identity)
                row["contig"] = qrec.id
                report.append(row)
                if new is None:
                    disclaimer(f"{qrec.id}: CDS '{row['cds']}' NOT transferred: {row['reason']}")
                    continue
                out.features.append(new)
                gname = row["cds"]
                for qa, sa in pairs:
                    aamap.append((qrec.id, gname, qa, srec.id, sa))
            elif ft.type in ("gene", "mat_peptide", "sig_peptide", "5'UTR", "3'UTR", "misc_feature", "stem_loop"):
                new = transfer_other(ft, s2q)
                if new is not None:
                    out.features.append(new)
        out.features.sort(key=lambda f: (int(f.location.start), -int(f.location.end)))
        out_recs.append(out)

    SeqIO.write(out_recs, args.outdir / "annotated.gb", "genbank")
    cols = ["contig", "cds", "product", "status", "n_aa", "identity", "src_loc", "q_loc", "reason"]
    with (args.outdir / "transfer_report.tsv").open("w") as fh:
        fh.write("\t".join(cols) + "\n")
        for r in report:
            fh.write("\t".join(str(r.get(c, "")) for c in cols) + "\n")
    with (args.outdir / "coord_map.tsv").open("w") as fh:
        fh.write("contig\tpos\tcanon_contig\tcanon_pos\n")
        for c in cmap:
            fh.write("\t".join(map(str, c)) + "\n")
    with (args.outdir / "aa_map.tsv").open("w") as fh:
        fh.write("contig\tgene\taa_idx\tcanon_contig\tcanon_aa_idx\n")
        for c in aamap:
            fh.write("\t".join(map(str, c)) + "\n")
    ok = sum(r["status"].startswith("transferred") for r in report)
    print(f"✔  CDSs transferred: {ok}/{len(report)}  → {args.outdir / 'annotated.gb'}")
    for r in report:
        print(f"   {r['status']:20s} {r['cds']:12s} {r['n_aa']:>5} aa  identity {r['identity'] or '–':>6}  {r['reason'][:70]}")


# ════════════════════════════════════════════════════════════════════════════════════════════════════
# Step 3 · integrity control
# ════════════════════════════════════════════════════════════════════════════════════════════════════
#!/usr/bin/env python3


MIN_FRACTION = 0.97          # = 29,000 / 29,903 of SARS-CoV-2, which was the fixed threshold in 1.x
MIN_POSITIONS = 29000        # only used in legacy mode (without --ref-dir)
DATE_FMT = "%d/%m/%y"


def parse_dmy(s):
    """[validation 2026-11-10, N14] dd/mm/yy as before, and also dd/mm/yyyy (written by `run` for years outside 2000-2068,
    where a 2-digit year could come back in the wrong century)."""
    s = s.strip()
    return datetime.strptime(s, "%d/%m/%Y" if len(s.rsplit("/", 1)[-1]) == 4 else DATE_FMT).date()


def format_dmy(d):
    """dd/mm/yy (unchanged output) when the 2-digit year reads back correctly, else dd/mm/yyyy."""
    return f"{d.day:02d}/{d.month:02d}/" + (f"{d.year % 100:02d}" if 2000 <= d.year <= 2068 else f"{d.year:04d}")

# Token regex: matches "-1", "-2", "-1a", "-2b", etc.
TOKEN_RE = re.compile(r"-(\d+)([a-z]?)$")

def parse_sample_id(filename):
    """Extract patient and token from filename like '007-A-1a_RG_readcount.txt'"""
    # Remove _RG_readcount.txt suffix
    stem = filename.replace("_RG_readcount.txt", "")
    # Extract token (e.g., "1a", "2b", "3")
    parts = stem.rsplit("-", 1)
    if len(parts) == 2:
        patient = parts[0]  # e.g., "007-A"
        token = parts[1]     # e.g., "1a"
        return patient, token
    return None, None

def count_positions(filepath):
    """Count number of positions in a readcount file"""
    count = 0
    try:
        with open(filepath, 'r') as f:
            for line in f:
                if line.strip():
                    fields = line.strip().split('\t')
                    if len(fields) >= 4:
                        try:
                            pos = int(fields[1])
                            count += 1
                        except ValueError:
                            continue
    except Exception as e:
        print(f"Error reading {filepath}: {e}", file=sys.stderr)
        return 0
    return count

def check_time_point_conflicts(patient_data, dates_tsv):
    """
    Check for time points with different tokens but sharing a date (1,2; not 1a, 1b).
    Returns True if patient passes the check, False otherwise.
    """
    # Group samples by date
    date_to_tokens = defaultdict(list)
    
    for sample_id, date_str in dates_tsv.items():
        if sample_id in patient_data:
            try:
                date = parse_dmy(date_str)
                token = patient_data[sample_id]['token']
                # Extract numeric part of token (1 from "1a", 2 from "2", etc.)
                match = TOKEN_RE.search(f"-{token}")
                if match:
                    numeric_token = match.group(1)
                    # Only check tokens without letter suffix (1, 2, 3, not 1a, 1b)
                    if not match.group(2):  # No letter suffix
                        date_to_tokens[date].append((numeric_token, token, sample_id))
            except (ValueError, KeyError):
                continue
    
    # Check for conflicts: same date, different numeric tokens
    conflicts = []
    for date, token_list in date_to_tokens.items():
        numeric_tokens = set([t[0] for t in token_list])
        if len(numeric_tokens) > 1:
            conflicts.append((date, token_list))
    
    return len(conflicts) == 0, conflicts

def main_integrity():
    global MIN_POSITIONS
    ap = argparse.ArgumentParser(description="Integrity control (step 3)")
    ap.add_argument("--input-dir", type=Path, default=Path("processing/02_rc"))
    ap.add_argument("--output-dir", type=Path, default=Path("processing/03_integrity_checked"))
    ap.add_argument("--dates", type=Path, default=Path("dates.tsv"))
    ap.add_argument("--ref-dir", type=Path, default=None,
                    help="folder of srasel prepare-reference: the threshold is computed on its total length")
    ap.add_argument("--min-fraction", type=float, default=MIN_FRACTION,
                    help="minimum fraction of reference positions covered (default %(default)s)")
    args = ap.parse_args()
    input_dir, output_dir, dates_file = args.input_dir, args.output_dir, args.dates

    if args.ref_dir:
        total = sum(c["length"] for c in read_contigs(args.ref_dir / "contigs.tsv"))
        MIN_POSITIONS = int(args.min_fraction * total)
        print(f"Position threshold: {MIN_POSITIONS} = {args.min_fraction:.0%} of {total} nt of the reference")
    else:
        disclaimer(f"Without --ref-dir: the fixed SRASel 1.x threshold is used ({MIN_POSITIONS} positions), "
                      "designed for SARS-CoV-2. With another virus ALL samples will be flagged as "
                      "'few positions' even if they are fine; pass --ref-dir.")
    
    # Read dates.tsv
    dates_tsv = {}
    try:
        with open(dates_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line:
                    parts = line.split('\t')
                    if len(parts) >= 2:
                        sample_id = parts[0]
                        date_str = parts[1]
                        dates_tsv[sample_id] = date_str
    except Exception as e:
        print(f"Error reading dates.tsv: {e}", file=sys.stderr)
        sys.exit(1)
    
    # Group files by patient
    patient_files = defaultdict(dict)
    
    for rc_file in sorted(input_dir.glob("*_readcount.txt")):
        patient, token = parse_sample_id(rc_file.name)
        if not patient or not token:
            print(f"Warning: Could not parse sample ID from {rc_file.name}", file=sys.stderr)
            continue
        
        # Remove _RG_readcount.txt suffix to get sample_id
        # Sample IDs in dates.tsv don't have _RG suffix
        sample_id_base = rc_file.name.replace("_RG_readcount.txt", "")
        sample_id_clean = sample_id_base.replace("_RG", "") if sample_id_base.endswith("_RG") else sample_id_base
        
        patient_files[patient][sample_id_clean] = {
            'filepath': rc_file,
            'token': token,
            'sample_id_for_file': sample_id_base  # Keep original for file naming
        }
    
    # Create output directory
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Statistics
    all_patients = []
    patients_with_issues = []
    total_samples_checked = 0
    total_samples_passed = 0
    total_samples_failed = 0
    
    # Process each patient
    for patient, samples in sorted(patient_files.items()):
        patient_dir = output_dir / patient
        patient_dir.mkdir(exist_ok=True)
        
        patient_issues = []
        failed_samples = []
        passed_samples = []
        
        # Check each sample for minimum positions
        for sample_id, data in samples.items():
            total_samples_checked += 1
            positions = count_positions(data['filepath'])
            
            if positions < MIN_POSITIONS:
                issue_msg = f"{sample_id}: Only {positions} positions (< {MIN_POSITIONS})"
                print(f"⚠️  {patient}/{issue_msg}", file=sys.stderr)
                patient_issues.append(issue_msg)
                failed_samples.append((sample_id, f"positions={positions}"))
                total_samples_failed += 1
            else:
                passed_samples.append(sample_id)
                total_samples_passed += 1
        
        # [validation 2026-11-10, N8] replicates (1a, 1b…) are pooled as ONE time point by build-tables, at the date of the last one read:
        # if they carry different dates, the reads of one date would be analysed at another, silently. Stop instead.
        rep_dates = defaultdict(set)
        for sid, data in samples.items():
            m = TOKEN_RE.search(f"-{data['token']}")
            if m and m.group(2) and sid in dates_tsv:
                rep_dates[m.group(1)].add(dates_tsv[sid].strip())
        bad = {k: v for k, v in rep_dates.items() if len(v) > 1}
        if bad:
            k, v = next(iter(sorted(bad.items())))
            fail(f"{patient}: the replicates of time point {k} ({k}a, {k}b…) have different dates: {', '.join(sorted(v))}",
                 "samples named <patient>-<n>a / <n>b are same-day replicates and are pooled into one time point.",
                 "give them the same date, or number them as different time points (<patient>-<n>, <patient>-<n+1>)")
        # Check time point conflicts (check all samples, not just passed ones)
        no_conflicts, conflicts = check_time_point_conflicts(
            {sid: data for sid, data in samples.items()},
            dates_tsv
        )
        
        if not no_conflicts:
            conflict_details = []
            for date, token_list in conflicts:
                tokens_str = ", ".join([f"{t[1]} ({t[0]})" for t in token_list])
                conflict_details.append(f"Date {date}: {tokens_str}")
                print(f"⚠️  {patient}: Time point conflicts detected:", file=sys.stderr)
                print(f"   Date {date}: {tokens_str}", file=sys.stderr)
            issue_msg = f"Time point conflicts: {'; '.join(conflict_details)}"
            patient_issues.append(issue_msg)
        
        # Always copy ALL samples to output directory (even if there are issues)
        all_sample_ids = sorted(samples.keys())
        
        if all_sample_ids:
            # Create .time file for this patient (with ALL samples)
            time_file = patient_dir / f"{patient}.time"
            with open(time_file, 'w') as tf:
                for sample_id in all_sample_ids:
                    if sample_id in dates_tsv:
                        tf.write(f"{sample_id}\t{dates_tsv[sample_id]}\n")
            
            # Copy and rename readcount files (ALL samples, including failed ones)
            for sample_id in all_sample_ids:
                if sample_id in samples:
                    source = samples[sample_id]['filepath']
                    # Use sample_id for file naming (without _RG if present)
                    # srasel build-tables expects files named like: sample_id.readcounts.tsv
                    dest = patient_dir / f"{sample_id}.readcounts.tsv"
                    shutil.copy2(source, dest)
            
            all_patients.append(patient)
            if patient_issues:
                patients_with_issues.append((patient, patient_issues, len(passed_samples), len(failed_samples)))
                print(f"⚠️  {patient}: {len(passed_samples)} samples passed, {len(failed_samples)} failed - ISSUES DETECTED (all samples copied)")
            else:
                print(f"✔ {patient}: {len(passed_samples)} samples passed (no issues, all samples copied)")
        else:
            # Patient has no samples (shouldn't happen)
            all_patients.append(patient)
            patients_with_issues.append((patient, patient_issues, 0, len(failed_samples)))
            print(f"❌ {patient}: No samples found", file=sys.stderr)
    
    # Summary
    print(f"\n{'='*60}")
    print(f"Summary:")
    print(f"  Total samples checked: {total_samples_checked}")
    print(f"  Total samples passed: {total_samples_passed}")
    print(f"  Total samples failed: {total_samples_failed}")
    print(f"  Total patients processed: {len(all_patients)}")
    print(f"  Patients with issues: {len(patients_with_issues)}")
    print(f"  Patients without issues: {len(all_patients) - len(patients_with_issues)}")
    print(f"{'='*60}")
    
    if patients_with_issues:
        print(f"\n⚠️  Patients with issues detected:")
        print(f"{'='*60}")
        for patient, issues, passed_count, failed_count in patients_with_issues:
            print(f"\n  Patient: {patient}")
            print(f"    Samples passed: {passed_count}")
            print(f"    Samples failed: {failed_count}")
            print(f"    Issues ({len(issues)}):")
            for issue in issues:
                print(f"      - {issue}")
        print(f"\n{'='*60}")


# ════════════════════════════════════════════════════════════════════════════════════════════════════
# Step 4 · position × time matrices
# ════════════════════════════════════════════════════════════════════════════════════════════════════
#!/usr/bin/env python3


# ───────────────────────── helpers ──────────────────────────────
PLUS_RE  = re.compile(r"^\+([A-Z]+):(\d+)")
MINUS_RE = re.compile(r"^-([A-Z]+):(\d+)")
BASES    = "ACTGN"


def parse_time_file(tfile: Path):
    """
    Return:
        id2date   dict{sample_id→date}
        id2token  dict{sample_id→token}
        tokens_in_order  list of tokens as they appear (unique, keep first)
    """
    id2date, id2token = {}, {}
    tokens_order, seen = [], set()
    with tfile.open() as fh:
        for line in fh:                      # ─── clean NULL bytes ───
            if line.strip():
                sid_raw, d = line.rstrip().split("\t")
                sid   = sid_raw.replace('\x00', '')
                token = sid.rsplit("-", 1)[1]
                id2date[sid]  = parse_dmy(d)
                id2token[sid] = token
                if token not in seen:
                    tokens_order.append(token)
                    seen.add(token)
    return id2date, id2token, tokens_order


def earliest_day0(id2date, id2token):
    t1_dates = []
    for sid, dt in id2date.items():
        m = TOKEN_RE.search(id2token[sid])
        if m and m.group(1) == "1":
            t1_dates.append(dt)
    # if there is no “1”, take the earliest date of all
    return min(t1_dates) if t1_dates else min(id2date.values())


def parse_readcount_line(fields):
    """Return depth, dict{base:count}, list(+), list(-) for ONE position."""
    depth = int(fields[3])
    ref_base = fields[2] if fields[2] in BASES else "N"   # CHANGE 2026-11-03: ambiguous reference base (M, Y, R…) → N; previously KeyError (OBSERVATIONS_ORIGINAL.md, no. 9)
    counts = {b: 0 for b in BASES}
    plus, minus = [], []

    for token in fields[4:]:
        if token.startswith("="):                # reference matches
            n = int(token.split(":")[1])
            counts[ref_base] += n
        elif token[0] in BASES:                  # A:…, C:…, …
            base = token[0]
            n = int(token.split(":")[1])
            counts[base] += n
        elif token.startswith("+"):
            m = PLUS_RE.match(token)
            if m: plus.append(f"+{m.group(1)}{m.group(2)}")
        elif token.startswith("-"):
            m = MINUS_RE.match(token)
            if m: minus.append(f"-{m.group(1)}{m.group(2)}")
    return depth, counts, plus, minus


def load_reference(ref_dir, contigs_path, fasta_path):
    """(contigs, {contig: secuencia}) or (None, None) if no reference was given."""
    if ref_dir:
        contigs_path = contigs_path or Path(ref_dir) / "contigs.tsv"
        fasta_path = fasta_path or Path(ref_dir) / "reference.fna"
    if not contigs_path:
        return None, None
    contigs = read_contigs(Path(contigs_path))
    seqs = {}
    if fasta_path and Path(fasta_path).is_file():
        from Bio import SeqIO
        seqs = {r.id: str(r.seq).upper() for r in SeqIO.parse(str(fasta_path), "fasta")}
    else:
        disclaimer("reference.fna not found: it will NOT be checked that the reference base of "
                      "bam-readcount matches the annotation (risk of annotating with wrong "
                      "coordinates without noticing).")
    return contigs, seqs


# ───────────────────────── main ─────────────────────────────────
def main_build_tables(pdir: Path, contigs, seqs, alias, max_mismatch):
    # 1· sanity & I/O paths
    if not pdir.is_dir():
        raise SystemExit(f"❌  {pdir} is not a directory")
    time_file = next(pdir.glob("*.time"), None)
    if not time_file:
        raise SystemExit("❌  No *.time file found in the directory")

    # 2· load dates & tokens
    id2date, id2token, tokens = parse_time_file(time_file)
    day0 = earliest_day0(id2date, id2token)

    # 3· find readcount files we actually have
    #     stem → "009A-A-1.readcounts",  we also need to strip ".readcounts"
    rc_files = {}
    for f in pdir.glob("*.readcounts.tsv"):
        sid = re.sub(r"\.readcounts$", "", f.stem).replace('\x00', '')
        rc_files[sid] = f

    if not rc_files:
        raise SystemExit("❌  No *.readcounts.tsv files found")

    # 4· matrix: pos_global → token → code
    matrix = defaultdict(dict)
    legacy = contigs is None
    if legacy:
        disclaimer("Without --ref-dir/--contigs: legacy mode (a single contig, positions as is). "
                      "The reference is not checked. If the readcount has more than one contig, it will abort.")
    ref_checked = ref_bad = 0

    for sid, fpath in rc_files.items():
        token = id2token.get(sid)
        if not token:                # sample without date/token – skip
            continue
        days = (id2date[sid] - day0).days

        chrom_map = {}               # chrom of the readcount → reference contig (or "legacy")
        f_checked = f_bad = 0
        with fpath.open(errors="ignore") as fh:
            tsv = csv.reader(fh, delimiter="\t")
            for row in tsv:
                if not row:
                    continue
                # clean NULs in each field
                row = [c.replace('\x00', '') for c in row]
                try:
                    pos = int(row[1])
                except ValueError:
                    continue                 # malformed line

                chrom = row[0]
                if chrom not in chrom_map:
                    if legacy:
                        chrom_map[chrom] = None
                        if len(chrom_map) > 1:
                            fail(f"{fpath.name} contains more than one contig: {sorted(chrom_map)}",
                                    "without a reference, SRASel cannot know at which global position "
                                    "each contig goes; it would write the segments in the same rows and "
                                    "they would overwrite each other.",
                                    "Run srasel prepare-reference with one accession per segment and pass "
                                    "--ref-dir reference.")
                    else:
                        c = resolve_contig(chrom, contigs, alias)
                        if c is None and len(contigs) == 1:
                            c = contigs[0]
                            disclaimer(f"The readcount contig ('{chrom}') is not named like the "
                                          f"reference ('{c['contig']}'); it is assumed to be the same because "
                                          "there is only one contig. The base-by-base comparison will confirm it.")
                        if c is None:
                            fail(f"Contig '{chrom}' of {fpath.name} is not in the reference",
                                    f"the reference only has: {[k['contig'] for k in contigs]}.",
                                    "Align against reference/reference.fna, or map the name with "
                                    f"--alias {chrom}=<contig>.")
                        chrom_map[chrom] = c
                        if len(contigs) == 1 and len(chrom_map) > 1:
                            fail(f"{fpath.name} has several contigs ({sorted(chrom_map)}) but the "
                                    "reference has only one",
                                    "it cannot be decided which one each corresponds to.",
                                    "Prepare the reference with all segments (--refs a b c).")
                c = chrom_map[chrom]
                if c is not None:
                    if pos < 1 or pos > c["length"]:
                        fail(f"Position {pos} outside {c['contig']} (length {c['length']}) in {fpath.name}",
                                "the reads were aligned against a reference different from the one prepared.",
                                "Use the same reference to align and to prepare (reference.fna).")
                    gpos = to_global(c, pos)
                    ref_seq = seqs.get(c["contig"]) if seqs else None
                    if ref_seq is not None:
                        rb = row[2].upper()
                        if rb != "N" and ref_seq[pos - 1] != "N":
                            f_checked += 1
                            if rb != ref_seq[pos - 1]:
                                f_bad += 1
                else:
                    gpos = pos
                depth, counts, plus, minus = parse_readcount_line(row)

                code = (
                    f"{days}/{depth}/"
                    f"A{counts['A']}C{counts['C']}T{counts['T']}"
                    f"G{counts['G']}N{counts['N']}/"
                    f"{''.join(plus) if plus else '+0'}"
                    f"{''.join(minus) if minus else '-0'}"
                )
                matrix[gpos][token] = code

        ref_checked += f_checked
        ref_bad += f_bad
        if f_checked and f_bad / f_checked > max_mismatch:
            fail(f"{fpath.name}: reference base does not match at {f_bad}/{f_checked} positions "
                    f"({100*f_bad/f_checked:.1f}% > {100*max_mismatch:.1f}%)",
                    "the bam-readcount output was generated with a reference different from reference.fna "
                    "(another strain, another numbering, or even another virus). The gene/codon annotations "
                    "would fall on the wrong positions.",
                    "Realign against reference/reference.fna, or regenerate the reference with the "
                    "correct accession. If the difference is real (different strain), raise --max-ref-mismatch.")
        elif f_bad:
            disclaimer(f"{fpath.name}: {f_bad}/{f_checked} positions with a different reference base "
                          "(below the threshold): strain differences; the annotation may contain "
                          "substitutions relative to the reference, which is normal.")

    # 6· write output
    out = pdir / f"{pdir.name}.tsv"
    with out.open("w", newline="") as fh:
        wr = csv.writer(fh, delimiter="\t")
        wr.writerow(["position"] + tokens)
        for pos in sorted(matrix):
            row = [matrix[pos].get(tok, "NA") for tok in tokens]
            wr.writerow([pos] + row)

    msg = (f"✔  Wrote {out}  ({len(matrix)} positions × {len(tokens)} time-points)")
    if not legacy:
        msg += f"  [{len(contigs)} contig(s); ref-check {ref_checked-ref_bad}/{ref_checked} ok]"
    print(msg)


# ───────────────────────── runner ───────────────────────────────


def cli_build_tables():
    ap = argparse.ArgumentParser(description="Build position×time matrix for one patient")
    ap.add_argument("patient_dir", type=Path, help="Path to patient folder")
    ap.add_argument("--ref-dir", type=Path, default=None,
                    help="folder created by srasel prepare-reference (contigs.tsv + reference.fna)")
    ap.add_argument("--contigs", type=Path, default=None, help="contigs.tsv (alternative to --ref-dir)")
    ap.add_argument("--fasta", type=Path, default=None, help="reference.fna (alternative to --ref-dir)")
    ap.add_argument("--alias", action="append", default=[], metavar="CHROM=CONTIG",
                    help="map a contig name from the bam-readcount output to one from the reference (repeatable)")
    ap.add_argument("--max-ref-mismatch", type=float, default=0.01,
                    help="maximum fraction of positions with a different reference base (default 0.01)")
    args = ap.parse_args()
    alias = dict(a.split("=", 1) for a in args.alias)
    contigs, seqs = load_reference(args.ref_dir, args.contigs, args.fasta)
    main_build_tables(args.patient_dir, contigs, seqs, alias, args.max_ref_mismatch)


# ════════════════════════════════════════════════════════════════════════════════════════════════════
# Step 5 · table annotation (gene, codon, amino acid)
# ════════════════════════════════════════════════════════════════════════════════════════════════════
#!/usr/bin/env python3



def load_model(args):
    """(contigs, global_pos → [annotations]) from --ref-dir or --gb."""
    if args.ref_dir:
        gb = args.ref_dir / "references.gb"
        if not gb.is_file():
            fail(f"Not found: {gb}", "step 0 is missing.",
                    "Run: srasel prepare-reference --refs <accession(s)> --email <email> --outdir reference")
        records, _ = load_references([str(gb)], args.ref_dir / "gb_cache", None, offline=True)
        contigs = read_contigs(args.ref_dir / "contigs.tsv")
        # consistency: the order/offsets of contigs.tsv must be those of references.gb
        if [c["contig"] for c in contigs] != [r.id for r in records]:
            fail("contigs.tsv and references.gb do not have the same contigs/order",
                    "one of the two was edited by hand or they come from different runs.",
                    "Run srasel prepare-reference again.")
    else:
        records, _ = load_references(args.gb, Path(".gb_cache"), None, offline=True)
        if len(records) > 1:
            fail(f"--gb contains {len(records)} contigs",
                    "without --ref-dir, step 4 could not assign global positions per contig.",
                    "Use srasel prepare-reference + --ref-dir for segmented viruses.")
        contigs = assign_offsets(records)
        disclaimer("--gb mode: it cannot be checked that the GenBank record corresponds to the reference "
                      "the reads were aligned to (step 4 does this with --ref-dir).")
    models = {}
    for rec in records:
        models[rec.id] = build_cds_models(rec)
    ann = position_annotations(models, contigs)
    bad = [m.cds_id for ms in models.values() for m in ms if m.status == "MISMATCH"]
    n_multi = sum(1 for v in ann.values() if len(v) > 1)
    print(f"Annotation: {len(contigs)} contig(s), {sum(len(v) for v in models.values())} CDS, "
          f"{len(ann)} coding positions ({n_multi} with more than one possible reading).",
          file=sys.stderr)
    if bad:
        disclaimer(f"{len(bad)} CDS do NOT validate against the NCBI /translation: {bad}. "
                      "Their amino acids are not reliable (see srasel prepare-reference / cds_model.tsv).")
    return contigs, ann


def annotate_tsv(tsv_path: Path, contigs, ann, out_dir: Path = None):
    """Write <patient>_genes.tsv with the annotation columns."""
    out_path = (out_dir or tsv_path.parent) / f"{tsv_path.stem}_genes.tsv"
    total = contigs[-1]["offset"] + contigs[-1]["length"]
    n_rows = n_cod = n_out = 0

    with tsv_path.open() as fin, out_path.open("w", newline="") as fout:
        rd = csv.reader(fin, delimiter="\t")
        wr = csv.writer(fout, delimiter="\t")

        header = next(rd)
        wr.writerow([header[0], "gene", "codon_pos", "aa_idx", "contig", "contig_pos",
                     "cds_codons", *header[1:]])

        for row in rd:
            try:
                pos = int(row[0])
            except ValueError:
                wr.writerow([row[0], "", "", "", "", "", "", *row[1:]])  # keep malformed lines
                continue
            n_rows += 1
            contig, cpos = from_global(pos, contigs)
            if contig is None:
                n_out += 1
                contig, cpos = "", ""
            a = ann.get(pos, [])
            if a:
                n_cod += 1
                gene, cp, aa = legacy_columns(a)
                wr.writerow([row[0], gene, cp, aa, contig, cpos, encode_annots(a), *row[1:]])
            else:
                wr.writerow([row[0], "", "", "", contig, cpos, "", *row[1:]])
    if n_out:
        fail(f"{tsv_path.name}: {n_out} positions outside all contigs (global max {total})",
                "the matrix was built with a different reference from the one being used for annotation.",
                "Rebuild step 4 with --ref-dir (same reference/ as here).")
    return out_path, n_rows, n_cod


def main_annotate():
    ap = argparse.ArgumentParser(description="Add gene/codon/CDS information to patient mutation tables")
    ap.add_argument("--tsv-dir", default="tsv_time_sets", type=Path,
                    help="Directory containing the <patient>.tsv files")
    ap.add_argument("--ref-dir", type=Path, default=None, help="folder from srasel prepare-reference")
    ap.add_argument("--gb", nargs="+", default=None,
                    help="standalone alternative to --ref-dir: local GenBank file(s) (single contig)")
    ap.add_argument("--out-dir", type=Path, default=None, help="where to write the *_genes.tsv files (default: --tsv-dir)")
    args = ap.parse_args()

    if not args.ref_dir and not args.gb:
        fail("No reference was given", "it is necessary to know how the genome is read.",
                "Pass --ref-dir reference (recommended) or --gb file.gb")
    if not args.tsv_dir.is_dir():
        sys.exit(f"❌  TSV directory not found: {args.tsv_dir}")

    contigs, ann = load_model(args)
    tsv_files = sorted(p for p in args.tsv_dir.glob("*.tsv") if not p.name.endswith("_genes.tsv"))
    if not tsv_files:
        sys.exit("❌  No *.tsv files found to annotate.")
    if args.out_dir:
        args.out_dir.mkdir(parents=True, exist_ok=True)
    for tsv in tsv_files:
        out, n, ncod = annotate_tsv(tsv, contigs, ann, args.out_dir)
        print(f"✔  {out.name} written ({n} positions, {ncod} coding)")


# ════════════════════════════════════════════════════════════════════════════════════════════════════
# Step 6 · SRASel statistical analysis
# ════════════════════════════════════════════════════════════════════════════════════════════════════
#!/usr/bin/env python3
# -*- coding: utf-8 -*-




SRASEL_TOKEN_RE = re.compile(r"^(\d+)")
AA_RE = re.compile(r"^([A-Z\*\?]+)(\d+)(?:\([^)]*\))?$|^(\d+)([A-Z\*\?]+)(?:\([^)]*\))?$|^(\d+)(amb)(?:\([^)]*\))?$|^(amb)(\d+)(?:\([^)]*\))?$")

# Translation tables: there is NO longer a fixed SARS-CoV-2 table. Each annotation carries the
# /transl_table of its CDS (NCBI) and sg.translate_codon() uses that table.
CODON2AA = codon_table(1)     # only for compatibility with old code (standard table)

# ───────────────────── single final report helper ─────────────────────

def load_contig_maps(tsv_path):
    """global_pos → contig / position within the contig (segmented viruses). Empty if there are no columns."""
    hdr = pd.read_csv(tsv_path, sep="\t", nrows=0).columns
    if "contig" not in hdr:
        return {}, {}
    # keep_default_na=False: pandas would read the gene 'NA' (influenza neuraminidase) as a null value
    d = pd.read_csv(tsv_path, sep="\t", usecols=["position", "contig", "contig_pos"],
                    dtype={"contig": str}, keep_default_na=False)
    return dict(zip(d["position"], d["contig"])), dict(zip(d["position"], d["contig_pos"]))


def add_contig_cols(df, contig_of, cpos_of):
    """Insert 'contig' and 'contig_pos' right after 'pos' (pos is the GLOBAL position)."""
    if not contig_of or "pos" not in df.columns or "contig" in df.columns:
        return df
    df = df.copy()
    i = df.columns.get_loc("pos") + 1
    df.insert(i, "contig", df["pos"].map(contig_of))
    df.insert(i + 1, "contig_pos", df["pos"].map(cpos_of))
    return df


def build_final_report_text(patient: str,
                            sigma: int = 350,
                            nperm: int = 2000,
                            freq_delta: float = 0.03,
                            thr_clear: float = 0.95,
                            eps_tie: float = 0.05,
                            depth_any: int = 100) -> str:
    """
    Returns a single multi-line string that documents, in English (Nature-like),
    all figures and tables produced for a given patient/run, with precise definitions.
    """
    return f"""
[REPORT — {patient}]

FIGURES
1) Genome-wide selection landscape (file: {patient}_genome_selection.pdf).
   This figure summarizes selection across the genome. Points mark labeled trajectories by genomic
   coordinate (x-axis) and weighted slope β (y-axis; time in days). Here β quantifies the per-day
   change in variant frequency f = k/n estimated by weighted least squares (WLS) regression of f on day t
   with weights w = n (read depth). Specifically:
       β = Sxy / Sxx,  where
       Sxy = Σ w_i (t_i − t̄_w)(f_i − f̄_w),   Sxx = Σ w_i (t_i − t̄_w)^2,
       t̄_w = (Σ w_i t_i) / (Σ w_i),          f̄_w = (Σ w_i f_i) / (Σ w_i).
   Variants are labeled ‘pos’ if p < 0.05 and β > 0, or ‘neg’ if p < 0.05 and β < 0. The p-values are
   obtained by a permutation test that shuffles the sampling days within each trajectory (n = {nperm} permutations).
   The right axis shows kernel-smoothed densities (Gaussian, σ = {sigma}) of selected positions, plotted upward for β > 0 (red)
   and downward for β < 0 (blue). Dashed horizontal lines denote neutral baselines: β̄_all (grey; all variants)
   and β̄_sel (black; only labeled variants). A colored bar above the x-axis delineates coding-sequence spans by gene.

2) Per-position temporal trajectories (files: {patient}_plots/posXXXXX_ALL.pdf).
   For each genomic position with at least one labeled trajectory, the panel displays the observed frequencies (points)
   across days for every (pos, var). Colored solid lines are WLS fits for labeled trajectories (β > 0, red; β < 0, blue);
   unlabeled trajectories are shown in light grey dashed. Each fit is drawn in its WLS form, i.e., a straight line
   with slope β that passes through the weighted means (t̄_w, f̄_w), which exactly represents the WLS solution without
   explicitly estimating an intercept. For context, genome-wide neutral reference lines are shown: β̄_all (grey) and β̄_sel (black).

TABLES
1) {patient}_long.tsv
   Long-format counts per (position, variant, day). Columns:
     pos, var, day, k (reads supporting the variant), n (total depth).
   Variants include nucleotides (A/C/G/T/N) and aggregated indels (INS, DEL).
   Rows are retained only for (pos, var) pairs that reach total depth ≥ {depth_any} on at least one day.

2) {patient}_variant_stats.tsv
   Per-(position, variant) statistics after a minimum temporal-change filter Δf ≥ {freq_delta:.3f},
   where Δf is computed from the fitted slope as Δf = β · (max(day) − min(day)).
   β is the WLS slope as defined above (weights w = n). Permutation p-values (n = {nperm}) are obtained by shuffling days
   within each trajectory; a trajectory is labeled ‘pos’ if p < 0.05 and β > 0, or ‘neg’ if p < 0.05 and β < 0.
   The score is |β| · (−log10 p) with the sign of β. Amino-acid annotation builds a codon by forcing the focal base at the
   position and choosing “clear” neighbors (frequency ≥ {thr_clear:.2f}) that differ from the focal position’s top frequency
   by more than {eps_tie:.2f}; ambiguity is reported as ‘ambiguous’ or ‘ambiguous (indel)’. Columns:
     gene, aa_gene (CDS to which aa_idx/aa_change refer), aa_idx, pos, [contig, contig_pos], var, beta, pval, score, tag, delta_f, codon, aa_change,
     ambiguous, other_frames (effect in the other overlapping reading frames), annot_detail,
     depth (mean n), n_days, and JSON arrays for day, k, n.

3) {patient}_selected_ranked.tsv
   Ranked list of labeled variants (tag ∈ {{pos, neg}}), sorted by descending absolute score (|β| · −log10 p, signed by β).
   Provides a concise prioritization of trajectories for follow-up.

""".strip()

# ───────── Covariation (selected variants only, at the end) ─────────
def _compute_covariation_annotations_selected(
    ranked_pre: pd.DataFrame,
    method: str = "beta_diff",
    threshold: float = 0.01,
    min_days: int = 3,
    min_range: float = 0.05,
    max_day_diff: int = 1,
    first_k_min: int = 10
) -> pd.DataFrame:
    """
    Compute co-variation among SELECTED variants (tag in {'pos','neg'}) within a patient.
    METHOD: Compares beta values directly (not frequency correlation).
    Two variants covary if:
      1) |beta₁ - beta₂| ≤ threshold
      2) |start_day₁ - start_day₂| ≤ max_day_diff (they appear at similar times)
    
    Returns a DataFrame with columns:
        - pos, var
        - covarying (bool)
        - covarying_count (int)
        - covarying_with (str): formatted list of partners it co-varies with, including diff_beta and diff_day.
          Format per partner: nt=<pos>(<var>); aa=<gene>:<aa_change> [Δβ=0.xx, Δday=X]
    """
    if ranked_pre is None or ranked_pre.empty:
        return pd.DataFrame(columns=["pos","var","covarying","covarying_count","covarying_with"])

    # We work only with selected variants
    sel = ranked_pre[ ranked_pre["tag"].isin(["pos","neg"]) ].copy()
    print(f"🔍 Selected variants found: {len(sel)}")
    if sel.empty:
        print("⚠️  No selected variants for covariation analysis")
        return pd.DataFrame(columns=["pos","var","covarying","covarying_count","covarying_with"])

    # Metadata index by token
    # token = (pos:int, var:str)
    def _first_nonempty(row: pd.Series, keys: List[str]) -> Optional[str]:
        for k in keys:
            if k in row and pd.notna(row[k]) and str(row[k]).strip() != "":
                return str(row[k])
        return None

    meta_index: Dict[Tuple[int,str], Dict[str, Optional[str]]] = {}
    beta_dict: Dict[Tuple[int,str], float] = {}
    first_day_dict: Dict[Tuple[int,str], int] = {}
    
    for _, r in sel.iterrows():
        tok = (int(r["pos"]), r["var"])
        if tok in meta_index:
            continue
        meta_index[tok] = {
            "gene": _first_nonempty(r, ["gene","region","protein","prot"]),
            "aa_change": _first_nonempty(r, ["aa_change","aa","aa_change_str"]),
            "aa_pos": _first_nonempty(r, ["aa_pos","aa_position","aapos"]),
            "var_nt": _first_nonempty(r, ["var","nt_var","nt_change"]),
        }
        beta_dict[tok] = float(r["beta"])
        
        # Start day = first day with at least first_k_min reads (days are zero-filled, so the earliest listed day is just the first covered day).
        # If the table has no usable list "k", or no day reaches the minimum, the first listed day is used.
        if "day" in r and isinstance(r["day"], (list, tuple)) and len(r["day"]) > 0:
            ks = r["k"] if "k" in r and isinstance(r["k"], (list, tuple)) and len(r["k"]) == len(r["day"]) else None
            seen = [d for d, kk in zip(r["day"], ks) if kk >= first_k_min] if ks is not None else []
            first_day_dict[tok] = int(min(seen if seen else r["day"]))
        else:
            first_day_dict[tok] = 0  # If there is no data, assume day 0

    def _fmt_partner(tok: Tuple[int,str], diff_beta: float, diff_day: int) -> str:
        pos, var = tok
        m = meta_index.get(tok, {})
        nt_var = m.get("var_nt") or str(var) or ""
        nt_part = f"nt={pos}" + (f"({nt_var})" if nt_var and nt_var != str(pos) else "")
        gene = m.get("gene") or "NA"
        aa_change = (m.get("aa_change") or "").strip()
        aa_pos = (m.get("aa_pos") or "").strip()
        if aa_change and aa_change.lower() != "nan":
            aa_part = f"aa={gene}:{aa_change}"
        elif aa_pos and aa_pos.lower() != "nan":
            aa_part = f"aa={gene}:{aa_pos}"
        else:
            aa_part = f"aa={gene}"
        return f"{nt_part}; {aa_part} [Δβ={diff_beta:.4f}, Δday={diff_day}]"

    # Comparison of betas AND timing across all variants
    print(f"🔍 Analyzing covariation by β similarity (threshold: Δβ ≤ {threshold}, Δday ≤ {max_day_diff})...")
    print(f"📊 Variants to analyze: {len(beta_dict)}")
    
    out_rows = []
    covarying_found = 0
    
    for tok1 in beta_dict.keys():
        beta1 = beta_dict[tok1]
        day1 = first_day_dict[tok1]
        partners = []
        
        # Compare with all the other variants
        for tok2 in beta_dict.keys():
            if tok1 == tok2:  # Do not compare with itself
                continue
            
            beta2 = beta_dict[tok2]
            day2 = first_day_dict[tok2]
            
            diff_beta = abs(beta1 - beta2)
            diff_day = abs(day1 - day2)
            
            # Covariation if BOTH criteria are met:
            # 1) Similar beta
            # 2) Similar temporal onset
            if diff_beta <= threshold and diff_day <= max_day_diff:
                partners.append((tok2, diff_beta, diff_day))
        
        # Format partners
        partners_fmt = [_fmt_partner(tok, diff_b, diff_d) for tok, diff_b, diff_d in partners]
        
        is_covarying = bool(partners)
        if is_covarying:
            covarying_found += 1
            if covarying_found <= 3:  # Debug for the first 3
                print(f"  Covariation {covarying_found}: {tok1} with {len(partners)} partners (β={beta1:.4f}, start_day={day1})")
        
        out_rows.append({
            "pos": tok1[0],
            "var": tok1[1],
            "covarying": is_covarying,
            "covarying_count": int(len(partners)),
            "covarying_with": " | ".join(partners_fmt) if partners_fmt else ""
        })

    print(f"📊 Covariations found: {covarying_found} of {len(beta_dict)} variants")
    return pd.DataFrame(out_rows)

# ───────────── helpers ─────────────────────────────────────────
def split_cell(cell: str):
    if cell == "NA":
        return None
    days, depth, bases, indels = cell.split("/", 3)
    days, depth = int(days), int(depth)
    counts = {m.group(1): int(m.group(2))
              for m in re.finditer(r"([ACTGN])(\d+)", bases)}
    # Extract insertions as a dictionary {secuencia: count}
    ins_dict = {m.group(1): int(m.group(2)) 
                for m in re.finditer(r"\+([A-Z]+)(\d+)", "+"+indels)}
    # Extract deletions as a dictionary {secuencia: count}
    dels_dict = {m.group(1): int(m.group(2)) 
                 for m in re.finditer(r"-([A-Z]+)(\d+)", "-"+indels)}
    return days, depth, counts, ins_dict, dels_dict

ANNOT_COLS = ("position", "gene", "codon_pos", "aa_idx", "contig", "contig_pos", "cds_codons")
_LEGACY_WARNED = []


def parse_layout(hdr):
    """
    Separates the annotation columns from the time columns BY NAME.
    (1.x always assumed 4 annotation columns; now there can be 4 or 7.)
    Returns (indices of known columns, number of annotation columns, time tokens).
    """
    idx = {c: i for i, c in enumerate(hdr) if c in ANNOT_COLS}
    n = 0
    while n < len(hdr) and hdr[n] in ANNOT_COLS:
        n += 1
    if n < 4 or hdr[:4] != ["position", "gene", "codon_pos", "aa_idx"]:
        fail("Unrecognized header in *_genes.tsv: " + ",".join(hdr[:8]),
                "it must start with position, gene, codon_pos, aa_idx.",
                "Generate the file with srasel annotate (SRASel 2.0).")
    return idx, n, hdr[n:]


def annots_from_line(line, idx):
    """Annotations [(cds_id, gene, strand, cp, aa_idx, (g1,g2,g3), table)…] of one row."""
    if "cds_codons" in idx:
        return decode_annots(line[idx["cds_codons"]])
    # ── 1.x format (no cds_codons): one can only assume the + strand, a single frame ──────────
    if not _LEGACY_WARNED:
        _LEGACY_WARNED.append(1)
        disclaimer("The *_genes.tsv does NOT have the cds_codons column (SRASel 1.x format). The + strand is assumed "
                      "and a single frame per position: positions with several genes/jumps will remain "
                      "ambiguous and genes on the − strand will give wrong amino acids. "
                      "Regenerate the table with srasel annotate (2.0).")
    pos = int(line[0])
    try:
        cp = int(line[idx["codon_pos"]])
    except ValueError:
        return []
    aa = line[idx["aa_idx"]].strip()
    aa = int(aa) if re.fullmatch(r"\d+", aa) else 0
    st = pos - (cp - 1)
    return [("legacy", line[idx["gene"]], 1, cp, aa, (st, st + 1, st + 2), 1)]


def process_line(line_data):
    """Process one TSV line and return the generated rows"""
    line, tokens, tp_num, idx, n_annot = line_data
    rows = []

    pos, gene = int(line[0]), line[1]
    annots = annots_from_line(line, idx)
    # amino acid index of the PRIMARY reading (the first one); "ND" if not coding
    aa_idx_val = str(annots[0][4]) if annots and annots[0][4] else "ND"

    by_tp = defaultdict(list)
    for tok, cell in zip(tokens, line[n_annot:]):
        by_tp[tp_num[tok]].append(cell)

    for tp, clist in by_tp.items():
        n_tot = days = 0
        base_cnt = defaultdict(int)
        ins_cnt = defaultdict(int)
        dels_cnt = defaultdict(int)
        for c in clist:
            p = split_cell(c)
            if not p:
                continue
            d, n_i, bases, ins_dict, dels_dict = p
            days = d
            n_tot += n_i
            for b, x in bases.items():
                base_cnt[b] += x
            for seq, x in ins_dict.items():
                ins_cnt[seq] += x
            for seq, x in dels_dict.items():
                dels_cnt[seq] += x
        if n_tot == 0:
            continue

        # ► SNVs (A/C/T/G/N): same as before
        for b, c in base_cnt.items():
            if c > 0:
                rows.append((pos, b, days, c, n_tot))
        # ► INDELs as separate variants by sequence
        #     Each unique insertion is treated as a "+SEQ" variant
        for seq, c in ins_cnt.items():
            if c > 0:
                rows.append((pos, f"+{seq}", days, c, n_tot))
        # Each unique deletion is treated as a "-SEQ" variant
        for seq, c in dels_cnt.items():
            if c > 0:
                rows.append((pos, f"-{seq}", days, c, n_tot))

    return rows, pos, gene, aa_idx_val, annots

def process_chunk(chunk_data):
    """Process a chunk of already processed TSV rows in parallel"""
    chunk_rows, tokens, tp_num, chunk_genes = chunk_data
    rows = []
    gene_of = {}
    aaidx_of = {}
    annot_of = {}
    
    # The rows are already processed, so use the provided gene mappings
    for row in chunk_rows:
        pos, var, day, k, n = row
        rows.append(row)
        
        # Use the provided gene mappings
        if pos not in gene_of:
            gene_of[pos] = chunk_genes.get(pos, "unknown")
            aaidx_of[pos] = chunk_genes.get(f"{pos}_aa", "ND")
            annot_of[pos] = chunk_genes.get(f"{pos}_codon", [])
    
    return rows, gene_of, aaidx_of, annot_of

def make_long(tsv_path: pathlib.Path, depth_any=10, n_jobs=2, nperm=2000, freq_delta=0.01, thr_clear=0.95, eps_tie=0.05):
    """New implementation: creates N separate physical _long files and processes them in parallel"""
    pat = tsv_path.stem.split("_genes")[0]
    outdir = tsv_path.parent
    
    if n_jobs == 1:
        # Sequential processing (unchanged)
        rows=[]; gene_of={}; aaidx_of={}; annot_of={}
        
        with tsv_path.open() as fh:
            rdr = csv.reader(fh, delimiter="\t")
            hdr = next(rdr); idx, n_annot, tokens = parse_layout(hdr)
            tp_num = {tok: int(SRASEL_TOKEN_RE.match(tok).group(1)) for tok in tokens}

            # Read all lines into memory
            fh.seek(0)
            rdr = csv.reader(fh, delimiter="\t")
            next(rdr)  # skip header
            all_lines = list(rdr)
            
            for line in tqdm(all_lines, desc=f"Reading {tsv_path.stem}", unit="pos"):
                result = process_line((line, tokens, tp_num, idx, n_annot))
                line_rows, pos, gene, aa_idx_val, codon_pos = result
                rows.extend(line_rows)
                gene_of[pos] = gene
                aaidx_of[pos] = aa_idx_val
                annot_of[pos] = codon_pos

        long = pd.DataFrame(rows, columns=["pos","var","day","k","n"])
        # keep variants that reach k ≥ depth_any on some day
        keep = (long.groupby(["pos","var"])["k"].max() >= depth_any)
        all_depth = long[["pos", "day", "n"]]
        long = long.merge(keep.reset_index().rename(columns={"k":"keep"}))
        kept = long[long["keep"]].drop(columns="keep")
        if ZERO_FILL:
            kept = zero_fill(kept, all_depth)
        return (kept, gene_of, aaidx_of, annot_of)
    
    else:
        # NEW IMPLEMENTATION: Create N separate physical files
        print(f"🔄 Processing {pat} with {n_jobs} cores...")
        
        # 1. Read all lines and apply a global depth filter
        print("📖 Reading TSV file...")
        with tsv_path.open() as fh:
            rdr = csv.reader(fh, delimiter="\t")
            hdr = next(rdr); idx, n_annot, tokens = parse_layout(hdr)
            tp_num = {tok: int(SRASEL_TOKEN_RE.match(tok).group(1)) for tok in tokens}

            fh.seek(0)
            rdr = csv.reader(fh, delimiter="\t")
            next(rdr)  # skip header
            all_lines = list(rdr)
        
        # Apply the global depth filter BEFORE splitting into chunks
        print(f"🔍 Applying global depth filter (≥{depth_any} reads per variant)...")
        
        # Process all lines to obtain complete data
        all_rows = []
        genes_info = {}  # Dictionary to store gene info per position
        for line in tqdm(all_lines, desc="Processing lines", unit="pos"):
            rows, pos, gene, aa_idx_val, codon_pos = process_line((line, tokens, tp_num, idx, n_annot))
            if rows:
                all_rows.extend(rows)
                # Save gene information for this position
                if pos not in genes_info:
                    genes_info[pos] = gene
                    genes_info[f"{pos}_aa"] = aa_idx_val
                    genes_info[f"{pos}_codon"] = codon_pos
        
        # Create the full DataFrame and apply the global filter
        print("📊 Applying quality filters...")
        full_df = pd.DataFrame(all_rows, columns=["pos","var","day","k","n"])
        # FIXED: Filter by reads of the specific variant (k), not total coverage (n)
        keep_global = (full_df.groupby(["pos","var"])["k"].max() >= depth_any)
        valid_variants = set(keep_global[keep_global].index)
        
        print(f"✅ Global filter: {len(valid_variants)} valid variants out of {len(keep_global)} total")
        
        # Filter processed rows keeping only valid variants
        filtered_rows = []
        for row in all_rows:
            if (row[0], row[1]) in valid_variants:  # (pos, var)
                filtered_rows.append(row)
        
        if ZERO_FILL:       # observations with frequency 0 (see zero_fill)
            _zf = zero_fill(pd.DataFrame(filtered_rows, columns=["pos","var","day","k","n"]), full_df)
            filtered_rows = list(_zf.itertuples(index=False, name=None))

        # Group rows by position to keep nucleotides/amino acids together
        pos_groups = defaultdict(list)
        for row in filtered_rows:
            pos = row[0]
            pos_groups[pos].append(row)
        
        # GLOBAL mean frequencies to infer codons (also those that cross a chunk boundary)
        _, fmean_pos_global = build_freq_summaries(
            pd.DataFrame(filtered_rows, columns=["pos","var","day","k","n"]))

        # 2. Create chunks balanced by position
        print("📦 Splitting data into chunks for parallel processing...")
        positions = sorted(pos_groups.keys())
        chunk_size = max(1, len(positions) // n_jobs)
        chunks = []
        
        for i in range(0, len(positions), chunk_size):
            chunk_positions = positions[i:i+chunk_size]
            chunk_rows = []
            chunk_genes = {}
            for pos in chunk_positions:
                chunk_rows.extend(pos_groups[pos])
                # Include gene information for this chunk
                if pos in genes_info:
                    chunk_genes[pos] = genes_info[pos]
                    chunk_genes[f"{pos}_aa"] = genes_info[f"{pos}_aa"]
                    chunk_genes[f"{pos}_codon"] = genes_info[f"{pos}_codon"]
            # Create a chunk containing the processed rows and gene info
            chunks.append((chunk_rows, tokens, tp_num, chunk_genes))
        
        print(f"📁 Creating {len(chunks)} temporary files...")
        
        # 3. Create separate physical files
        chunk_files = []
        for i, chunk in enumerate(tqdm(chunks, desc="Creating chunks", unit="chunk")):
            chunk_file = outdir / f"{pat}_long_chunk_{i:02d}.tsv"
            chunk_files.append(chunk_file)
            
            # Process chunk and save as a physical file
            chunk_rows, chunk_gene_of, chunk_aaidx_of, chunk_annot_of = process_chunk(chunk)
            
            if chunk_rows:
                chunk_df = pd.DataFrame(chunk_rows, columns=["pos","var","day","k","n"])
                # The depth filter was already applied globally
                
                # Save physical file
                chunk_df.to_csv(chunk_file, sep="\t", index=False)
            else:
                # Create an empty file to maintain consistency
                pd.DataFrame(columns=["pos","var","day","k","n"]).to_csv(chunk_file, sep="\t", index=False)
        
        # 4. Process files in parallel (permutation analysis)
        print(f"🔬 Analyzing variants with {n_jobs} cores...")
        
        def process_chunk_file(chunk_file_path):
            """Process a _long_chunk file and return statistics"""
            if not chunk_file_path.exists():
                return None, {}, {}, {}
            
            chunk_df = pd.read_csv(chunk_file_path, sep="\t")
            if chunk_df.empty:
                return None, {}, {}, {}
            
            # Rebuild mappings from the original chunk
            chunk_idx = int(chunk_file_path.stem.split("_chunk_")[1])
            chunk_rows, tokens, tp_num, chunk_genes = chunks[chunk_idx]
            
            gene_of = {}; aaidx_of = {}; annot_of = {}
            # Use the gene mappings of the chunk
            for row in chunk_rows:
                pos = row[0]
                if pos not in gene_of:
                    gene_of[pos] = chunk_genes.get(pos, "unknown")
                    aaidx_of[pos] = chunk_genes.get(f"{pos}_aa", "ND")
                    annot_of[pos] = chunk_genes.get(f"{pos}_codon", [])
            
            return chunk_df, gene_of, aaidx_of, annot_of
        
        def analyse_chunk_variants(chunk_file_path, nperm, freq_delta, thr_clear, eps_tie, chunk_id):
            """Analyze all variants of a chunk sequentially"""
            chunk_df, gene_of, aaidx_of, annot_of = process_chunk_file(chunk_file_path)
            if chunk_df is None or chunk_df.empty:
                return []
            
            # (1.x built fmean_pos only with the positions of the chunk → neighbors lost at the boundary)
            fmean_pos = fmean_pos_global
            
            # Group the variants of the chunk
            groups = list(chunk_df.groupby(["pos","var"]))
            
            # Analyze the variants of the chunk sequentially (no internal parallelization)
            stats = []
            for g in tqdm(groups, desc=f"Core {chunk_id}", unit="var", position=chunk_id, leave=False):
                result = analyse_variant(g, nperm, gene_of, aaidx_of, annot_of,
                                       chunk_df, freq_delta, fmean_pos, thr_clear, eps_tie)
                if result:
                    stats.append(result)
            
            return stats
        
        # Process files in parallel (variant analysis)
        print(f"🔬 Processing {len(chunk_files)} files in parallel with {n_jobs} cores...")
        all_stats = Parallel(n_jobs=n_jobs, backend="loky")(
            delayed(analyse_chunk_variants)(chunk_file, nperm, freq_delta, thr_clear, eps_tie, i) 
            for i, chunk_file in enumerate(chunk_files)
        )
        
        # Flatten the list of statistics
        stats = []
        for chunk_stats in all_stats:
            stats.extend(chunk_stats)
        
        # We also need the mappings for the final report
        results = Parallel(n_jobs=n_jobs, backend="loky")(
            delayed(process_chunk_file)(chunk_file) for chunk_file in chunk_files
        )
        
        # 5. Merge results from all files
        print("🔗 Merging results from all cores...")
        all_dfs = []
        gene_of = {}; aaidx_of = {}; annot_of = {}
        
        for chunk_df, chunk_gene_of, chunk_aaidx_of, chunk_annot_of in results:
            if chunk_df is not None and not chunk_df.empty:
                all_dfs.append(chunk_df)
                gene_of.update(chunk_gene_of)
                aaidx_of.update(chunk_aaidx_of)
                annot_of.update(chunk_annot_of)
        
        if all_dfs:
            long = pd.concat(all_dfs, ignore_index=True)
        else:
            long = pd.DataFrame(columns=["pos","var","day","k","n"])
        
        # 6. Clean up temporary files
        print("🧹 Cleaning up temporary files...")
        for chunk_file in chunk_files:
            if chunk_file.exists():
                chunk_file.unlink()
        
        print(f"✅ Analysis completed: {len(long)} final rows")
        return long, gene_of, aaidx_of, annot_of, stats

# — weighted slope ————————————————————————————————
def beta_only(day,k,n):
    w = n
    W  = np.sum(w)
    x̄ = np.sum(w*day)   / W
    ȳ = np.sum(w*(k/n)) / W
    Sxx = np.sum(w*(day-x̄)**2)
    Sxy = np.sum(w*(day-x̄)*((k/n)-ȳ))
    beta = Sxy / Sxx if Sxx>0 else 0.
    return beta

ZERO_FILL = True     # --legacy-no-zero-fill disables it (SRASel 1.x behavior)


def zero_fill(kept: pd.DataFrame, depth_src: pd.DataFrame) -> pd.DataFrame:
    """
    Adds rows with k=0 for the days on which a retained variant was NOT observed but the position did have coverage.
    SRASel 1.x only created rows with k>0: a variant starting from 0 lost precisely its most informative points and
    two complementary alleles (A goes up / G goes down) gave different slopes and p-values. With real data from Freiburg,
    F490L (0%→99.7%) gave p=0.24 while its reference allele (99.3%→0.3%) gave p=0.025.
    """
    if kept.empty:
        return kept
    depth = depth_src[["pos", "day", "n"]].drop_duplicates(["pos", "day"])
    full = kept[["pos", "var"]].drop_duplicates().merge(depth, on="pos")
    out = full.merge(kept[["pos", "var", "day", "k"]], on=["pos", "var", "day"], how="left")
    out["k"] = out["k"].fillna(0).astype(int)
    return out[["pos", "var", "day", "k", "n"]]


PERM_SEED = None     # --seed: if set, each (pos,var) uses its own reproducible generator


def pval_perm(day,k,n,beta_real,nperm,rng=None):
    """Simple sequential version for permutations"""
    greater = 0
    for _ in range(nperm):
        beta_star = beta_only(rng.permutation(day) if rng is not None else np.random.permutation(day),k,n)
        if abs(beta_star) >= abs(beta_real):
            greater += 1
    return (greater+1)/(nperm+1)

# ─────────────────── Mean frequencies and codon/AA annotation ──────────────
def build_freq_summaries(long_df: pd.DataFrame):
    """
    Returns:
      fmean_posvar: DataFrame with columns [pos, var, freq_mean]
      fmean_pos:    dict {pos -> list[(var, freq_mean_desc)]}
    """
    tmp = long_df.assign(freq = long_df["k"] / long_df["n"])
    fmean_posvar = (tmp.groupby(["pos","var"])["freq"]
                       .mean()
                       .reset_index(name="freq_mean"))
    # fast dict: pos -> [(var, freq_mean) ...] sorted descending
    fmean_pos = {}
    for p, sub in fmean_posvar.groupby("pos"):
        lst = list(zip(sub["var"].values, sub["freq_mean"].values))
        lst.sort(key=lambda t: t[1], reverse=True)
        fmean_pos[p] = lst
    return fmean_posvar, fmean_pos

def infer_codon_aa_for_recta(pos: int,
                             var: str,
                             fmean_pos: dict,
                             annot,
                             thr_clear: float,
                             eps_tie: float,
                             selected_positions=None):
    """
    Builds the codon (and AA) of *this line (pos,var)* for ONE reading frame (`annot`) of the genome.
      - At 'pos' the base is forced = var.
      - The other two bases of the codon are read from the mean frequencies: they are accepted only if
        they are "clear" (freq >= thr_clear), are not indels, and are not selected.
      - Otherwise the codon is ambiguous (the substitution cannot be interpreted reliably).
    `annot` = (cds_id, gene, strand, codon_pos, aa_idx, (g1,g2,g3), transl_table) or None.
    The three nucleotides (g1,g2,g3) already come in CDS reading order (− strand, splicing and
    ribosomal frameshifts included); if the strand is −, the codon is the complement of the + bases.
    Returns (codon, aa_label, ambiguous, detail_str).
    """
    if selected_positions is None:
        selected_positions = set()

    if len(var) != 1:   # indel
        return None, "amb (indel)", True, "indel"
    if var == "N":
        return None, "amb", True, "forced_N"

    if annot is None:
        return None, "amb", True, "no_codon_pos: the position does not belong to any annotated CDS"
    cds_id, gene, strand, codon_pos, _aa, triple, table = annot

    lst_here = fmean_pos.get(pos, [])
    if not lst_here:
        return None, "amb", True, "no_fmean_pos"
    v_pos_top, f_pos_top = lst_here[0]

    bases = []
    ambiguous_due_to_indel = False
    ambiguous = False
    detail_lines = [f"[{gene} {'+' if strand == 1 else '-'} cp={codon_pos}]"]

    for p in triple:
        if p == pos:
            bases.append(var)
            detail_lines.append(f"{p}:FORCED={var};pos_top=({v_pos_top},{f_pos_top:.3f})")
            continue

        lst = fmean_pos.get(p)
        if not lst:
            bases.append("N")
            ambiguous = True
            detail_lines.append(f"{p}:NOINFO;pos_selected={p in selected_positions}")
            continue

        # ── ignore indels as a “clear base” at neighboring positions ─────────
        lst_nt = [(v, f) for (v, f) in lst if len(v) == 1]   # A/C/G/T/N
        if not lst_nt:
            bases.append("N")
            ambiguous = True
            ambiguous_due_to_indel = True
            detail_lines.append(
                f"{p}:NO_NT_CANDIDATE(indel_only);pos_selected={p in selected_positions}")
            continue
        v1, f1 = lst_nt[0]
        f2 = lst_nt[1][1] if len(lst_nt) > 1 else 0.0
        p_selected = (p in selected_positions)
        detail_lines.append(
            f"{p}:top=({v1},{f1:.3f}) second={f2:.3f} "
            f"pos_top=({v_pos_top},{f_pos_top:.3f}) |f1-f_pos_top|={abs(f1 - f_pos_top):.3f} "
            f"pos_selected={p_selected}")

        if (f1 < thr_clear) or p_selected:
            bases.append("N")
            ambiguous = True
        else:
            bases.append(v1)

    # bases on the + strand and in reading order → mRNA codon
    codon = "".join(bases)
    if strand == -1:
        codon = "".join(revcomp_base(b) for b in bases)
    if ambiguous:
        aa_label = "amb (indel)" if ambiguous_due_to_indel else "amb"
        return codon, aa_label, True, ";".join(detail_lines)
    aa = translate_codon(codon, table)
    if aa == "X":
        aa = "?"
    return codon, aa, False, ";".join(detail_lines)


def annotate_frames(pos, var, beta, annots, fmean_pos, thr_clear, eps_tie,
                    selected_positions=None, force_amb_if_multisel=False):
    """
    Evaluates ALL reading frames of the position (overlapping genes, ribosomal frameshift…).
    Returns a list of dicts, the first is the main reading frame (GenBank order).
    """
    out = []
    alist = annots if annots else [None]
    for a in alist:
        codon, aa_label, ambiguous, detail = infer_codon_aa_for_recta(
            pos, var, fmean_pos, a, thr_clear=thr_clear, eps_tie=eps_tie,
            selected_positions=selected_positions)
        multisel = False
        if a is not None and selected_positions is not None:
            multisel = sum((q in selected_positions) for q in a[5]) >= 2
            if multisel and force_amb_if_multisel:
                ambiguous = True
        is_indel = (len(var) != 1) or (aa_label == "amb (indel)")
        aa = "amb" if aa_label in ("amb", "amb (indel)") else (aa_label.rstrip('0123456789') or "amb")
        aa_idx = str(a[4]) if (a is not None and a[4]) else "ND"
        out.append(dict(gene=(a[1] if a else ""), aa_idx=aa_idx, codon=codon, aa=aa,
                        is_indel=is_indel, ambiguous=bool(ambiguous), detail=detail,
                        multisel=multisel,
                        aa_change=_format_aa_change(aa, aa_idx, beta, is_indel)))
    return out


def format_other_frames(frames) -> str:
    """Effect of the same variant on the other reading frames of the genome, e.g. 'gag:G435D;tat:amb7'."""
    return ";".join(f"{f['gene']}:{f['aa_change']}" + ("[amb]" if f["ambiguous"] else "")
                    for f in frames[1:])


def analyse_variant(group, nperm, gene_of, aaidx_of, annot_of,
                    long_df, freq_delta, fmean_pos, thr_clear, eps_tie):
    (pos,var), grp = group
    if grp["day"].nunique() < 3:
        return None
    day, k, n = grp["day"].values, grp["k"].values, grp["n"].values
    freq = k/n
    # first we estimate the slope
    beta = beta_only(day, k, n)
    # Δf from the “fit”: slope × (t_max - t_min)
    delta_f = beta * (day.max() - day.min())
    if abs(delta_f) < freq_delta:
        return None

    rng = (np.random.default_rng([PERM_SEED, int(pos), zlib.crc32(str(var).encode())])
           if PERM_SEED is not None else None)
    p = pval_perm(day,k,n,beta,nperm,rng)
    tag   = ("pos" if (p<0.05 and beta>0)
             else "neg" if (p<0.05 and beta<0) else "")
    score = math.copysign(abs(beta)*(-math.log10(p)), beta)

    # ─── nt/aa annotation from global frequencies ─────
    frames = annotate_frames(pos, var, beta, annot_of.get(pos, []), fmean_pos,
                             thr_clear, eps_tie, selected_positions=None)
    main_f = frames[0]          # main reading frame; the rest goes to 'other_frames'

    return dict(gene=gene_of[pos], aa_gene=main_f["gene"], aa_idx=main_f["aa_idx"], pos=pos, var=var,
                beta=beta, pval=p, score=score, tag=tag,
                delta_f=float(delta_f),
                codon=main_f["codon"],
                aa_change=main_f["aa_change"], ambiguous=main_f["ambiguous"],
                other_frames=format_other_frames(frames),
                annot_detail=main_f["detail"],
                depth=float(np.mean(n)), n_days=int(grp["day"].nunique()),
                day=day.tolist(),            # ← "plain" lists
                k=k.tolist(),
                n=n.tolist())

# ───────────────────── per-position summary ─────────────────────────────
def _format_aa_change(aa: str, aa_idx: str, beta: float, is_indel: bool = False) -> str:
    """
    Formats aa_change according to the sign of beta:
    - Negative beta: change+pos (e.g.: K242)
    - Positive beta: pos+change (e.g.: 242K)
    - Ambiguous: amb+pos or pos+amb
    - Indel with beta < 0: (indel)amb242 or (indel)K242
    - Indel with beta > 0: 242amb(indel) or 242K(indel)
    """
    if aa is None or aa == "":
        aa = "amb"
    
    # Determine whether it is an indel
    if is_indel or aa == "amb (indel)":
        aa = "amb"
        indel_suffix = "(indel)"
    else:
        indel_suffix = ""
    
    # If there is no aa_idx or it is not numeric, use "ND"
    if not aa_idx or not str(aa_idx).isdigit():
        aa_idx = "ND"
    
    # Format according to the sign of beta
    if beta < 0:  # Negative beta: change+pos
        if aa == "amb":
            return f"{indel_suffix}amb{aa_idx}" if indel_suffix else f"amb{aa_idx}"
        else:
            return f"{indel_suffix}{aa}{aa_idx}" if indel_suffix else f"{aa}{aa_idx}"
    else:  # Positive beta: pos+change
        if aa == "amb":
            return f"{aa_idx}amb{indel_suffix}"
        else:
            return f"{aa_idx}{aa}{indel_suffix}"

def _split_aa_label(lbl: str) -> Tuple[str, str]:
    """'K100' -> ('K','100'); '100K' -> ('K','100'); 'ambiguous' -> ('amb','')"""
    # Consider "ambiguous" and variants such as "ambiguous (indel)" -> convert to "amb"
    if lbl is None or (isinstance(lbl, str) and lbl.startswith("ambiguous")):
        return "amb", ""
    
    # Special cases for ambND, NDamb, and amb followed by numbers
    if lbl == "ambND":
        return "amb", "ND"
    elif lbl == "NDamb":
        return "amb", "ND"
    elif lbl.startswith("amb") and lbl[3:].isdigit():
        return "amb", lbl[3:]
    
    m = AA_RE.match(lbl)
    if not m:
        return lbl, ""
    # Check whether the format is amino acid+number or number+amino acid
    if m.group(1) and m.group(2):  # amino acid+number (e.g.: D5152)
        return m.group(1), m.group(2)
    elif m.group(3) and m.group(4):  # number+amino acid (e.g.: 5152D)
        return m.group(4), m.group(3)
    elif m.group(5) and m.group(6):  # number+amb (e.g.: 5624amb)
        return m.group(6), m.group(5)
    elif m.group(7) and m.group(8):  # amb+number (e.g.: amb614)
        return m.group(7), m.group(8)
    else:
        return lbl, ""

def summarise_positions(df_stats: pd.DataFrame) -> pd.DataFrame:
    """
    Per-position summary, storing ALL selected lines (pos/neg) as JSON:
      - vars, tags, betas, pvals, codons, aa_labels, ambiguous, annot_detail
    In addition:
      - label:  D100K (↓ first, ↑ after) if there is one rise and one fall; or K100 if there is only one.
      - synonymous: True/False if it can be decided; False by default if not determinable.
      - why_ambiguous_pos: concatenation of the annotation details of the ambiguous lines.
      - beta_up/p_up and beta_dn/p_dn: of the best lines (highest |score|) per sign.
      - score_up/score_dn: the score of those “best” lines.
    """
    sel = df_stats[df_stats["tag"].isin(["pos","neg"])]
    if sel.empty:
        return pd.DataFrame(columns=[
            "pos","aa_idx","label","synonymous","n_sel",
            "vars","tags","betas","pvals","codons","aa_labels","ambiguous","annot_detail",
            "why_ambiguous_pos","beta_up","p_up","beta_dn","p_dn","score_up","score_dn"
        ])

    rows = []

    for pos, sub in sel.groupby("pos"):
        # JSON lists with ALL selected lines
        vars_l        = sub["var"].tolist()
        tags_l        = sub["tag"].tolist()
        betas_l       = sub["beta"].tolist()
        pvals_l       = sub["pval"].tolist()
        # pandas >= 3 fills missing text with NaN (None before): normalised so the JSON is null with any pandas
        codons_l      = [None if pd.isna(x) else x for x in sub["codon"]] if "codon" in sub else [None]*len(sub)
        aa_labels_l   = [None if pd.isna(x) else x for x in sub["aa_change"]] if "aa_change" in sub else [None]*len(sub)
        ambiguous_l   = sub["ambiguous"].tolist() if "ambiguous" in sub else [False]*len(sub)
        details_l     = sub["annot_detail"].tolist() if "annot_detail" in sub else [""]*len(sub)

        why_amb = [d for a, d in zip(ambiguous_l, details_l) if a]

        # top by score for each sign
        pos_sel = sub[sub["tag"]=="pos"].sort_values("score", ascending=False)
        neg_sel = sub[sub["tag"]=="neg"].sort_values("score", ascending=False)

        beta_up = p_up = beta_dn = p_dn = score_up = score_dn = None
        label = "amb"
        synonymous = None
        
        # Get aa_idx directly from the aa_idx column of the DataFrame
        aa_idx = sub["aa_idx"].iloc[0] if not sub.empty else ""

        # Check whether there are multiple lines of the same sign (should be ambiguous)
        multiple_pos = len(pos_sel) > 1
        multiple_neg = len(neg_sel) > 1
        
        if multiple_pos and not neg_sel.empty:
            # Multiple rises + one fall → amino acid of the fall{aa_idx}amb
            dn = neg_sel.iloc[0]
            aa_d, idx_d = _split_aa_label(dn["aa_change"])
            if aa_d == "amb":
                label = f"amb{aa_idx}amb" if aa_idx else "ambamb"
            else:
                # Use the amino acid extracted directly (already without index)
                label = f"{aa_d}{aa_idx}amb" if aa_idx else f"{aa_d}amb"
            synonymous = None
            beta_up = p_up = beta_dn = p_dn = score_up = score_dn = None
        elif multiple_neg and not pos_sel.empty:
            # Multiple falls + one rise → amb{aa_idx}amino acid of the rise
            up = pos_sel.iloc[0]
            aa_u, idx_u = _split_aa_label(up["aa_change"])
            if aa_u == "amb":
                label = f"amb{aa_idx}amb" if aa_idx else "ambamb"
            else:
                # Use the amino acid extracted directly (already without index)
                label = f"amb{aa_idx}{aa_u}" if aa_idx else f"amb{aa_u}"
            synonymous = None
            beta_up = p_up = beta_dn = p_dn = score_up = score_dn = None
        elif multiple_pos and neg_sel.empty:
            # Only multiple rises → {aa_idx}amb
            label = f"{aa_idx}amb" if aa_idx else "amb"
            synonymous = None
            beta_up = p_up = beta_dn = p_dn = score_up = score_dn = None
        elif multiple_neg and pos_sel.empty:
            # Only multiple falls → amb{aa_idx}
            label = f"amb{aa_idx}" if aa_idx else "amb"
            synonymous = None
            beta_up = p_up = beta_dn = p_dn = score_up = score_dn = None
        elif multiple_pos and multiple_neg:
            # Multiple of both signs → amb{aa_idx}amb
            label = f"amb{aa_idx}amb" if aa_idx else "ambamb"
            synonymous = None
            beta_up = p_up = beta_dn = p_dn = score_up = score_dn = None
        elif not pos_sel.empty and not neg_sel.empty and not multiple_pos and not multiple_neg:
            up  = pos_sel.iloc[0]
            dn  = neg_sel.iloc[0]
            aa_u, idx_u = _split_aa_label(up["aa_change"])
            aa_d, idx_d = _split_aa_label(dn["aa_change"])
            # Use aa_idx from the DataFrame if it cannot be extracted from aa_change
            if not aa_idx and (idx_d or idx_u):
                aa_idx = idx_d or idx_u
            # Build label: ↓ first, ↑ after
            if aa_d == "amb" and aa_u == "amb":
                label = f"amb{aa_idx}amb" if aa_idx else "ambamb"
            else:
                # Extract only the amino acids without the indices
                aa_d_only = aa_d.rstrip('0123456789') if aa_d else "amb"
                aa_u_only = aa_u.rstrip('0123456789') if aa_u else "amb"
                
                # Show both directions: ↓ first, ↑ after
                label = f"{aa_d_only}{aa_idx}{aa_u_only}"  # ↓ first, ↑ after
            # Synonymous labeling as boolean; None if it cannot be decided
            if aa_d not in ("amb","?") and aa_u not in ("amb","?"):
                synonymous = (aa_d == aa_u)   # True if AAs are equal, False if different
            else:
                synonymous = None
            beta_up, p_up, score_up = up["beta"], up["pval"], up["score"]
            beta_dn, p_dn, score_dn = dn["beta"], dn["pval"], dn["score"]
        else:
            # only one selected line
            r = pos_sel.iloc[0] if not pos_sel.empty else neg_sel.iloc[0]
            aa, idx = _split_aa_label(r["aa_change"])
            # Use aa_idx from the DataFrame if it cannot be extracted from aa_change
            if not aa_idx and idx:
                aa_idx = idx
            if aa != "amb":
                # Use the amino acid extracted directly (already without index)
                # If rise ⇒ idx first (100K); if fall ⇒ AA first (K100)
                label = f"{aa_idx}{aa}" if r["tag"] == "pos" else f"{aa}{aa_idx}"
            else:
                # If ambiguous but we have aa_idx, include it
                if aa_idx:
                    label = f"{aa_idx}amb" if r["tag"] == "pos" else f"amb{aa_idx}"
                else:
                    # If there is no aa_idx, use ND and respect the negative/positive rule
                    label = "NDamb" if r["tag"] == "pos" else "ambND"
            if r["tag"] == "pos":
                beta_up, p_up, score_up = r["beta"], r["pval"], r["score"]
            else:
                beta_dn, p_dn, score_dn = r["beta"], r["pval"], r["score"]

        rows.append(dict(
            pos=pos,
            aa_idx=aa_idx,
            label=label,
            synonymous=synonymous,
            n_sel=len(sub),
            vars=json.dumps(vars_l),
            tags=json.dumps(tags_l),
            betas=json.dumps(betas_l),
            pvals=json.dumps(pvals_l),
            codons=json.dumps(codons_l),
            aa_labels=json.dumps(aa_labels_l),
            ambiguous=json.dumps(ambiguous_l),
            annot_detail=json.dumps(details_l),
            why_ambiguous_pos=" | ".join(why_amb),
            beta_up=beta_up,  p_up=p_up,
            beta_dn=beta_dn,  p_dn=p_dn,
            score_up=score_up, score_dn=score_dn,
        ))

    return pd.DataFrame(rows)

# ───────────────────── single figure per position ────────────────────────
# [redesign 2026-11-18] Publication style of the two static figures (presentation only: same data, same marks). White background, the palette of
# report.html (up = vermillion, down = blue; Okabe-Ito), readable sizes, TrueType text in the PDF. Applied with a decorator, so no figure code moves.
_UP, _DOWN, _NEUTRAL, _INK, _MUTED = "#D55E00", "#0072B2", "#B4BCC9", "#1C2B3A", "#64748B"
_PUB_RC = {"figure.facecolor": "white", "axes.facecolor": "white", "savefig.facecolor": "white", "font.family": "sans-serif",
           "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"], "font.size": 9, "axes.titlesize": 9, "axes.labelsize": 9, "xtick.labelsize": 8,
           "ytick.labelsize": 8, "legend.fontsize": 8, "text.color": _INK, "axes.labelcolor": _INK, "axes.edgecolor": "#44566C", "axes.linewidth": 0.6,
           "xtick.color": "#44566C", "ytick.color": "#44566C", "grid.color": "#E1E6EE", "pdf.fonttype": 42}


def _pub_style(fn):
    import functools

    @functools.wraps(fn)
    def wrapped(*a, **k):
        with plt.rc_context(_PUB_RC):
            return fn(*a, **k)
    return wrapped


@_pub_style
def plot_position(patient: str,
                  pos: int,
                  df_stats: pd.DataFrame,
                  long_df: pd.DataFrame,
                  beta_mean_sel: float,
                  beta_mean_all: float,
                  pos_row: pd.Series,
                  plot_dir: pathlib.Path,
                  gene_of: dict = None,
                  aaidx_of: dict = None):
    """
    One figure per position with at least one selected line:
      - selected lines in red (β>0) / blue (β<0)
      - the rest in gray
    """
    mates = long_df[ long_df["pos"] == pos ]
    if mates.empty:
        return

    # quick maps
    tag_map  = {(r["pos"], r["var"]): r["tag"]  for _, r in df_stats.iterrows()}

    fig, ax = plt.subplots(figsize=(5,3.2))

    # Compute scales for k (central point) and n (outer circle)
    k_global_max = float(mates["k"].max()) if not mates.empty else 0.0
    n_global_max = float(mates["n"].max()) if not mates.empty else 0.0

    for var, sub in mates.groupby("var"):
        d  = sub["day"].values
        fr = sub["k"].values / sub["n"].values
        b  = beta_only(d, sub["k"].values, sub["n"].values)

        tag = tag_map.get((pos,var), "")
        if tag == "pos":
            color, ec = _UP, _INK
            z = 3
        elif tag == "neg":
            color, ec = _DOWN, _INK
            z = 3
        else:
            color, ec = _NEUTRAL, _NEUTRAL
            z = 1

        # Compute sizes for k (central point) and n (outer circle)
        if k_global_max > 0:
            s_k = 20.0 + 180.0 * (sub["k"].values.astype(float) / k_global_max)
        else:
            s_k = np.full_like(fr, 100.0, dtype=float)
        
        if n_global_max > 0:
            s_n = 30.0 + 200.0 * (sub["n"].values.astype(float) / n_global_max)
        else:
            s_n = np.full_like(fr, 130.0, dtype=float)

        # Draw outer circles (n) first - same color as k but lighter
        ax.scatter(d, fr*100, s=s_n, c=color, alpha=0.2, edgecolors=color, linewidth=0.5, zorder=z-1)
        
        # Draw central points (k) on top
        ax.scatter(d, fr*100, s=s_k, c=color, edgecolors=ec,
                   linewidths=0.25, alpha=.7 if tag else .3, zorder=z)
        # line
        xs = np.array(sorted(d))
        w   = sub["n"].values
        xw  = np.average(d,  weights=w)
        yw  = np.average(fr, weights=w)
        yfit = yw + b*(xs - xw)
        ax.plot(xs, yfit*100, color=color if tag else _MUTED,
                lw=1.0 if tag else .8, ls="-" if tag else "--", alpha=.8 if tag else .3, zorder=z)

    # neutrality lines
    xspan = np.array([mates["day"].min(), mates["day"].max()])
    freq_all = (mates["k"].sum() / mates["n"].sum())
    # all
    ax.plot(xspan,
            (freq_all + beta_mean_all*(xspan-xspan.mean()))*100,
            color=_MUTED, ls="--", lw=.8, alpha=.8, label=r"$\bar{\beta}_{all}$ (all variants)")
    # sel
    if beta_mean_sel is not None:
        ax.plot(xspan,
                (freq_all + beta_mean_sel*(xspan-xspan.mean()))*100,
                color=_INK, ls="--", lw=.8, alpha=.8, label=r"$\bar{\beta}_{sel}$ (labelled only)")

    ax.set_xlabel("Time (days since the first sample)"); ax.set_ylabel("Allele frequency k / n (%)")
    ax.grid(True, ls=":", alpha=0.3)
    ax.spines[["top", "right"]].set_visible(False)
    # legend UNDER the axes (never over the data): label colours and the neutrality lines, then what the two circle sizes are
    from matplotlib.lines import Line2D
    _tags = {tag_map.get((pos, v), "") for v in mates["var"].unique()}
    _h, _l = ax.get_legend_handles_labels()
    for _t, _c, _n in (("pos", _UP, "up (label pos)"), ("neg", _DOWN, "down (label neg)"), ("", _NEUTRAL, "not labelled")):
        if _t in _tags:
            _h.append(Line2D([], [], marker="o", ls="", markerfacecolor=_c, markeredgecolor=_INK if _t else _NEUTRAL, markeredgewidth=.4, markersize=6)); _l.append(_n)
    fig.legend(_h, _l, loc="lower center", ncol=2, frameon=False, fontsize=7.5, bbox_to_anchor=(0.5, 0.045), columnspacing=1.4, handlelength=1.6)

    # title with the pos_row summary (if available)
    if pos_row is not None:
        def _get(d, keys):
            for k in keys:
                if k in d and d[k] is not None:
                    s = str(d[k]).strip()
                    if s != "" and s.lower() not in {"nan", "none"}:
                        return d[k]
            return None

        def _safe_aa(x):
            if x is None:
                return "amb"
            s = str(x).strip()
            # Unify all ambiguity labels to "amb"
            if s == "" or s.lower() in {"nan", "na", "none", "nd", "ambiguous"} or s.startswith("ambiguous"):
                return "amb"
            return s

        def _safe_idx(x):
            try:
                return str(int(float(x)))
            except Exception:
                # If the index were missing (it should not be), we display 'ND'
                return "ND"

        # Get aa_idx from the original data if available
        if aaidx_of is not None and pos in aaidx_of:
            aa_idx = aaidx_of[pos]
        else:
            aa_idx = _get(pos_row, ("aa_idx", "aa_pos", "aa_position", "aa_index"))
        
        # Get amino acid information from df_stats for this position
        pos_stats = df_stats[df_stats["pos"] == pos]
        if not pos_stats.empty:
            # Check whether there are selected indels at this position
            # Indels are variants that start with + (insertion) or - (deletion)
            indel_stats = pos_stats[pos_stats["var"].astype(str).str.startswith(('+', '-'))]
            has_selected_indel = not indel_stats.empty and any(tag in ["pos", "neg"] for tag in indel_stats["tag"].tolist())
            
            if has_selected_indel:
                # If there are selected indels, use amb format with (indel)
                indel_beta = indel_stats.iloc[0]["beta"]  # Use the first selected indel
                if indel_beta < 0:  # Negative beta: (indel)amb + pos
                    change_lbl = f"(indel)amb{aa_idx}"
                else:  # Positive beta: pos + amb(indel)
                    change_lbl = f"{aa_idx}amb(indel)"
            else:
                # Use the amino acid label from the summary if available
                if pos_row is not None and "label" in pos_row and not pos_row["label"].startswith("ambiguous"):
                    change_lbl = pos_row["label"]
                else:
                    # Fallback: use aa_change from the statistics
                    aa_changes = pos_stats["aa_change"].tolist()
                    if aa_changes and not aa_changes[0].startswith("ambiguous"):
                        change_lbl = aa_changes[0]
                    else:
                        change_lbl = f"amb{aa_idx}amb"
        else:
            change_lbl = f"amb{aa_idx}amb"

        syn_flag = pos_row.get("synonymous", None)
        syn_txt = ("syn" if syn_flag is True else
                   "nonsyn" if syn_flag is False and syn_flag is not None else
                   "amb")
        n_sel = pos_row.get('n_sel', 1)
        ttl = f"{patient} · pos {pos} · {change_lbl} [{syn_txt}]  (n_sel={n_sel})"
    else:
        ttl = f"{patient} · pos {pos}"
    
    # Add gene information at the beginning of the title
    if gene_of is not None and pos in gene_of:
        gene_info = gene_of[pos]
    else:
        # Fallback: try to get it from df_stats
        gene_info = df_stats[df_stats["pos"] == pos]["gene"].iloc[0] if not df_stats[df_stats["pos"] == pos].empty else "unknown"
    ttl = f"{gene_info} · {ttl}"
    import textwrap
    ax.set_title(textwrap.fill(ttl, 66), fontsize=9, loc="left")
    fig.text(0.5, 0.01, "inner point: reads of the allele (k) · outer circle: reads covering the position (n)", ha="center", va="bottom", fontsize=6.5, color=_MUTED)
    fig.tight_layout(rect=[0, 0.2, 1, 1])

    out = plot_dir / f"pos{pos:05d}_ALL.pdf"
    fig.savefig(out)
    plt.close(fig)

@_pub_style
def plot_genome(patient: str,
                df_stats: pd.DataFrame,
                long_df: pd.DataFrame,
                outdir: pathlib.Path,
                beta_mean_sel: float,
                beta_mean_all: float,
                tsv_path: pathlib.Path) -> None:
    """
    Genomic summary:
      • Selected points (pos/neg).
      • Independent density curves    β>0 (↑ red)   β<0 (↓ blue)
        – drawn and filled on the right axis, occupying its full height
      • Two horizontal reference lines: β̄_all and β̄_sel.
      • Colored gene bar just ABOVE the x-axis (does not cover the data)
      • Printing of the gene ranges to stdout
    """

    # ───────────── 1 · filter selected variants  ─────────────────
    sel = df_stats[df_stats["tag"].isin(["pos", "neg"])].copy()
    if sel.empty:
        print(f"[WARN] {patient}: no labeled variants; skipping figure")
        return

    sel["color"] = sel["tag"].map({"pos": _UP, "neg": _DOWN}).values
    # --- Use the *_genes.tsv to fix the full genomic range ---
    genes_tsv = tsv_path
    if not genes_tsv.is_file():
        genes_tsv = (outdir.parent / f"{patient}_genes.tsv")
        if not genes_tsv.is_file():
            genes_tsv = outdir / f"{patient}_genes.tsv"

    if genes_tsv.is_file():
        # keep_default_na=False: the 'NA' gene (influenza neuraminidase) must NOT be read as null
        genes_raw = pd.read_csv(genes_tsv, sep="\t",
                                usecols=["position", "gene"], keep_default_na=False)
    else:
        # Fallback if *_genes.tsv does not exist
        genes_raw = (df_stats[["pos", "gene"]]
                     .rename(columns={"pos": "position"})
                     .drop_duplicates())

    contig_spans = None
    if genes_tsv.is_file() and "contig" in pd.read_csv(genes_tsv, sep="\t", nrows=0).columns:
        ct = pd.read_csv(genes_tsv, sep="\t", usecols=["position", "contig"],
                         dtype={"contig": str}, keep_default_na=False)
        ct = ct[ct["contig"] != ""]
        if ct["contig"].nunique() > 1:
            contig_spans = ct.groupby("contig")["position"].agg(["min", "max"]).sort_values("min")

    genome_min = int(genes_raw["position"].min())
    genome_max = int(genes_raw["position"].max())
    x_full     = np.arange(genome_min, genome_max + 1)


    # ───────────── 2 · base figure + density axis  ───────────────────
    fig, ax  = plt.subplots(figsize=(13, 5))
    ax2      = ax.twinx()                     # ← density
    ax.set_xlabel("Genomic position (nt)\n")
    ax.set_ylabel(r"Slope $\beta$ (change of frequency per day)")
    ax2.set_ylabel("Smoothed density of labelled positions (σ = 350 nt)")
    ax.spines["top"].set_visible(False); ax2.spines["top"].set_visible(False)

    # ───────────── 3 · Points only (no CI bars)
    ax.scatter(sel["pos"], sel["beta"], s=46, c=sel["color"],
               edgecolors=_INK, linewidth=.25, zorder=3, alpha=.9)

    # ───────────── 4 · density curves (right axis only) ─────────
    # ───—─ 3.5 · set bottom margin and future position of the gene bar ──
    # Make sure y=0 is within the range and add a symmetric margin
    ymin_d, ymax_d = ax.get_ylim()            # limits after plotting points
    span = (ymax_d - ymin_d)
    if not np.isfinite(span) or span <= 0:
        span = 1.0
    pad = 0.05 * span                         # 5 % derived from the visible range
    ymin_new = min(ymin_d, 0.0) - pad
    ymax_new = max(ymax_d, 0.0) + pad
    ax.set_ylim(ymin_new, ymax_new)
    y_bar = ymin_new + 0.40 * pad             # bar ≈ 40 % deep within the bottom padding

    dens_max = 0.0
    for tag, sign, col in (("pos", +1, _UP),
                           ("neg", -1, _DOWN)):
        sub = sel[sel["tag"] == tag]
        if sub.empty:
            continue

        dens = (sub.groupby("pos").size()
                    .groupby(level=0).sum()          # avoids duplicates
                    .reindex(x_full, fill_value=0)
                    .astype(float)
                    .sort_index())
        smooth = gaussian_filter1d(dens.values, sigma=350)
        dens_max = max(dens_max, smooth.max())    # ← keeps the global maximum


        smooth_signed = sign * smooth               # up / down
        # fill + line on the right axis
        ax2.fill_between(x_full, 0, smooth_signed,
                         color=col, alpha=.20, lw=0, zorder=1)
        ax2.plot(x_full, smooth_signed,
                 color=col, lw=1.1, alpha=.7, zorder=1)

    # ----- adjust ax₂ so that y = 0 is EXACTLY aligned -----
    # fraction of the left axis height where y=0 falls
    frac0  = (0.0 - ymin_new) / (ymax_new - ymin_new)
    # Avoid extremes 0 or 1 for numerical stability
    frac0 = min(max(frac0, 1e-6), 1 - 1e-6)
    upper2 =  1.05 * dens_max
    lower2 = -upper2 * frac0 / (1 - frac0)             # computed to align y=0
    ax2.set_ylim(lower2, upper2)

    # Ticks every 25 % division of the actual range of the right axis
    yticks = np.linspace(lower2, upper2, 5)
    ax2.set_yticks(yticks)

    def fmt_tick(val):
        return "0" if abs(val) < 1e-100 else f"{val:.3g}"

    ax2.set_yticklabels([fmt_tick(t) for t in yticks])
    # Hide values (numbering) of the right Y axis but keep the axis
    ax2.tick_params(right=True, labelright=False)

    # ensure visual alignment of 0 on both axes (limits already set)

    # ───────────── 5 · neutrality lines β̄ ─────────────────────────
    #   · all variants
    ax.axhline(beta_mean_all, color=_MUTED, ls="--", lw=.9,
               label=r"$\bar{\beta}_{all}$ (all variants)")
    #   · selected only (if any)
    if beta_mean_sel is not None:
        ax.axhline(beta_mean_sel, color=_INK, ls="--", lw=.9,
                   label=r"$\bar{\beta}_{sel}$ (labelled only)")

    # ───────────── 6 · ─────────────────────────────────────────────────
    genes_tbl = genes_raw.copy()
    genes_tbl["position"] = pd.to_numeric(genes_tbl["position"], errors="coerce")
    genes_tbl = genes_tbl.dropna(subset=["position"])
    genes_tbl["position"] = genes_tbl["position"].astype(int)
    genes_tbl = genes_tbl.sort_values("position")

    def _split_genes(val):
        if pd.isna(val):
            return []
        s = str(val).strip()
        if s == "":
            return []
        return [g.strip() for g in s.split(",") if g.strip() != ""]

    genes_tbl["gene_list"] = genes_tbl["gene"].map(_split_genes)
    genes_by_pos = (genes_tbl.groupby("position")["gene_list"]
                    .agg(lambda lists: sorted({g for lst in lists for g in lst})))

    pos_list = genes_by_pos.index.to_list()
    pos_genes = genes_by_pos.to_list()

    gene_order = []
    seen = set()
    for glist in pos_genes:
        for g in glist:
            if g not in seen:
                seen.add(g)
                gene_order.append(g)

    spans_rows = []
    active = {}
    prev_pos = None
    for pos, glist in zip(pos_list, pos_genes):
        current = set(glist)
        if prev_pos is not None:
            for g in list(active.keys()):
                if g not in current:
                    spans_rows.append((g, active[g], prev_pos))
                    del active[g]
        for g in current:
            if g not in active:
                active[g] = pos
        prev_pos = pos
    for g, start_pos in active.items():
        spans_rows.append((g, start_pos, prev_pos))

    spans = (pd.DataFrame(spans_rows, columns=["gene", "min", "max"])
             .sort_values("min"))

    # ── thin bar placed just ABOVE the x-axis within the same ax ───────
    # [redesign] neutral greys and slate (dark and light alternating) instead of tab20, so blue and vermillion keep their meaning (down / up)
    _greys = ["#3F4A5A", "#AEB6C2", "#6B7280", "#C9C3B8", "#57534E", "#9AA0A8", "#8C8478", "#BFC5CE"]
    gene2color = {g: _greys[i % len(_greys)] for i, g in enumerate(gene_order)}

    print("\n[GENE RANGES]")
    for g, mn, mx in spans[["gene", "min", "max"]].itertuples(index=False):
        ax.hlines(y_bar, mn, mx, lw=8,
                  color=gene2color[g], clip_on=False, zorder=4)
        print(f"  {g:10s} : {mn:>6d}–{mx:>6d}")

    # ── segmented virus: visually separate the contigs ──────────────────
    if contig_spans is not None:
        for edge in contig_spans["min"].iloc[1:]:
            ax.axvline(edge - CONTIG_GAP / 2, color="0.35", lw=.9, zorder=2)
        for name, r in contig_spans.iterrows():
            ax.text((r["min"] + r["max"]) / 2, 1.01, name, transform=ax.get_xaxis_transform(),
                    ha="center", va="bottom", fontsize=8, color="0.25")
        ax.set_xlabel("Global position (contigs separated by the grey lines)\n")

    # ───────────── 7 · legend (single row, framed) ──────────────────
    handles = [Patch(facecolor=gene2color[g], edgecolor='none')
               for g in gene_order]
    legend = ax.legend(handles,
                       gene_order,
                       title="Genes",
                       loc="upper center",
                       bbox_to_anchor=(0.5, -0.20),   # below the plot
                       ncol=len(gene_order),          # a single row
                       fontsize=8,
                       title_fontsize=9,
                       frameon=True)
    legend.get_frame().set_linewidth(0.6)
    legend.get_frame().set_edgecolor('0.4')
    # key of colours and reference lines, on the title line (never over the data)
    from matplotlib.lines import Line2D
    _key = [Line2D([], [], marker="o", ls="", markerfacecolor=_UP, markeredgecolor=_INK, markeredgewidth=.4, markersize=6, label="up (label pos), area filled above 0"),
            Line2D([], [], marker="o", ls="", markerfacecolor=_DOWN, markeredgecolor=_INK, markeredgewidth=.4, markersize=6, label="down (label neg), area filled below 0")]
    _h0, _l0 = ax.get_legend_handles_labels()
    fig.legend(_key + _h0, [h.get_label() for h in _key] + _l0, loc="upper right", ncol=4, frameon=False, fontsize=8, bbox_to_anchor=(0.995, 0.995), columnspacing=1.2)

    # ───────────── 9 · finishing and saving  ─────────────────────────────
    ax.grid(True, ls=":", alpha=.3)
    ax.set_title(f"Genomic selection – {patient}", loc="left", fontsize=10, fontweight="bold")
    fig.tight_layout(rect=[0, 0.06, 1, 0.93])   # leaves room for bar + legend
    fig.savefig(outdir / f"{patient}_genome_selection.pdf")
    plt.close(fig)

# ───────────── pipeline ────────────────────────────────────────
def process(tsv_path, outdir, nperm, n_jobs, resume, freq_delta,
            thr_clear, eps_tie, times_map=None, min_first_k=10,
            covar_enable=True, covar_method="beta_diff", covar_threshold=0.01,
            covar_min_days=3, covar_min_range=0.05, covar_max_day_diff=1):
    pat = tsv_path.stem.split("_genes")[0]
    stats_out = outdir/f"{pat}_variant_stats.tsv"
    if resume and stats_out.exists():
        print(f"⏭️  {pat}: already processed (skip)"); return
    print(f"\n🧬 Processing patient: {pat}")
    print("=" * 50)
    contig_of, cpos_of = load_contig_maps(tsv_path)
    if contig_of and len(set(contig_of.values())) > 1:
        print(f"   Segmented/multi-contig virus: {sorted(set(contig_of.values()))} "
              "(pos = global coordinate; see columns contig and contig_pos)")

    # If n_jobs > 1, make_long already performs the variant analysis in parallel
    if n_jobs > 1:
        long, gene_of, aaidx_of, annot_of, stats = make_long(tsv_path, depth_any=100, n_jobs=n_jobs, 
                                                               nperm=nperm, freq_delta=freq_delta,
                                                               thr_clear=thr_clear, eps_tie=eps_tie)
        long.to_csv(outdir/f"{pat}_long.tsv",sep="\t",index=False)
        
        if not stats:
            print("   (nothing passes the filters)"); return
        df_full = pd.DataFrame(stats)
    else:
        # Sequential processing
        long,gene_of,aaidx_of,annot_of = make_long(tsv_path, depth_any=100, n_jobs=n_jobs,
                                                       nperm=nperm, freq_delta=freq_delta,
                                                       thr_clear=thr_clear, eps_tie=eps_tie)
        long.to_csv(outdir/f"{pat}_long.tsv",sep="\t",index=False)

        # --- we summarize mean frequencies for ALL lines (pos,var)
        _, fmean_pos = build_freq_summaries(long)

        groups = list(long.groupby(["pos","var"]))
        print(f"🔬 Analyzing {len(groups)} variants with {n_jobs} cores...")
        work = Parallel(n_jobs=n_jobs,backend="loky")(
            delayed(analyse_variant)(
                        g, nperm, gene_of, aaidx_of, annot_of,
                        long, freq_delta, fmean_pos, thr_clear, eps_tie)
                for g in tqdm(groups,desc=f"Analyzing {pat}",unit="var"))
        stats=[d for d in work if d]
        
        if not stats:
            print("   (nothing passes the filters)"); return
        df_full = pd.DataFrame(stats)


    # ── LATER RE-ANNOTATION (only in process):
    #     If in the SAME codon (triplet) there are ≥2 selected POSITIONS
    #     (any line with tag ∈ {pos,neg}), we mark that codon as ambiguous
    #     for ALL lines (pos,var) that fall in that triplet.
    
    # Compute fmean_pos if not available (multi-core mode)
    if n_jobs > 1:
        _, fmean_pos = build_freq_summaries(long)
    
    selected_positions = set(df_full.loc[df_full["tag"].isin(["pos","neg"]), "pos"])

    def _triples(p: int):
        """Actual triplets from ALL reads at the position (not 'pos-(cp-1)..+2')."""
        return [a[5] for a in (annot_of.get(int(p)) or [])]

    def _is_multisel_codon(p: int) -> bool:
        return any(sum((q in selected_positions) for q in t) >= 2 for t in _triples(p))

    def _detail_reason(p: int) -> str:
        ts = _triples(p)
        if not ts:
            return "amb_due_to_multi_sel: no_codon_pos"
        t = ts[0]
        sel = [q for q in t if q in selected_positions]
        return (f"amb_due_to_multi_sel: codon={t[0]},{t[1]},{t[2]} "
                f" selected={','.join(map(str, sel)) if sel else '[]'}")

    mask_multi = df_full["pos"].apply(_is_multisel_codon)
    if mask_multi.any():
        print(f"🔄 Recomputing {mask_multi.sum()} variants in codons with multiple selections...")
        if "other_frames" not in df_full.columns:
            df_full["other_frames"] = ""

        # Recompute codon and aa_change with known selected_positions
        for idx in df_full[mask_multi].index:
            row = df_full.loc[idx]
            pos = int(row["pos"])
            frames = annotate_frames(pos, row["var"], row["beta"], annot_of.get(pos, []), fmean_pos,
                                     thr_clear, eps_tie, selected_positions=selected_positions,
                                     force_amb_if_multisel=True)
            df_full.at[idx, "other_frames"] = format_other_frames(frames)
            main_f = frames[0]
            if not main_f["multisel"]:
                continue        # only another read (another frame) has several selections
            df_full.at[idx, "codon"] = main_f["codon"]
            df_full.at[idx, "ambiguous"] = True  # Force ambiguous=True due to multi-selection
            df_full.at[idx, "aa_change"] = main_f["aa_change"]

            # Add reason to the detail (without losing the previous one)
            prev_detail = str(row.get("annot_detail", ""))
            reason = _detail_reason(pos)
            new_detail = reason if (not prev_detail or prev_detail == "nan") else f"{prev_detail} | {reason}"
            df_full.at[idx, "annot_detail"] = new_detail

    # ───────── Build ranked first (with the day/k/n lists still alive) ─────────
    print("📋 Building variant ranking...")
    ranked_pre = df_full[df_full["tag"]!=""].sort_values("score", ascending=False).copy()
    
    # ───────── Add column with the part of the variant after the hyphen ─────────
    ranked_pre["variant_suffix"] = ranked_pre["var"].str.split("-", n=1).str[1].fillna("")

    # ───────── Compute real date for ALL variants with n_days > 0 ─────────
    first_day = None
    if times_map and pat in times_map:
        print("📅 Computing first-observation dates...")
        t0 = times_map.get(pat)  # datetime.date
        if t0 is not None:
            # Filter ALL rows with n_days > 0 (not only the positive ones)
            valid_idx = ranked_pre.index[ranked_pre["n_days"] > 0]
            print(f"📊 Total variants with n_days > 0: {len(valid_idx)}")
            
            if len(valid_idx) > 0:
                # Build a "long" table with (pos,var,day,k) of all valid variants
                recs = []
                debug_samples = []
                for idx in tqdm(valid_idx, desc="Computing dates", unit="var"):
                    try:
                        days = ranked_pre.at[idx, "day"]
                        ks   = ranked_pre.at[idx, "k"]
                        p    = ranked_pre.at[idx, "pos"]
                        v    = ranked_pre.at[idx, "var"]
                        tag  = ranked_pre.at[idx, "tag"]
                    except Exception as e:
                        print(f"❌ Error extracting data for idx {idx}: {e}")
                        continue
                    
                    if not isinstance(days, (list, tuple)) or not isinstance(ks, (list, tuple)):
                        print(f"⚠️  Invalid data for {p}-{v}: days={type(days)}, ks={type(ks)}")
                        continue
                    
                    # Find the first day where k >= min_first_k
                    first_valid_day = None
                    
                    # Create list of (relative_day, k) sorted by day
                    # NOTE: The days in the cells are ALREADY relative days since t0 (0, 5, 15, 20...)
                    # They are NOT sample indices
                    day_k_pairs = []
                    for d, k in zip(days, ks):
                        try:
                            if d is None: 
                                continue
                            kf = float(k) if k is not None else 0.0
                            # The days already come as relative days since t0
                            day_k_pairs.append((int(d), kf))
                        except Exception as e:
                            print(f"❌ Error processing day {d}, k {k}: {e}")
                            continue
                    
                    # Sort by day and find the first valid day
                    day_k_pairs.sort(key=lambda x: x[0])  # Sort by day
                    for real_day, kf in day_k_pairs:
                        if kf >= float(min_first_k):
                            first_valid_day = real_day
                            
                            # Debug: print first samples
                            if len(debug_samples) < 5:
                                debug_samples.append({
                                    'pos': p, 'var': v, 'tag': tag,
                                    'day': real_day,
                                    'k': kf, 'min_first_k': min_first_k,
                                    'days_list': days, 'ks_list': ks,
                                    'day_k_pairs': day_k_pairs
                                })
                            break  # Take the first day that meets the condition
                    
                    if first_valid_day is not None:
                        recs.append((p, v, first_valid_day))
                    else:
                        print(f"⚠️  No valid day found for {p}-{v} (tag: {tag})")
                
                print(f"🔍 Debug samples (first 5):")
                for sample in debug_samples:
                    print(f"  {sample}")
                
                if recs:
                    pos_long = pd.DataFrame(recs, columns=["pos","var","day"])
                    first_day = (pos_long
                                 .groupby(["pos","var"], as_index=False)["day"]
                                 .min()
                                 .rename(columns={"day":"first_seen_day"}))
                    # Convert to calendar date
                    first_day["date"] = first_day["first_seen_day"] \
                        .apply(lambda d: (t0 + dt.timedelta(days=int(d))).isoformat())
                    
                    print(f"📅 Dates computed: {len(first_day)} variants")
                    
                    # Merge only the date column into ranked_pre
                    ranked_pre = ranked_pre.merge(first_day[["pos","var","date"]],
                                                  on=["pos","var"], how="left")
                else:
                    print("❌ No valid variants found to compute dates")

    # ───────── Save variant_stats with day/k/n as JSON (as before) ─────────
    df_full_out = add_contig_cols(df_full, contig_of, cpos_of).copy()
    df_full_out["day"] = df_full_out["day"].apply(json.dumps)
    df_full_out["k"]   = df_full_out["k"].apply(json.dumps)
    df_full_out["n"]   = df_full_out["n"].apply(json.dumps)
    df_full_out.to_csv(outdir/f"{pat}_variant_stats.tsv", sep="\t", index=False)

    # ───────── Save selected_ranked with 'date' and without lists ─────────
    ranked_out = ranked_pre.drop(columns=["day","k","n"], errors="ignore")

    # ───────── Covariation (selected variants only) AFTER threading ─────────
    if covar_enable:
        print(f"🔍 Computing covariation by β similarity (Δβ ≤ {covar_threshold}, Δday ≤ {covar_max_day_diff})...")
        cov_df = _compute_covariation_annotations_selected(
            ranked_pre,
            method=covar_method,
            threshold=covar_threshold,
            min_days=covar_min_days,
            min_range=covar_min_range,
            max_day_diff=covar_max_day_diff,
            first_k_min=min_first_k
        )
        print(f"📊 Covariation results: {len(cov_df)} variants analyzed")
        if not cov_df.empty:
            covarying_count = cov_df["covarying"].sum()
            print(f"✅ Found {covarying_count} covarying variants")
            ranked_out = ranked_out.merge(cov_df, on=["pos","var"], how="left")
        else:
            print("⚠️  No variants found for covariation analysis")
            ranked_out["covarying"] = False
            ranked_out["covarying_count"] = 0
            ranked_out["covarying_with"] = ""
    else:
        ranked_out["covarying"] = False
        ranked_out["covarying_count"] = 0
        ranked_out["covarying_with"] = ""
    
    # ───────── Add first-appearance date columns ─────────
    if first_day is not None:
        # Create mapping from (pos, var) to first_seen_day and date
        first_day_dict = first_day.set_index(['pos', 'var'])['first_seen_day'].to_dict()
        if 'date' in first_day.columns:
            date_dict = first_day.set_index(['pos', 'var'])['date'].to_dict()
        else:
            date_dict = {}
        
        ranked_out['days_from_t0'] = ranked_out.apply(
            lambda row: first_day_dict.get((row['pos'], row['var']), None), axis=1
        )
        ranked_out['date'] = ranked_out.apply(
            lambda row: date_dict.get((row['pos'], row['var']), None), axis=1
        )
    elif times_map and pat in times_map:
        # If we have times_map but no first_day, something went wrong
        ranked_out['days_from_t0'] = None
        ranked_out['date'] = None
    else:
        ranked_out['days_from_t0'] = "No time file provided"
        ranked_out['date'] = "No time file provided"
    
    ranked_out = add_contig_cols(ranked_out, contig_of, cpos_of)
    ranked_out.to_csv(outdir/f"{pat}_selected_ranked.tsv", sep="\t", index=False)

    df = df_full.drop(columns=["day","k","n"])

    beta_mean_all = df["beta"].mean()
    sel_mask = df["tag"].isin(["pos","neg"])
    beta_mean_sel = (df.loc[sel_mask, "beta"].mean()
                     if sel_mask.any() else None)
    print(f"   → {len(ranked_out)} labeled sites")

    # ─ summary per position + plots ───────────────────────────────
    print("📊 Generating per-position summaries...")
    plot_dir = outdir/f"{pat}_plots"; plot_dir.mkdir(exist_ok=True)

    pos_summary = summarise_positions(df)
    add_contig_cols(pos_summary, contig_of, cpos_of).to_csv(outdir/f"{pat}_per_position_summary.tsv",
                       sep="\t", index=False)

    # Quick map pos -> summary row (for titles)
    pos2row = {r.pos: r for _, r in pos_summary.iterrows()}

    # 1 figure per position with any selected line
    print(f"🎨 Generating {len(pos_summary['pos'].unique())} position plots...")
    for pos in tqdm(pos_summary["pos"].unique(), desc="Position plots", unit="pos"):
        plot_position(pat, pos, df, long,
                      beta_mean_sel, beta_mean_all,
                      pos2row.get(pos), plot_dir, gene_of, aaidx_of)

    # Global genomic figure
    print("🌍 Generating global genomic plot...")
    plot_genome(pat, df, long, outdir, beta_mean_sel, beta_mean_all, tsv_path)

    print("\n" + "=" * 50)
    print(f"✅ Analysis completed for {pat}")
    print(f"   📊 {len(ranked_out)} labeled sites")
    print(f"   📁 Files saved in: {outdir}")
    print("=" * 50)

    print(build_final_report_text(
        patient=pat,
        sigma=350,
        nperm=nperm,
        freq_delta=freq_delta,
        thr_clear=thr_clear,
        eps_tie=eps_tie,
        depth_any=100  # <-- adjust if you change the threshold in make_long()
    ))

# ───────────── main ────────────────────────────────────────────


def main_selection():
    global PERM_SEED, ZERO_FILL
    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(
        description="Variant ranking (keeps reference)")
    parser.add_argument("tsv", nargs='+', type=pathlib.Path,
                        help="*_genes.tsv files")
    parser.add_argument("-o","--outdir", default="ranking_out", type=pathlib.Path)
    parser.add_argument("-n","--nperm",  default=2000, type=int,
                        help="permutations per variant (default 2000)")
    parser.add_argument("-j","--jobs",   default=-1, type=int,
                        help="cores (-1 = all)")
    parser.add_argument("--freq-delta",  default=0.03, type=float,
                        help="minimum Δf (e.g. 0.03 = 3 %%)")
    parser.add_argument("--resume", action="store_true",
                        help="skip patients already processed")
    parser.add_argument("--thr-clear", default=0.95, type=float,
                        help="Frequency threshold for a 'clear' base")
    parser.add_argument("--eps-tie", default=0.05, type=float,
                        help="[NO EFFECT on the decision] in 1.x |f1-f_top| was computed but never "
                             "used to decide. It is kept for compatibility: it only appears in "
                             "annot_detail. The real criterion for a 'clear base' is --thr-clear.")
    parser.add_argument("--times", type=pathlib.Path,
                        help="TSV with columns: sample<TAB>date (format d/m/yy or d/m/yyyy)")
    parser.add_argument("--legacy-no-zero-fill", dest="zero_fill", action="store_false",
                        help="as in SRASel 1.x: dates on which a variant is not observed do NOT enter the fit "
                             "(biases against variants that start from 0). By default they ARE included with frequency 0.")
    parser.set_defaults(zero_fill=True)
    parser.add_argument("--seed", type=int, default=None,
                        help="seed for the permutations: reproducible p-values independent of the "
                             "distribution across cores (default: no seed, as in 1.x)")
    parser.add_argument("--first-k-min", default=10, type=int,
                        help="Minimum reads to consider the first observation (default 10); also defines the start day in the covariation annotation")
    # ───────── Co-variation options (enabled by default) ─────────
    parser.add_argument("--no-covar", dest="covar", action="store_false",
                        help="Disables the intra-patient covariation annotation (selected variants only)")
    parser.add_argument("--covar", dest="covar", action="store_true",
                        help="Enables the intra-patient covariation annotation (default)")
    parser.set_defaults(covar=True)
    parser.add_argument("--covar-method", choices=["beta_diff"], default="beta_diff",
                        help="Covariation method: beta_diff (difference of β)")
    parser.add_argument("--covar-threshold", type=float, default=0.01,
                        help="Maximum difference of β to declare covariation (default: 0.01)")
    parser.add_argument("--covar-min-days", type=int, default=3,
                        help="Minimum number of days observed per variant to enter the analysis")
    parser.add_argument("--covar-min-range", type=float, default=0.05,
                        help="Minimum dynamic range of frequency (max-min) per variant (default: 0.05). It only affects the covariation annotation; which variants receive a statistic is decided by --freq-delta")
    parser.add_argument("--covar-max-day-diff", type=int, default=1,
                        help="Maximum difference in onset days to declare covariation (default: 1)")
    args = parser.parse_args()

    args.outdir.mkdir(exist_ok=True)
    PERM_SEED = args.seed        # (PERM_SEED and ZERO_FILL are module globals; see “global” at the start of this function)
    ZERO_FILL = args.zero_fill
    if not ZERO_FILL:
        disclaimer("--legacy-no-zero-fill: reproduces the behavior of SRASel 1.x, which DISCARDS observations with "
                      "frequency 0 (a variant that starts from 0 loses its initial points and its complementary allele may "
                      "give a different p-value).")
    if args.eps_tie != 0.05:
        disclaimer("--eps-tie does NOT influence codon inference (see --help). To tighten or "
                      "relax what is considered a 'clear base' use --thr-clear.")

    # Load patient -> min_real_date (t0) map and sample mapping
    times_map = None
    if args.times is not None and args.times.exists():
        tdf = pd.read_csv(args.times, sep="\t", header=None, names=["sample","date"], dtype=str)
        # robust date parsing (day/month/year)
        # [validation 2026-11-10, N14] same reader as integrity/build-tables (dd/mm/yy or dd/mm/yyyy); pandas inferred one format per column
        def _dmy_or_nat(x):
            try:
                return pd.Timestamp(parse_dmy(x))
            except (ValueError, TypeError, AttributeError):
                return pd.to_datetime(x, dayfirst=True, errors="coerce")
        tdf["date"] = pd.to_datetime(tdf["date"].map(_dmy_or_nat))
        # patient = everything before the last '-'
        tdf["patient"] = tdf["sample"].str.rsplit("-", n=1).str[0]
        base = (tdf.dropna(subset=["date"])
                   .groupby("patient")["date"]
                   .min())
        # convert to datetime.date
        times_map = {p: d.to_pydatetime().date() for p, d in base.items()}

    for tsv_file in args.tsv:
        process(tsv_file, args.outdir, args.nperm,
                args.jobs, args.resume, args.freq_delta,
                args.thr_clear, args.eps_tie,
                times_map=times_map, min_first_k=args.first_k_min,
                covar_enable=args.covar,
                covar_method=args.covar_method,
                covar_threshold=args.covar_threshold,
                covar_min_days=args.covar_min_days,
                covar_min_range=args.covar_min_range,
                covar_max_day_diff=args.covar_max_day_diff)


# ════════════════════════════════════════════════════════════════════════════════════════════════════
# Step 7 · interactive HTML report
# ════════════════════════════════════════════════════════════════════════════════════════════════════
SRASEL_REPORT_DOC = r"""
srasel report – STEP 7 of SRASel 2.0: interactive HTML report, valid for ANY virus
─────────────────────────────────────────────────────────────────────────────────────────────
Reads the prepared reference (step 0) and the results of one or more patients (steps 4 and 6) and writes
a SINGLE self-contained .html file (no internet needed, data embedded) with six tabs:

  · Summary · Variants · Trajectories · Genes · Quality · About, and ONE selection bar shared by all of them: it always works on
    ALL tested variants and highlights those with p ≤ α and |Δf| ≥ δ (a slider and two inputs; SRASel's own values by default,
    “reset” returns to them); plus gene, direction and series. SRASel's own label is shown apart. Counts are descriptive
    (p is not corrected for multiple testing).
  · Variants: Δf versus −log10 p, or a genome map (CDS track from reference/features.tsv, several segments/contigs), and a sortable
    table; a click on a point or a row opens the frequency trajectory of that variant (with --notes / --truth, extra tabs).
  · Trajectories: frequency over time of up to 8 variants, or a variant × sample heat map.
  · Quality: coverage per sample, and (collapsed) heterozygosity, divergence from the first sample, a heat map of divergence between
    all sample pairs and a heat map of diversity along the genome × time.

Nothing is specific to SARS-CoV-2: genes, contigs and length come from reference/ (srasel prepare-reference).

    srasel report --ref-dir reference --processing processing -o report.html
    srasel report --ref-dir reference --processing runA/processing runB/processing -o report.html

Each --processing is the folder that contains 04_position_time_matrices/ and 06_selection_analysis/.
The series (those with *_variant_stats.tsv) are chosen in the Series list of the selection bar; the option “All series” adds them
up and, if there are several sets, also “All · <set>”.

SEVERAL sets / references in a single report (e.g. SARS-CoV-2 + HIV + influenza) and comparison of the effect of the
mapping reference (A: NCBI reference · B: patient consensus · C: original BAMs):

    srasel report --config report.json -o report.html
    report.json = {"title","subtitle","notes": notas.json,
                    "groups": [{"name","ref_dir","series":[{"processing","key","name","id","mode","canon","notes_key","ref_note"}]}],
                    "comparisons": [{"title","text","series":[id,…],"labels":[…]}]}
    “canon” = folder of srasel transfer-annotation (coord_map.tsv, aa_map.tsv): converts positions and amino acids to the canonical
    numbering; the “Mapping reference” section of the About tab thus pairs the variants of the three versions.

Diversity: at each position, H = 1 − Σ f² over A,C,G,T; alleles with f < --min-maf are discarded
(sequencing error) and so are positions with depth < --min-depth. Divergence between two samples:
mean, over the positions covered in both, of the total variation distance ½ Σ|f_i − f_j|.
"""

REPORT_TEMPLATE = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SRASel report</title>
<style>
:root{
  color-scheme:light;
  --navy:#10243A; --acc:#1463E8; --acch:#0B4FC4; --accbg:#EAF1FD; --bg:#F5F7FA; --surface:#FFFFFF; --line:#E1E6EE; --grid:#EDF0F5;
  --text:#1C2B3A; --text2:#44566C; --muted:#5F6E83; --chip:#F0F3F8;
  --ok:#16865D; --warn:#B7791F; --no:#C83C45;
  --up:#D55E00; --upt:#B04A00; --down:#0072B2; --neutral:#B4BCC9; --mark:#2B4A6F;
}
@media (prefers-color-scheme:dark){
  :root:where(:not([data-theme="light"])){
    color-scheme:dark;
    --navy:#D4E3F7; --acc:#6EA2FF; --acch:#8DB8FF; --accbg:#1B2B44; --bg:#0E1621; --surface:#152131; --line:#2A3B52; --grid:#223148;
    --text:#E6ECF4; --text2:#B7C4D6; --muted:#93A3B8; --chip:#1D2C42;
    --ok:#3DBB8A; --warn:#E0A94A; --no:#F07C84;
    --up:#F0883E; --upt:#F0883E; --down:#56B4E9; --neutral:#4A5B73; --mark:#8FB2DE;
  }
}
:root[data-theme="dark"]{
  color-scheme:dark;
  --navy:#D4E3F7; --acc:#6EA2FF; --acch:#8DB8FF; --accbg:#1B2B44; --bg:#0E1621; --surface:#152131; --line:#2A3B52; --grid:#223148;
  --text:#E6ECF4; --text2:#B7C4D6; --muted:#93A3B8; --chip:#1D2C42;
  --ok:#3DBB8A; --warn:#E0A94A; --no:#F07C84;
  --up:#F0883E; --upt:#F0883E; --down:#56B4E9; --neutral:#4A5B73; --mark:#8FB2DE;
}
*{box-sizing:border-box}
[hidden]{display:none!important}
body{margin:0;font:14px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;color:var(--text);background:var(--bg)}
button,select,input{font:inherit;color:inherit}
input[type=checkbox]{accent-color:var(--acc)}
:focus-visible{outline:2px solid var(--acc);outline-offset:2px}
a{color:var(--acc)}
#top{background:var(--surface);border-bottom:1px solid var(--line)}
@media (min-width:900px) and (min-height:640px){#top{position:sticky;top:0;z-index:20}}
.wrap{max-width:1180px;margin:0 auto;padding-left:24px;padding-right:24px}
body.vdo .wrap{max-width:none;margin:0}
@media (min-width:1000px){body.vdo #top{padding-right:min(440px,96vw)}}
.hd{display:flex;justify-content:space-between;gap:12px;align-items:baseline;padding-top:12px}
.hd h1{margin:0;font-size:17px;font-weight:650;display:inline;color:var(--navy)}
.hd .sub{color:var(--muted);font-size:13px;margin-left:10px}
.lnk{border:0;background:none;color:var(--muted);cursor:pointer;font-size:12.5px;padding:2px 4px;text-decoration:underline}
.lnk:hover{color:var(--acch)}
nav{display:flex;gap:2px;flex-wrap:wrap;padding-left:12px;padding-right:12px}
nav button{border:0;background:none;padding:9px 13px 8px;font-size:14px;color:var(--muted);cursor:pointer;border-bottom:2px solid transparent}
nav button:hover{color:var(--text)}
nav button[aria-selected="true"]{color:var(--acc);border-bottom-color:var(--acc);font-weight:600}
.bar{border-top:1px solid var(--line);background:var(--surface);padding:8px 0 7px}
html.embed .bar{border-top:0}
.brow{display:flex;gap:6px 18px;flex-wrap:wrap;align-items:center}
.brow label{display:inline-flex;gap:6px;align-items:center;color:var(--text2);font-size:13px;white-space:nowrap}
.brow select,.brow input{font-size:13px;padding:3px 6px;border:1px solid var(--line);border-radius:6px;background:var(--surface);color:var(--text);max-width:220px}
.brow input[type=number]{width:5.6em;font-variant-numeric:tabular-nums}
.brow input[type=range],.pq input[type=range]{width:120px;padding:0;border:0;background:none;accent-color:var(--acc);vertical-align:middle}
.thr{display:inline-flex;gap:6px 12px;align-items:center;flex-wrap:wrap}
.pq{display:inline-flex;gap:6px;align-items:center;font-size:12.5px;color:var(--text2);white-space:nowrap}
.pq output{font-variant-numeric:tabular-nums;min-width:3em;color:var(--text)}
.bline{margin-top:4px;font-size:13px;color:var(--text2);font-variant-numeric:tabular-nums}
.bline .m{color:var(--muted)}
main{max-width:1180px;margin:0 auto;padding:4px 24px 28px;min-width:0}
body.vdo main{max-width:none;margin:0;padding-right:calc(min(440px,96vw) + 24px)}
@media (max-width:1000px){body.vdo main{padding-right:24px}}
.panel{background:var(--surface);border:1px solid var(--line);border-radius:6px;padding:14px 16px;margin:12px 0;min-width:0}
h2{font-size:15px;margin:0 0 6px;font-weight:650;color:var(--navy)}
h3{font-size:13.5px;margin:14px 0 4px;font-weight:650;color:var(--navy)}
p{margin:6px 0}
.lead{font-size:14.5px;margin:2px 0 10px}
.cap{font-size:12.5px;color:var(--muted);margin:6px 0 0}
.muted{color:var(--muted)}.small{font-size:12.5px}
code,pre{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12.5px}
code{background:var(--chip);padding:1px 4px;border-radius:4px}
pre{background:var(--chip);border-radius:6px;padding:10px 12px;overflow-x:auto;margin:6px 0;white-space:pre-wrap;word-break:break-all}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px}
.kpi{border:1px solid var(--line);border-radius:6px;padding:8px 12px}
.kpi .l{font-size:12px;color:var(--muted)}
.kpi .v{font-size:22px;font-weight:650;line-height:1.2;color:var(--navy);font-variant-numeric:tabular-nums}
.kpi .s{font-size:12px;color:var(--muted)}
.vb{display:flex;gap:8px 16px;flex-wrap:wrap;align-items:center;margin:0 0 8px}
.seg{display:inline-flex;border:1px solid var(--line);border-radius:6px;overflow:hidden}
.seg button{border:0;background:var(--surface);color:var(--text2);padding:4px 12px;cursor:pointer;font-size:13px}
.seg button+button{border-left:1px solid var(--line)}
.seg button[aria-pressed="true"]{background:var(--accbg);color:var(--acc);font-weight:600}
.btn{border:1px solid var(--line);background:var(--surface);color:var(--text2);padding:3px 10px;border-radius:6px;cursor:pointer;font-size:12.5px}
.btn:hover{border-color:var(--acc);color:var(--acch)}
.btn:disabled{opacity:.45;cursor:default}
.btn:disabled:hover{border-color:var(--line);color:var(--text2)}
.tw{overflow:auto;max-height:560px;margin:6px 0;border:1px solid var(--line);border-radius:6px}
.tw.free{max-height:none}
table{border-collapse:collapse;width:100%;font-size:13px}
th,td{padding:5px 9px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;white-space:nowrap;font-variant-numeric:tabular-nums}
tbody tr:last-child td{border-bottom:0}
thead th{position:sticky;top:0;background:var(--surface);color:var(--text2);font-weight:600;border-bottom:2px solid var(--line);z-index:1}
th .thb{border:0;background:none;padding:0;font-weight:600;color:inherit;cursor:pointer;text-align:inherit}
th .thb:hover{color:var(--acch)}
.num{text-align:right}
tbody tr[data-j]{cursor:pointer}
tbody tr[data-j]:hover{background:var(--chip)}
tbody tr.sel{background:var(--accbg)}
.t-up{color:var(--upt);font-weight:600}.t-dn{color:var(--down);font-weight:600}
.wrapc td,.wrapc th{white-space:normal}
.tbar{display:flex;gap:6px 12px;flex-wrap:wrap;align-items:center;margin:2px 0 4px;font-size:12.5px;color:var(--text2)}
.tbar input[type=search]{font-size:13px;padding:3px 8px;border:1px solid var(--line);border-radius:6px;background:var(--surface);color:var(--text);width:min(100%,300px)}
.tbar select{font-size:12.5px;padding:2px 5px;border:1px solid var(--line);border-radius:6px;background:var(--surface);color:var(--text)}
.tbar .grow{flex:1}
.tbar .pg{display:inline-flex;gap:6px;align-items:center;font-variant-numeric:tabular-nums}
svg{display:block;width:100%;overflow:visible}
svg text{fill:var(--text2);font-size:11px;font-variant-numeric:tabular-nums}
.legend{display:flex;gap:4px 16px;flex-wrap:wrap;font-size:12.5px;color:var(--text2);margin:6px 0 0;align-items:center}
.legend span{display:inline-flex;gap:6px;align-items:center}
.legend button.lg{display:inline-flex;gap:6px;align-items:center;border:0;background:none;padding:1px 3px;border-radius:6px;cursor:pointer;font-size:12.5px;color:var(--text2)}
.legend button.lg[aria-pressed="false"]{opacity:.45;text-decoration:line-through}
.legend svg.sw{display:inline-block;width:14px;height:14px;overflow:visible}
.dot{display:inline-block;width:10px;height:10px;border-radius:50%}.dot.ring{border:2px solid var(--text)}
.tri{display:inline-block;width:0;height:0;border-left:5px solid transparent;border-right:5px solid transparent}
.tri.u{border-bottom:9px solid var(--up)}.tri.d{border-top:9px solid var(--down)}
.nd{display:inline-block;width:14px;height:10px;border:1px solid var(--line);vertical-align:-1px;background:repeating-linear-gradient(135deg,var(--chip) 0 3px,var(--muted) 3px 4px)}
.cbar{margin-top:8px;font-size:12px;color:var(--text2);max-width:440px;font-variant-numeric:tabular-nums}
.cbar .ct{margin-bottom:2px}
.cbar i{display:block;width:100%;height:10px;border-radius:3px;border:1px solid var(--line)}
.cbar .tk{position:relative;height:14px;margin-top:1px}
.cbar .tk span{position:absolute;transform:translateX(-50%);white-space:nowrap}
.cbar .tk span.l{transform:none}.cbar .tk span.r{transform:translateX(-100%)}
.zh{position:relative}
.zb{position:absolute;top:0;right:0;z-index:3;opacity:0;display:flex;gap:4px}
.zh:hover>.zb,.zb:focus-within{opacity:1}
@media(hover:none){.zb{opacity:.9}}
.zb button{border:1px solid var(--line);background:var(--surface);color:var(--text2);border-radius:6px;font-size:12px;padding:1px 7px;cursor:pointer}
.zb button:hover{border-color:var(--acc);color:var(--acch)}
#zm{position:fixed;inset:0;background:rgba(16,36,58,.6);z-index:100;display:none;padding:3vh 2.5vw}
#zm .box{background:var(--surface);border-radius:6px;height:100%;display:flex;flex-direction:column;overflow:hidden;border:1px solid var(--line)}
#zm .zbar{display:flex;gap:14px;align-items:center;padding:8px 14px;border-bottom:1px solid var(--line);flex-wrap:wrap}
#zm .zbar b{font-size:14px;max-width:48%;color:var(--navy)}
#zm .zbtns{margin-left:auto;display:flex;gap:6px}
#zm .zbody{flex:1;overflow:hidden;padding:8px 14px;min-height:0}
#zm .zbody svg{cursor:grab}
.tip{position:fixed;pointer-events:none;background:#10243A;color:#F4F6FA;border:1px solid #2A3B52;border-radius:6px;padding:6px 9px;font-size:12px;z-index:200;display:none;max-width:340px;line-height:1.4;font-variant-numeric:tabular-nums}
.tip b{display:block}
.tip.def{font-size:12.5px;max-width:360px}
.hi{display:inline-block;width:16px;height:16px;padding:0;margin:0 0 0 4px;border:1px solid var(--muted);border-radius:50%;background:var(--surface);color:var(--muted);cursor:help;font-size:11px;line-height:13px;text-align:center;vertical-align:middle;font-weight:600}
.hi::before{content:"?"}
.hi:hover,.hi:focus-visible,.hi[aria-expanded="true"]{border-color:var(--acc);color:var(--acch)}
.dyn{display:grid;grid-template-columns:300px minmax(0,1fr);gap:14px;align-items:start}
@media (max-width:900px){.dyn{grid-template-columns:1fr}.dlist{max-height:230px}}
.dlist{border:1px solid var(--line);border-radius:6px;padding:8px;max-height:560px;overflow:auto}
.dlist input[type=search]{width:100%;font-size:13px;padding:3px 6px;border:1px solid var(--line);border-radius:6px;background:var(--surface);color:var(--text)}
.drow{display:flex;gap:6px;align-items:center;padding:2px 3px;border-radius:6px;font-size:12.5px}
.drow:hover{background:var(--chip)}.drow.sel{background:var(--accbg)}
.drow .dl{flex:1;cursor:pointer;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.drow .dp{white-space:nowrap;font-variant-numeric:tabular-nums}.drow .dp.up{color:var(--upt)}.drow .dp.dn{color:var(--down)}
.opts{display:flex;gap:6px 16px;flex-wrap:wrap;align-items:center;margin-bottom:6px;font-size:12.5px}
.opts label{display:inline-flex;gap:5px;align-items:center;color:var(--text2)}
.opts select{font-size:12.5px;padding:2px 5px;border:1px solid var(--line);border-radius:6px;background:var(--surface);color:var(--text);max-width:230px}
#vd{position:fixed;top:0;right:0;bottom:0;width:min(440px,96vw);background:var(--surface);border-left:1px solid var(--line);transform:translateX(106%);transition:transform .15s;z-index:30;overflow:auto;padding:12px 14px}
@media (prefers-reduced-motion:reduce){#vd{transition:none}}
#vd.open{transform:none}
#vd .vh{display:flex;justify-content:space-between;gap:8px;align-items:flex-start;margin-bottom:8px;color:var(--navy)}
.kv{display:grid;grid-template-columns:128px minmax(0,1fr);gap:4px 12px;font-size:13px;margin:0 0 10px}
.kv dt{color:var(--muted)}.kv dd{margin:0;overflow-wrap:anywhere;font-variant-numeric:tabular-nums}
#vd .alt{padding:3px 5px;border-radius:6px;cursor:pointer;font-size:12.5px}#vd .alt:hover{background:var(--chip)}
#vd summary,details.fold>summary{cursor:pointer;font-weight:600;font-size:13px;margin:8px 0 4px;color:var(--navy)}
.note{border:1px solid var(--line);border-left:3px solid var(--acc);padding:7px 12px;border-radius:6px;font-size:13px;margin:8px 0}
.note.warn{border-left-color:var(--warn)}
.checks{list-style:none;margin:0;padding:0}.checks li{padding:6px 0;border-bottom:1px solid var(--line)}.checks li:last-child{border-bottom:0}
.ok{color:var(--ok);font-weight:600}.bad{color:var(--no);font-weight:600}
.two{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,420px),1fr));gap:14px;align-items:start}
@media (max-width:640px){.wrap,main{padding-left:12px;padding-right:12px}nav{padding-left:0;padding-right:0}.hd .sub{display:block;margin:0}}
html.embed .hd,html.embed nav{display:none}
html.embed #top{position:sticky;top:0;z-index:20}
@media print{
  html{color-scheme:light}
  body{background:#fff}
  #top{position:static!important;border:0}.hd .lnk,nav,.zb,#vd,.tip,#zm,.tbar,.btn{display:none!important}
  .panel{break-inside:avoid;border-color:#bbb}.tw{max-height:none;overflow:visible}
}
</style>
</head>
<body>
<!-- Embedding contract (the host page draws its own tab bar; this page keeps working alone):
     URL hash  #tab=<id>      id = summary | variants | traj | genes | quality | about  (+ sim, val when the report has them); unknown ids are ignored;
                              the hash is rewritten with history.replaceState when a tab is clicked, and a hashchange switches the tab.
     URL hash  #embed=1       hides the report's own title, theme button and tab bar (the selection bar stays); #theme=light|dark forces a theme.
     Other keys written by the page: p (series), a, d (thresholds), g (gene), dir, v (open variant). Old links with t=<id> still work.
     postMessage (for hosts that load the report with srcdoc and so cannot change a hash): the host sends {type:"srasel-report", tab:"variants", embed:true, theme:"dark"}
     (every key optional); the report answers the parent with {type:"srasel-report", event:"ready"|"tab", tab:<id>, tabs:[[id,label],...], embed:<bool>}. -->
<div id="top">
  <div class="hd wrap"><div><h1 id="h1"></h1><span class="sub" id="sub"></span></div>
    <button class="lnk" id="theme" type="button" aria-label="Switch between light and dark theme">Light / dark</button></div>
  <nav id="nav" class="wrap" role="tablist" aria-label="Report sections"></nav>
  <div class="bar" id="bar"><div class="wrap">
    <div class="brow">
      <span class="thr" id="bThr">
        <label>p ≤ <input id="bP" data-thr="p" type="number" min="0" max="1" step="0.001" aria-label="p threshold">
          <input id="bPr" data-thr="p" type="range" min="-3.3" max="0" step="0.01" aria-label="p threshold, logarithmic slider"></label><button class="hi" type="button" data-h="p" aria-label="What is p?"></button>
        <label>|Δf| ≥ <input id="bD" data-thr="d" type="number" min="0" max="1" step="0.01" aria-label="absolute frequency change threshold"></label><button class="hi" type="button" data-h="df" aria-label="What is Δf?"></button>
        <button class="lnk" id="bReset" type="button" title="Back to SRASel's own thresholds">reset</button></span>
      <label id="lGene">Gene <select id="bGene" aria-label="Gene"></select></label>
      <label id="lDir">Direction <select id="bDir" aria-label="Direction of change">
        <option value="both">both</option><option value="up">up</option><option value="down">down</option></select></label>
      <label id="lSer" hidden>Series <select id="bSer" aria-label="Series"></select></label>
    </div>
    <div class="bline" id="bCount" aria-live="polite"></div>
  </div></div>
</div>
<main id="main" role="tabpanel" aria-labelledby="tab-summary"></main>
<aside id="vd" aria-label="Variant details"></aside>
<div class="tip" id="tip"></div>
<div class="tip def" id="htip" role="tooltip"></div>
<div id="helpdefs" hidden></div>
<div id="zm" role="dialog" aria-modal="true" aria-label="Enlarged chart"><div class="box">
  <div class="zbar"><b id="zt"></b><span class="small muted">wheel = zoom · drag = pan · double click = reset · Esc = close</span>
    <span class="zbtns"><button class="btn" id="zin" type="button" aria-label="Zoom in">+</button><button class="btn" id="zout" type="button" aria-label="Zoom out">−</button><button class="btn" id="zrs" type="button">Reset</button><button class="btn" id="zx" type="button">Close</button></span></div>
  <div class="zbody" id="zbody"></div></div></div>
<script>
const DATA = /*__DATA__*/null;
if (!DATA.refs) { DATA.refs = [DATA.ref]; DATA.groups = [{name: DATA.title, ref_dir: DATA.ref_dir}]; DATA.patients.forEach(p => p.g = 0); }
DATA.compare = DATA.compare || [];
const NS = "http://www.w3.org/2000/svg";
const $ = (s, r = document) => r.querySelector(s);
const ESC = {"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"};
const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ESC[c]);
const refOf = p => DATA.refs[p.g || 0];
const D0 = DATA.defaults, PMIN = 1 / D0.nperm;
/* Colour = meaning, the same on every figure: up = vermillion, down = blue, SRASel label = dark ring, does not pass = gray (Okabe-Ito).
   OKI colours SERIES (several variants or patients in one chart): the two direction colours are left out on purpose, and every series
   also gets its own marker shape (SHP), so colour is never the only code. */
const OKI = ["#009E73", "#CC79A7", "#E69F00", "#6A4FD0", "var(--mark)", "#A0522D", "#7a7a7a", "#56B4E9"];
const SHP = ["circle", "square", "diamond", "up", "down", "circle", "square", "diamond"];
const fmt = (x, d = 2) => x == null ? "–" : Number(x).toFixed(d);
const fp = p => p == null ? "–" : p < 0.001 ? p.toExponential(1) : p.toFixed(3);
const ex = x => x == null ? "–" : String(+x);                                       // the stored value: the number as it is in DATA (the report rounds β to 8 decimals, p to 6, Δf to 5, depth to 1 when it writes DATA)
const exd = x => x == null ? "–" : String(+Number(x).toPrecision(6));               // a value computed here from the counts (observed Δf)
const pex = p => p == null ? "–" : p < 0.001 ? Number(p).toExponential() : String(+p);   // exact p; scientific notation below 1e-3 (3.2e-5)
const nlp = p => -Math.log10(Math.max(p == null ? 1 : p, PMIN / 2));
const loc = n => Number(n).toLocaleString("en-US");
const pc = (a, b) => b ? (100 * a / b).toFixed(1) + " %" : "–";
const wb = x => Math.min(100, Math.max(0, 100 * x)).toFixed(1);          // display of a Wilson bound in %: clamped to 0…100 (a bound of −1e-17 must not print as "−0")
const maxOf = (a, d) => a.length ? Math.max(...a) : d;
const pname = p => p.name || p.key;
const median = a => { const b = [...a].sort((x, y) => x - y); return b.length ? b[Math.floor(b.length / 2)] : null; };

function obsDf(v) {                       // OBSERVED difference between the last and first dates with data (not the Δf of the fit)
  const o = v.days.map((d, i) => [d, v.n[i] ? v.k[i] / v.n[i] : null]).filter(q => q[1] != null).sort((a, b) => a[0] - b[0]);
  return o.length > 1 ? o[o.length - 1][1] - o[0][1] : null;
}
DATA.patients.forEach((p, i) => { const r = refOf(p); p.variants.forEach(v => { v._i = i; v._r = r; v.dfo = obsDf(v); }); p.samples.forEach(s => { s._t = r.total; }); });
const DUP = new Set(); DATA.compare.forEach(c => c.series.slice(1).forEach(i => DUP.add(i)));   // same patient mapped another way: not counted twice

/* ───────── state ───────── */
const st = {tab: "summary", cur: DATA.groups.length > 1 ? "g0" : (DATA.patients.length > 1 ? "all" : 0), alpha: D0.p, delta: D0.df,
  gene: "", dir: "both", vview: "volcano", tview: "lines", vrows: "pass", selV: null, sortKey: "p", sortDir: 1, pins: [], gxw: null, dynS: null,
  msort: "score", mrows: 60, gsel: "", hsel: null, hcommon: false, hmode: "abs", divOpen: false, simS: null, tbl: {}, hid: new Set()};
const idxs = () => st.cur === "all" ? DATA.patients.map((_, i) => i) : /^g\d+$/.test(st.cur) ? DATA.patients.map((p, i) => i).filter(i => DATA.patients[i].g === +st.cur.slice(1)) : [st.cur];
const multi = () => typeof st.cur !== "number";
const SC = () => idxs().map(i => ({p: DATA.patients[i], i}));
const baseSeries = () => { const L = SC(); return st.cur === "all" ? L.filter(({i}) => !DUP.has(i)) : L; };
const scopeVars = () => baseSeries().flatMap(({p}) => p.variants);
const scopeRef = () => { const L = baseSeries(); return refOf((L[0] || {p: DATA.patients[0]}).p); };
const gname = p => DATA.groups[p.g || 0].name;

/* selection: ONE rule for every tab, always over ALL tested variants: a variant "passes" when p ≤ α and |Δf| ≥ δ (the bar's two thresholds,
   SRASel's own values by default). SRASel's own label (v.tag, fixed when the program ran) is shown apart (ring, "SRASel" column). */
const pass = v => v.p != null && v.df != null && v.p <= st.alpha + 1e-12 && Math.abs(v.df) >= st.delta - 1e-12;
const inMode = pass;
const isDefault = () => st.alpha === D0.p && st.delta === D0.df;
const fa = a => +a.toPrecision(2);
const geneOK = v => !st.gene || (v.gene || "non-coding") === st.gene;
const dirOK = v => st.dir === "both" || (st.dir === "up" ? v.df > 0 : v.df < 0);
const inSel = v => inMode(v) && geneOK(v) && dirOK(v);
const dirCol = v => v.df > 0 ? "var(--up)" : "var(--down)";
const tagTxt = v => v.tag === "pos" ? '<span class="t-up">up</span>' : v.tag === "neg" ? '<span class="t-dn">down</span>' : '<span class="muted">–</span>';
const tagWord = v => v.tag === "pos" ? "up" : v.tag === "neg" ? "down" : "none";
const key = v => v.pos + ":" + v.var;
const posKey = v => v._i + "|" + (v.c || "") + "|" + v.pos;
const where = v => (v._r.contigs.length > 1 && v.c ? v.c + ":" : "nt ") + (v.cp != null ? v.cp : v.pos);
const label = v => (v.gene || "non-coding") + " " + (v.aa || "") + " · " + where(v) + " " + v.var;
const labelS = v => (DATA.patients.length > 1 ? pname(DATA.patients[v._i]) + " · " : "") + label(v);
const rank2 = v => Math.abs(v.dfo == null ? 0 : v.dfo) * nlp(v.p);     // comparable between series of different duration
const score = v => Math.abs(v.beta || 0) * nlp(v.p);                    // = |β|·(−log10 p), the program score
const mpCell = v => v.mp ? v.mp.map(m => `<b>${esc(m[0])}</b> <span class="small muted">(${esc(v.gene)} ${m[1]}–${m[2]} · aa ${m[3]} of the peptide)</span>`).join("<br>") : "";
const thr = () => ({a: st.alpha, d: st.delta});
function tally(list, filt = true) {
  const pos = new Set(), sp = new Set(), lp = new Set(); let ns = 0, up = 0, dn = 0, lab = 0;
  list.forEach(v => { pos.add(posKey(v)); if (inSel(v)) { ns++; sp.add(posKey(v)); if (v.df > 0) up++; else if (v.df < 0) dn++; } if (v.tag && (!filt || (geneOK(v) && dirOK(v)))) { lab++; lp.add(posKey(v)); } });
  return {nv: list.length, np: pos.size, ns, nsp: sp.size, up, dn, lab, lp: lp.size};
}

/* ───────── drawing helpers ───────── */
const tip = $("#tip"), main = $("#main");
function el(name, attrs = {}, parent) {
  const e = document.createElementNS(NS, name);
  for (const k in attrs) e.setAttribute(k, attrs[k]);
  if (parent) parent.appendChild(e);
  return e;
}
function showTip(ev, html) {
  tip.innerHTML = html; tip.style.display = "block";
  const w = tip.offsetWidth, h = tip.offsetHeight;
  let x = ev.clientX + 14, y = ev.clientY + 14;
  if (x + w > innerWidth - 8) x = ev.clientX - w - 14;
  if (y + h > innerHeight - 8) y = ev.clientY - h - 14;
  tip.style.left = x + "px"; tip.style.top = y + "px";
}
const hideTip = () => tip.style.display = "none";
let HSCALE = 1;
function hov(node, html, r0) {
  const circ = node.tagName === "circle";
  node.addEventListener("mousemove", ev => { if (circ) node.setAttribute("r", +r0 + 2.5); showTip(ev, typeof html === "function" ? html() : html); });
  node.addEventListener("mouseleave", () => { if (circ) node.setAttribute("r", r0); hideTip(); });
}
/* marker of a given shape (circle, square, diamond, up, down) centred on cx, cy */
function shapeOf(shape, cx, cy, r) {
  if (shape === "square") return ["rect", {x: cx - r * .85, y: cy - r * .85, width: r * 1.7, height: r * 1.7}];
  if (shape === "diamond") return ["polygon", {points: `${cx},${cy - r * 1.25} ${cx + r * 1.25},${cy} ${cx},${cy + r * 1.25} ${cx - r * 1.25},${cy}`}];
  if (shape === "up") return ["polygon", {points: `${cx},${cy - r * 1.2} ${cx + r * 1.1},${cy + r * .85} ${cx - r * 1.1},${cy + r * .85}`}];
  if (shape === "down") return ["polygon", {points: `${cx},${cy + r * 1.2} ${cx + r * 1.1},${cy - r * .85} ${cx - r * 1.1},${cy - r * .85}`}];
  return ["circle", {cx, cy, r}];
}
const mk = (parent, shape, cx, cy, r, a = {}) => { const [t, g] = shapeOf(shape, cx, cy, r); return el(t, {...g, ...a}, parent); };
const swatch = (shape, color) => { const [t, g] = shapeOf(shape, 0, 0, 5); return `<svg class="sw" viewBox="-7 -7 14 14" aria-hidden="true"><${t} ${Object.entries(g).map(([k, v]) => `${k}="${v}"`).join(" ")} fill="${color}"/></svg>`; };
const scale = (d0, d1, r0, r1) => v => r0 + (v - d0) / ((d1 - d0) || 1) * (r1 - r0);
function niceTicks(max, n) {
  if (!(max > 0)) return [0];
  const raw = max / n, mag = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / mag;
  const step = (f < 1.5 ? 1 : f < 3.5 ? 2 : f < 7.5 ? 5 : 10) * mag, out = [];
  for (let v = 0; v <= max + 1e-9; v += step) out.push(+v.toPrecision(12));
  return out;
}
const sg = v => String(+Number(v).toPrecision(5));                        // enough digits, scientific notation for tiny values
const kfmt = v => v >= 1000 ? +(v / 1000).toFixed(1) + "k" : String(v);
const symT = (lim, step) => { const o = [0]; for (let v = step; v <= lim + 1e-9; v += step) { const r = +v.toFixed(3); o.push(r, -r); } return o; };
const sampleOf = (p, d) => p.samples.filter(s => s.day === d).map(s => s.id).join("/");
const tipOf = v => {
  const o = v.days.map((d, i) => [d, v.n[i] ? v.k[i] / v.n[i] : 0]).sort((a, b) => a[0] - b[0]), f0 = o[0], f1 = o[o.length - 1];
  return `<b>${esc(label(v))}</b>${DATA.patients.length > 1 ? esc(pname(DATA.patients[v._i])) + "<br>" : ""}Estimated Δf ${ex(v.df)}${v.dfo != null ? " · observed " + exd(v.dfo) : ""}<br>p = ${pex(v.p)}<br>β ${ex(v.beta)} /day (${fmt(v.beta * 1000, 3)} ‰/day) · mean depth ${v.depth == null ? "–" : ex(v.depth)}×` +
    (f0 ? `<br>frequency ${fmt(f0[1] * 100, 1)} % (day ${f0[0]}) → ${fmt(f1[1] * 100, 1)} % (day ${f1[0]}) over ${o.length} dates` : "") +
    `<br>SRASel label: ${tagWord(v)} · thresholds of the bar: ${pass(v) ? "passes" : "does not pass"}` + (v.of ? `<br>other reading frames: ${esc(v.of)}` : "") + `<br><span style="opacity:.7">stored values of the report</span>` +
    (v.mp ? v.mp.map(m => `<br>mature protein: <b>${esc(m[0])}</b> (${esc(v.gene)} ${m[1]}–${m[2]}) · aa ${m[3]} of the peptide`).join("") : "");
};
/* colour scale: title, gradient and numeric ticks; ticks = [[u, "label"], …] with u in 0…1 along the bar; mid = diverging scale (u 0…1 ↔ −1…+1) */
function cbar(host, title, ticks, color, mid) {
  const grad = [0, .125, .25, .375, .5, .625, .75, .875, 1].map(u => color(mid ? -1 + 2 * u : u)).join(",");
  host.innerHTML = `<div class="cbar"><div class="ct">${title}</div><i style="background:linear-gradient(90deg,${grad})"></i><div class="tk">${ticks.map(([u, t]) => `<span class="${u < .03 ? "l" : u > .97 ? "r" : ""}" style="left:${(100 * u).toFixed(2)}%">${t}</span>`).join("")}</div></div>`;
}
const seqColor = t => `color-mix(in srgb, var(--mark) ${Math.round(8 + 92 * Math.max(0, Math.min(1, t)))}%, var(--surface))`;
const divColor = t => t >= 0 ? `color-mix(in srgb, var(--up) ${Math.round(100 * Math.min(1, t))}%, var(--surface))`
                              : `color-mix(in srgb, var(--down) ${Math.round(100 * Math.min(1, -t))}%, var(--surface))`;

/* generic heat map */
function heat(host, o) {
  const W = host.clientWidth || 700, nr = o.rows.length, nc = o.cols.length;
  const m = {l: o.ml || 86, t: o.mt || 6, r: 8, b: o.mb || 30};
  const cw = (W - m.l - m.r) / nc, ch = Math.min((o.maxch || 30) * HSCALE, Math.max(14, (o.maxh || 360) * HSCALE / nr));
  const H = m.t + nr * ch + m.b;
  const svg = el("svg", {viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": o.aria});
  const pt = el("pattern", {id: "nodata", width: 6, height: 6, patternUnits: "userSpaceOnUse", patternTransform: "rotate(45)"}, el("defs", {}, svg));
  el("rect", {width: 6, height: 6, fill: "var(--chip)"}, pt); el("line", {x1: 0, y1: 0, x2: 0, y2: 6, stroke: "var(--muted)", "stroke-width": 1.3, opacity: .5}, pt);
  o.rows.forEach((rl, r) => {
    el("text", {x: m.l - 6, y: m.t + r * ch + ch / 2 + 4, "text-anchor": "end"}, svg).textContent = rl;
    o.cols.forEach((cl, c) => {
      const v = o.vals[r][c], t = v == null ? null : o.norm(v);
      const rc = el("rect", {x: m.l + c * cw + .5, y: m.t + r * ch + .5, width: Math.max(1, cw - 1), height: ch - 1, rx: cw > 14 ? 2 : 1}, svg);
      if (t == null) { rc.setAttribute("fill", "url(#nodata)"); }
      else rc.setAttribute("style", "fill:" + o.color(t));
      if (o.labels && t != null && cw > 30)
        el("text", {x: m.l + c * cw + cw / 2, y: m.t + r * ch + ch / 2 + 4, "text-anchor": "middle",
          style: `font-size:11px;fill:${Math.abs(t) > .55 ? "#fff" : "var(--text)"}`}, svg).textContent = o.cellText(v);
      rc.addEventListener("mousemove", ev => showTip(ev, o.tip(r, c, v)));
      rc.addEventListener("mouseleave", hideTip);
    });
  });
  o.colLabels(svg, m, cw, nr * ch);
  host.replaceChildren(svg);
}

/* ───────── charts ───────── */
/* sampling timeline: one row per series, samples placed PROPORTIONALLY to their day; colour = mean depth of the sample (log scale), square + red outline = below 100× */
function ovFollow(host) {
  const L = baseSeries(), manyG = DATA.groups.length > 1, rh = 24, m = {l: Math.min(210, 14 + 6.6 * maxOf(L.map(({p}) => pname(p).length), 4)), r: 16, t: 8, b: 42}, W = host.clientWidth || 560;
  const rows = []; let lastG = -1; L.forEach(({p, i}) => { if (manyG && p.g !== lastG) { rows.push({hdr: gname(p)}); lastG = p.g; } rows.push({p, i}); });
  const xmax = Math.max(1, ...L.flatMap(({p}) => p.samples.map(s => s.day))), H = m.t + rows.length * rh + m.b, x = scale(0, xmax, m.l, W - m.r);
  const dmax = Math.max(2, ...L.flatMap(({p}) => p.samples.map(s => s.depth))), cf = d => Math.log10(Math.max(1, d)) / Math.log10(dmax), cs = d => seqColor(.12 + .88 * cf(d));
  const svg = el("svg", {viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Sampling timeline"});
  niceTicks(xmax, Math.max(3, Math.min(6, Math.round((W - m.l - m.r) / 80)))).forEach(t => { el("line", {x1: x(t), x2: x(t), y1: m.t, y2: H - m.b, stroke: "var(--grid)"}, svg); el("text", {x: x(t), y: H - m.b + 14, "text-anchor": "middle"}, svg).textContent = t; });
  el("text", {x: (m.l + W - m.r) / 2, y: H - 6, "text-anchor": "middle"}, svg).textContent = "time since the first sample of each series (days)";
  rows.forEach((r, j) => {
    const yy = m.t + j * rh + 11;
    if (r.hdr) { el("text", {x: 4, y: yy + 3, style: "font-weight:600"}, svg).textContent = r.hdr.length > 54 ? r.hdr.slice(0, 52) + "…" : r.hdr; return; }
    el("text", {x: m.l - 8, y: yy + 4, "text-anchor": "end"}, svg).textContent = pname(r.p);
    if (!r.p.samples.length) return;
    el("line", {x1: x(Math.min(...r.p.samples.map(s => s.day))), x2: x(Math.max(...r.p.samples.map(s => s.day))), y1: yy, y2: yy, stroke: "var(--line)", "stroke-width": 2}, svg);
    r.p.samples.forEach(s => { const low = s.depth < 100, c = mk(svg, low ? "square" : "circle", x(s.day), yy, 4.8, {fill: cs(s.depth), stroke: low ? "var(--no)" : "var(--surface)", "stroke-width": low ? 2 : 1});
      hov(c, () => `<b>${esc(pname(r.p))} · ${esc(s.id)}</b>day ${s.day}<br>mean depth ${ex(s.depth)}×${low ? "<br><b>below 100×</b>" : ""}`, 4.8); });
  });
  host.replaceChildren(svg);
  const cb = document.createElement("div"); host.appendChild(cb);
  const dt = [1, 10, 100, 1000, 10000, 100000].filter(d => d <= dmax);
  cbar(cb, "mean depth of the sample (reads, log scale)", [...dt.map(d => [cf(d), loc(d) + "×"]), ...(cf(dmax) - cf(dt[dt.length - 1]) > .2 ? [[1, loc(Math.round(dmax)) + "×"]] : [])], f => cs(Math.pow(dmax, f)));
}
/* gene lanes + contig ticks, shared by the genome charts; returns the height used below y0 */
function geneTrack(svg, REF, x, y0, W, w, o = {}) {
  const genes = REF.genes.filter(g => g.gend >= w[0] && g.gstart <= w[1]).sort((a, b) => a.gstart - b.gstart), lanes = [];
  const gl = genes.map(g => { let i = lanes.findIndex(e => e < g.gstart); if (i < 0) { i = lanes.length; lanes.push(0); } lanes[i] = g.gend; return {...g, lane: i}; });
  const mps = (REF.mp || []).filter(q => q.gs != null && q.ge >= w[0] && q.gs <= w[1]);
  const nl = Math.max(1, lanes.length), ty = y0 + 8, trackH = nl * 14 + (mps.length ? 18 : 0) + 46;
  REF.contigs.forEach((c, ci) => { const a = Math.max(c.offset + 1, w[0]), b = Math.min(c.offset + c.length, w[1]); if (b < a) return;
    el("rect", {x: x(a), y: ty, width: Math.max(1, x(b) - x(a)), height: 4, fill: "var(--text2)", opacity: .5}, svg);
    if (ci > 0 && c.offset + 1 >= w[0]) el("line", {x1: x(c.offset + 1), x2: x(c.offset + 1), y1: o.top, y2: ty + trackH - 14, stroke: "var(--muted)", "stroke-dasharray": "3 3"}, svg);
    if (REF.contigs.length > 1) el("text", {x: Math.max(o.left, x(a)) + 3, y: o.top + 10, style: "fill:var(--muted)"}, svg).textContent = c.name; });
  gl.forEach(gg => { const gx = Math.max(o.left, x(gg.gstart)), gw = Math.max(1.5, Math.min(W - o.right, x(gg.gend)) - gx), gy = ty + 8 + gg.lane * 14;
    const r = el("rect", {x: gx, y: gy, width: gw, height: 12, rx: 2, fill: "var(--neutral)", stroke: "var(--text2)", "stroke-width": .5, style: o.onGene ? "cursor:pointer" : ""}, svg);
    const co = REF.contigs.find(c => c.name === gg.contig), off = co ? co.offset : 0;
    r.addEventListener("mousemove", ev => showTip(ev, `<b>${esc(gg.name)}</b>${esc(gg.product)}<br>${esc(gg.contig)}:${loc(gg.gstart - off)}–${loc(gg.gend - off)} (${loc(gg.gend - gg.gstart + 1)} nt) · ${gg.strand === "-" ? "strand −" : "strand +"}${REF.contigs.length > 1 ? `<br>position in the concatenated reference ${loc(gg.gstart)}–${loc(gg.gend)}` : ""}`)); r.addEventListener("mouseleave", hideTip);
    if (o.onGene) r.addEventListener("click", () => o.onGene(gg));
    if (gw > gg.name.length * 6.4 + 4) el("text", {x: gx + gw / 2, y: gy + 10, "text-anchor": "middle", style: "fill:var(--text);pointer-events:none"}, svg).textContent = gg.name; });
  const py = ty + 12 + nl * 14;
  mps.forEach(q => { const gx = Math.max(o.left, x(q.gs)), gw = Math.max(1.5, Math.min(W - o.right, x(q.ge)) - gx);
    const r = el("rect", {x: gx, y: py, width: gw, height: 11, rx: 2, fill: "var(--mark)", opacity: .4, stroke: "var(--mark)", "stroke-width": .6}, svg);
    r.addEventListener("mousemove", ev => showTip(ev, `<b>${esc(q.n)}</b>mature protein of ${esc(q.g)} · aa ${q.a}–${q.b}<br>${esc(locOf(REF, q.gs))}–${esc(locOf(REF, q.ge))}`)); r.addEventListener("mouseleave", hideTip);
    if (gw > q.n.length * 6.4 + 4) el("text", {x: gx + gw / 2, y: py + 9, "text-anchor": "middle", style: "fill:var(--text);pointer-events:none"}, svg).textContent = q.n; });
  niceTicks(w[1] - w[0], Math.max(3, Math.round((W - o.left - o.right) / 110))).forEach(t => { const gpos = Math.round(w[0] + t);
    el("text", {x: x(gpos), y: ty + 24 + nl * 14 + (mps.length ? 18 : 0), "text-anchor": "middle", style: "fill:var(--muted)"}, svg).textContent = locOf(REF, gpos); });
  el("text", {x: (o.left + W - o.right) / 2, y: ty + 40 + nl * 14 + (mps.length ? 18 : 0), "text-anchor": "middle"}, svg).textContent = W < 560 ? "position in the reference (nt)" : REF.contigs.length > 1 ? "position in the reference (contig:nt); gray = genes, blue = mature proteins" : "position in the reference (nt); gray = genes" + ((REF.mp || []).length ? ", blue = mature proteins" : "");
  return trackH + 8;
}
const locOf = (REF, g) => { const c = REF.contigs.find(c => g > c.offset && g <= c.offset + c.length); return c ? (REF.contigs.length > 1 ? c.name + ":" : "") + (g - c.offset) : ""; };
function trackHeight(REF, w) {
  const genes = REF.genes.filter(g => g.gend >= w[0] && g.gstart <= w[1]).sort((a, b) => a.gstart - b.gstart), lanes = [];
  genes.forEach(g => { let i = lanes.findIndex(e => e < g.gstart); if (i < 0) { i = lanes.length; lanes.push(0); } lanes[i] = g.gend; });
  const mps = (REF.mp || []).filter(q => q.gs != null && q.ge >= w[0] && q.gs <= w[1]);
  return Math.max(1, lanes.length) * 14 + (mps.length ? 18 : 0) + 46 + 8;
}
/* Summary: number of selected positions per window along the genome */
function ovGenome(host) {
  const REF = scopeRef(), vs = scopeVars().filter(inSel), NB = 90, W = host.clientWidth || 900, m = {l: 44, r: 12, t: 10, b: 8}, mapH = 120;
  const cnt = new Array(NB).fill(0), bw = REF.total / NB, seen = new Set();
  vs.forEach(v => { const k = posKey(v); if (seen.has(k)) return; seen.add(k); cnt[Math.min(NB - 1, Math.floor((v.pos - 1) / bw))]++; });      // each position ONCE
  const mx = Math.max(1, ...cnt), w = [1, REF.total], H = m.t + mapH + trackHeight(REF, w) + m.b, x = scale(1, REF.total, m.l, W - m.r), y = scale(0, mx, m.t + mapH, m.t);
  const svg = el("svg", {viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Positions passing the thresholds along the genome"});
  niceTicks(mx, 4).filter(t => Number.isInteger(t)).forEach(t => { el("line", {x1: m.l, x2: W - m.r, y1: y(t), y2: y(t), stroke: "var(--grid)"}, svg); el("text", {x: m.l - 6, y: y(t) + 4, "text-anchor": "end"}, svg).textContent = t; });
  el("text", {transform: `translate(11 ${m.t + mapH / 2}) rotate(-90)`, "text-anchor": "middle"}, svg).textContent = "positions passing";
  for (let b = 0; b < NB; b++) { if (!cnt[b]) continue; const x0 = x(b * bw + 1), wd = Math.max(1, x((b + 1) * bw) - x0 - 1);
    const r = el("rect", {x: x0, y: y(cnt[b]), width: wd, height: y(0) - y(cnt[b]), fill: "var(--mark)"}, svg);
    r.addEventListener("mousemove", ev => showTip(ev, `<b>nt ${loc(Math.round(b * bw + 1))}–${loc(Math.round((b + 1) * bw))}</b>${cnt[b]} position${cnt[b] > 1 ? "s" : ""} with a variant passing the thresholds`)); r.addEventListener("mouseleave", hideTip); }
  geneTrack(svg, REF, x, m.t + mapH, W, w, {left: m.l, right: m.r, top: m.t});
  host.replaceChildren(svg);
  const cap = $("#sGenCap"); if (cap) cap.textContent = `Bars: positions with a variant passing the thresholds, in windows of ${loc(Math.round(bw))} nt (a position counts once; the count depends on coverage, not on “enrichment”).`;
}

/* Δf versus evidence */
function volcano(host, vs, o = {}) {
  const W = host.clientWidth || 720, H = (o.h || 400) * HSCALE, m = {l: 54, r: 18, t: 14, b: 48}, ad = vs.map(v => Math.abs(v.df)).sort((a, b) => a - b);
  const lim = Math.max(1.25, Math.ceil(Math.min(1.1 * (ad[Math.floor(ad.length * 0.995)] || 1), ad[ad.length - 1] || 1) * 4) / 4), outN = ad.filter(d => d > lim).length;
  const cxf = v => Math.max(-lim, Math.min(lim, v.df)), fill = o.fill || (v => inSel(v) ? dirCol(v) : null), pick = o.pick || pickVar, T = thr();
  const ymax = Math.ceil(nlp(PMIN) * 10) / 10 + .2, x = scale(-lim, lim, m.l, W - m.r), y = scale(0, ymax, H - m.b, m.t);
  const svg = el("svg", {viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Estimated Δf versus statistical evidence"});
  if (lim > 1) [[-lim, -1], [1, lim]].forEach(([a, b]) => el("rect", {x: x(a), y: m.t, width: x(b) - x(a), height: H - m.b - m.t, fill: "var(--muted)", opacity: .1}, svg));
  for (const v of symT(lim, lim <= 2 ? .5 : 1)) { el("line", {x1: x(v), x2: x(v), y1: m.t, y2: H - m.b, stroke: Math.abs(v) < 1e-9 ? "var(--muted)" : "var(--grid)"}, svg); el("text", {x: x(v), y: H - m.b + 15, "text-anchor": "middle"}, svg).textContent = +v.toFixed(2); }
  for (let v = 0; v <= ymax; v += 0.5) { el("line", {x1: m.l, x2: W - m.r, y1: y(v), y2: y(v), stroke: "var(--grid)"}, svg); el("text", {x: m.l - 6, y: y(v) + 4, "text-anchor": "end"}, svg).textContent = v; }
  el("text", {x: (m.l + W - m.r) / 2, y: H - 6, "text-anchor": "middle"}, svg).textContent = W < 560 ? "Estimated Δf = β × follow-up (← down · up →)" : "Estimated Δf = β × follow-up, as a fraction of frequency (← down · up →)";
  el("text", {transform: `translate(12 ${(m.t + H - m.b) / 2}) rotate(-90)`, "text-anchor": "middle"}, svg).textContent = "evidence: −log10 p (permutation)";
  el("line", {x1: m.l, x2: W - m.r, y1: y(nlp(PMIN)), y2: y(nlp(PMIN)), stroke: "var(--muted)", "stroke-dasharray": "1 3"}, svg);
  const ya = y(Math.min(ymax, -Math.log10(Math.max(T.a, 1e-9))));
  el("line", {x1: m.l, x2: W - m.r, y1: ya, y2: ya, stroke: "var(--text2)", "stroke-dasharray": "5 4", class: "thrP", "data-a": T.a}, svg);
  [-T.d, T.d].forEach(d => el("line", {x1: x(d), x2: x(d), y1: m.t, y2: H - m.b, stroke: "var(--text2)", "stroke-dasharray": "5 4", class: "thrD", "data-d": d}, svg));
  el("text", {x: m.l + 4, y: ya - 4, style: "fill:var(--text2)"}, svg).textContent = `p = ${fa(T.a)}`;
  el("text", {x: x(T.d) + 4, y: m.t + 11, style: "fill:var(--text2)"}, svg).textContent = `|Δf| = ${T.d}`;
  const isSel = v => v === st.selV, grey = vs.filter(v => !fill(v) && !v.tag && !isSel(v)); let path = "";
  grey.forEach(v => { path += `M${x(cxf(v)).toFixed(1)} ${y(nlp(v.p)).toFixed(1)}h0`; });
  el("path", {d: path, stroke: "var(--neutral)", "stroke-width": 3.4, "stroke-linecap": "round", opacity: .5, fill: "none"}, svg);
  const act = vs.filter(v => fill(v) || v.tag || isSel(v));
  act.sort((a, b) => (!!fill(a)) - (!!fill(b)));
  act.forEach((v, j) => { const f = fill(v), sel = isSel(v);
    el("circle", {cx: x(cxf(v)), cy: y(nlp(v.p)), r: sel ? 7.5 : f ? 4.6 : 3.8, fill: f || "none", stroke: sel || v.tag ? "var(--text)" : "var(--surface)",
      "stroke-width": sel ? 2.4 : v.tag ? 1.4 : .8, opacity: f ? .9 : 1, "stroke-dasharray": Math.abs(v.df) > lim ? "2 2" : null, "data-j": j, style: "cursor:pointer"}, svg); });
  svg.addEventListener("mousemove", e => { const c = e.target.closest && e.target.closest("circle[data-j]"); if (c) showTip(e, (o.tip || tipOf)(act[+c.dataset.j])); else hideTip(); });
  svg.addEventListener("mouseleave", hideTip);
  svg.addEventListener("click", e => { const c = e.target.closest && e.target.closest("circle[data-j]"); if (c) pick(act[+c.dataset.j]); });
  host.replaceChildren(svg);
  const lg = document.createElement("div"); lg.className = "legend";
  lg.innerHTML = o.legend || `<span><i class="dot" style="background:var(--up)"></i>up (Δf &gt; 0)</span><span><i class="dot" style="background:var(--down)"></i>down (Δf &lt; 0)</span><span><i class="dot ring"></i>SRASel label${hi("tag")}</span><span><i class="dot" style="background:var(--neutral)"></i>does not pass</span>
    <span class="muted">${loc(vs.length)} variants · dashed lines: p ≤ ${fa(T.a)}, |Δf| ≥ ${T.d} · dotted line: test floor, smallest possible p = 1/${D0.nperm + 1}${outN ? ` · ${outN} with |Δf| &gt; ${lim} drawn at the edge (dashed outline)` : ""}</span>`;
  host.appendChild(lg);
}

/* variants along the genome (zoom by dragging) */
function genomeX(host, REF, vs, w) {
  const W = host.clientWidth || 900, m = {l: 54, r: 14, t: 12, b: 6}, mapH = 280 * HSCALE, pvs = vs.filter(v => v.pos >= w[0] && v.pos <= w[1]);
  const H = m.t + mapH + trackHeight(REF, w) + m.b;
  const svg = el("svg", {viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Variants along the genome"});
  const ab = vs.map(v => Math.abs(v.df)).sort((a, b) => a - b), lim = Math.max(1.25, Math.ceil(Math.min(1.1 * (ab[Math.floor(ab.length * .995)] || 1), ab[ab.length - 1] || 1) * 4) / 4), cxf = v => Math.max(-lim, Math.min(lim, v.df));
  const x = scale(w[0], w[1], m.l, W - m.r), y = scale(lim, -lim, m.t, m.t + mapH);
  for (const v of symT(lim, lim <= 1.5 ? .5 : 1)) { el("line", {x1: m.l, x2: W - m.r, y1: y(v), y2: y(v), stroke: Math.abs(v) < 1e-9 ? "var(--muted)" : "var(--grid)"}, svg); el("text", {x: m.l - 6, y: y(v) + 4, "text-anchor": "end"}, svg).textContent = +v.toFixed(2); }
  el("text", {transform: `translate(12 ${m.t + mapH / 2}) rotate(-90)`, "text-anchor": "middle"}, svg).textContent = "Estimated Δf = β × follow-up (fraction of frequency)";
  niceTicks(w[1] - w[0], Math.max(3, Math.round((W - m.l - m.r) / 110))).forEach(t => { const gpos = Math.round(w[0] + t); el("line", {x1: x(gpos), x2: x(gpos), y1: m.t, y2: m.t + mapH, stroke: "var(--grid)"}, svg); });
  geneTrack(svg, REF, x, m.t + mapH, W, w, {left: m.l, right: m.r, top: m.t, onGene: gg => {
    if (!scopeVars().some(v => (v.gene || "non-coding") === gg.name)) { $("#vWin").textContent = `“${gg.name}”: no variant is assigned to this gene`; return; }
    setGene(gg.name); } });
  const isSel = v => v === st.selV, grey = pvs.filter(v => !inSel(v) && !v.tag && !isSel(v)), act = pvs.filter(v => inSel(v) || v.tag || isSel(v));
  let path = ""; grey.forEach(v => { path += `M${x(v.pos).toFixed(1)} ${y(cxf(v)).toFixed(1)}h0`; });
  el("path", {d: path, stroke: "var(--neutral)", "stroke-width": 3.2, "stroke-linecap": "round", opacity: .5, fill: "none"}, svg);
  act.sort((a, b) => (!!inSel(a)) - (!!inSel(b)));
  act.forEach((v, j) => { const ps = inSel(v), sel = isSel(v);
    el("circle", {cx: x(v.pos), cy: y(cxf(v)), r: sel ? 7.5 : ps ? 4.4 : 3.6, fill: ps ? dirCol(v) : "none", stroke: sel || v.tag ? "var(--text)" : "var(--surface)", "stroke-width": sel ? 2.4 : v.tag ? 1.4 : .8,
      opacity: ps ? .9 : 1, "stroke-dasharray": Math.abs(v.df) > lim ? "2 2" : null, "data-j": j, style: "cursor:pointer"}, svg); });
  const sel = el("rect", {y: m.t, height: mapH, fill: "var(--acc)", opacity: .12, display: "none"}, svg);
  let d0 = null;
  svg.addEventListener("mousedown", e => { if (e.target.tagName === "circle") return; const r = svg.getBoundingClientRect(); d0 = (e.clientX - r.left) * W / r.width; });
  svg.addEventListener("mousemove", e => { const c = e.target.closest && e.target.closest("circle[data-j]"); if (c) showTip(e, tipOf(act[+c.dataset.j])); else if (d0 == null) hideTip();
    if (d0 != null) { const r = svg.getBoundingClientRect(), d1 = (e.clientX - r.left) * W / r.width; sel.setAttribute("display", "block"); sel.setAttribute("x", Math.min(d0, d1)); sel.setAttribute("width", Math.abs(d1 - d0)); } });
  addEventListener("mouseup", function up(e) { removeEventListener("mouseup", up); if (d0 == null) return; const r = svg.getBoundingClientRect(), d1 = (e.clientX - r.left) * W / r.width, a = Math.min(d0, d1), b = Math.max(d0, d1); d0 = null; sel.setAttribute("display", "none");
    if (b - a > 8 && !host._inZ) { st.gxw = [Math.max(1, w[0] + (a - m.l) / (W - m.l - m.r) * (w[1] - w[0])), Math.min(REF.total, w[0] + (b - m.l) / (W - m.l - m.r) * (w[1] - w[0]))]; drawVariants(); } });
  svg.addEventListener("click", e => { const c = e.target.closest && e.target.closest("circle[data-j]"); if (c) pickVar(act[+c.dataset.j]); });
  svg.addEventListener("dblclick", () => { if (!host._inZ) { st.gxw = null; drawVariants(); } });
  svg.addEventListener("mouseleave", hideTip);
  host.replaceChildren(svg);
  const lg = document.createElement("div"); lg.className = "legend";
  const far = vs.filter(v => Math.abs(v.df) > lim).length;
  lg.innerHTML = `<span><i class="dot" style="background:var(--up)"></i>up (Δf &gt; 0)</span><span><i class="dot" style="background:var(--down)"></i>down (Δf &lt; 0)</span><span><i class="dot ring"></i>SRASel label${hi("tag")}</span><span><i class="dot" style="background:var(--neutral)"></i>does not pass</span><span class="muted">${loc(pvs.length)} tested variants in the window${far ? ` · ${far} with |Δf| &gt; ${lim} at the edge (dashed outline)` : ""} · drag to zoom, double click to reset</span>`;
  host.appendChild(lg);
}

/* frequency over time: points = observations (size = coverage), solid = joins them, dashed = SRASel fit */
function dynChart(host, vs, o = {}) {
  const W = host.clientWidth || 640, hMain = (o.h || 320) * HSCALE, hCov = o.cov ? 64 : 0, m = {l: 54, r: 18, t: 14, b: 40 + hCov};
  const H = hMain + hCov, svg = el("svg", {viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Frequency trajectories over the follow-up"});
  const xmax = Math.max(1, ...vs.flatMap(v => v.days)), fmax = vs.reduce((a, v) => v.k.reduce((b, k, i) => v.n[i] ? Math.max(b, k / v.n[i]) : b, a), 0);
  const yTop = o.log ? 1 : (o.zoom ? Math.min(1, Math.max(0.05, Math.ceil(fmax * 1.15 * 20) / 20)) : 1), yLo = o.log ? 0.002 : 0;
  const x = scale(0, xmax, m.l, W - m.r), y0 = hMain - 40;
  const y = o.log ? (f => y0 - (Math.log10(Math.max(f, yLo)) - Math.log10(yLo)) / (Math.log10(yTop) - Math.log10(yLo)) * (y0 - m.t)) : scale(yLo, yTop, y0, m.t);
  const ticks = o.log ? [0.002, 0.01, 0.1, 1] : [0, .25, .5, .75, 1].map(t => t * yTop);
  ticks.forEach(t => { el("line", {x1: m.l, x2: W - m.r, y1: y(t), y2: y(t), stroke: "var(--grid)"}, svg);
    el("text", {x: m.l - 6, y: y(t) + 4, "text-anchor": "end"}, svg).textContent = (t * 100 < 1 && t > 0 ? fmt(t * 100, 1) : Math.round(t * 100)) + " %"; });
  niceTicks(xmax, Math.max(3, Math.min(7, Math.round((W - m.l - m.r) / 80)))).forEach(t => { el("line", {x1: x(t), x2: x(t), y1: m.t, y2: y0, stroke: "var(--grid)"}, svg);
    el("text", {x: x(t), y: y0 + 15, "text-anchor": "middle"}, svg).textContent = t; });
  el("text", {x: (m.l + W - m.r) / 2, y: y0 + 31, "text-anchor": "middle"}, svg).textContent = "time since the first sample of the series (days)";
  el("text", {transform: `translate(12 ${(m.t + y0) / 2}) rotate(-90)`, "text-anchor": "middle"}, svg).textContent = "allele frequency k / n (%)" + (o.log ? ", log scale" : "");
  const clip = "c" + Math.random().toString(36).slice(2, 7);
  el("clipPath", {id: clip}, el("defs", {}, svg)).appendChild(el("rect", {x: m.l, y: m.t, width: W - m.l - m.r, height: y0 - m.t}));
  const many = vs.length > 1;
  vs.forEach((v, vi) => {
    const col = many ? OKI[vi % OKI.length] : dirCol(v), p = DATA.patients[v._i];
    const pts = v.days.map((d, i) => ({d, f: v.n[i] ? v.k[i] / v.n[i] : null, k: v.k[i], n: v.n[i]})).filter(q => q.f != null).sort((a, b) => a.d - b.d);
    const sel = !many || v === st.selV;
    if (pts.length > 1) {                                          // WLS fit line: slope β of the program, intercept with the same weights (n)
      const sw = pts.reduce((s, q) => s + q.n, 0), mx = pts.reduce((s, q) => s + q.n * q.d, 0) / sw, my = pts.reduce((s, q) => s + q.n * q.f, 0) / sw, a = my - v.beta * mx;
      if (sel && v.beta != null) { if (!o.log) el("line", {x1: x(0), y1: y(a), x2: x(xmax), y2: y(a + v.beta * xmax), stroke: col, "stroke-dasharray": "6 5", "stroke-width": 1.6, opacity: .7, "clip-path": `url(#${clip})`}, svg);
        else { const pl = []; for (let k = 0; k <= 60; k++) { const t = xmax * k / 60, f = a + v.beta * t; if (f > yLo) pl.push(`${x(t)},${y(f)}`); } if (pl.length > 1) el("polyline", {points: pl.join(" "), fill: "none", stroke: col, "stroke-dasharray": "6 5", "stroke-width": 1.6, opacity: .7}, svg); } }
    }
    el("polyline", {points: pts.map(q => `${x(q.d)},${y(q.f)}`).join(" "), fill: "none", stroke: col, "stroke-width": sel ? 2 : 1.2, opacity: sel ? .95 : .55}, svg);
    const dm = Math.max(1, ...pts.map(q => q.n));
    pts.forEach(q => {
      const c = mk(svg, many ? SHP[vi % SHP.length] : "circle", x(q.d), y(q.f), 3.5 + 4 * Math.sqrt(q.n / dm), {fill: q.f === 0 ? "var(--surface)" : col, stroke: q.f === 0 ? col : "var(--surface)", "stroke-width": q.f === 0 ? 1.6 : 1.5, opacity: sel ? 1 : .7});
      c.addEventListener("mousemove", ev => showTip(ev, `<b>${esc(labelS(v))}</b>day ${q.d}${sampleOf(p, q.d) ? " · " + esc(sampleOf(p, q.d)) : ""}<br>frequency ${fmt(q.f * 100, 2)} % (${loc(q.k)} of ${loc(q.n)} reads; k / n = ${+q.f.toPrecision(6)})`));
      c.addEventListener("mouseleave", hideTip);
    });
  });
  if (o.cov) {                                                      // coverage (depth at that position) of the main variant, on the same time axis
    const v = vs[0], cy0 = H - 8, ch = hCov - 22, nm = Math.max(1, ...v.n), cy = scale(0, nm, cy0, cy0 - ch);
    el("text", {x: m.l - 6, y: cy0 - ch + 4, "text-anchor": "end"}, svg).textContent = loc(nm);
    el("text", {x: m.l - 6, y: cy0, "text-anchor": "end"}, svg).textContent = "0";
    el("text", {x: m.l + 2, y: cy0 - ch - 3, style: "fill:var(--muted)"}, svg).textContent = "coverage at this position, n (reads; red = below 100)";
    v.days.forEach((d, i) => { const r = el("rect", {x: x(d) - 3, y: cy(v.n[i]), width: 6, height: Math.max(0, cy0 - cy(v.n[i])), fill: v.n[i] < 100 ? "var(--no)" : "var(--neutral)"}, svg);
      r.addEventListener("mousemove", ev => showTip(ev, `day ${d}<br>${loc(v.n[i])} reads${v.n[i] < 100 ? "<br><b>below 100</b>" : ""}`)); r.addEventListener("mouseleave", hideTip); });
  }
  host.replaceChildren(svg);
}

/* ───────── definitions (help icons) ─────────
   Plain definitions of what the numbers are, true to the program (README, "What it does", step 5). Each icon is a focusable button that points to its
   definition with aria-describedby; the text appears on hover, focus or click and Esc closes it. */
const HELP = {
  p: ["p", `Permutation p of the fitted slope β. The sampling days of the allele's counts are shuffled ${D0.nperm} times in this run; p = (c + 1) / (${D0.nperm} + 1), where c is the number of shuffles whose |β| is at least the observed |β|. The smallest possible p is 1/${D0.nperm + 1}. The bar keeps the variants with p at or below the value you set.`],
  df: ["Δf", `Δf (estimated) = β × follow-up: the change of allele frequency along the weighted linear fit over the follow-up. Follow-up here is the largest day minus the smallest day among the dates on which the position of this allele has coverage (the days used for its fit), which can be shorter than the whole series. It is a fitted value, so it can fall outside [−1, 1]. The program only tests alleles with |Δf| ≥ ${D0.df}. The bar keeps the variants with |Δf| at or above the value you set.`],
  dfo: ["observed Δf", `Observed Δf = frequency (k / n) on the last date with reads minus frequency on the first date with reads. It is computed by this page from the counts; it is not a column of the program's tables.`],
  beta: ["β", `β = slope of the linear fit of allele frequency (k / n) on day, weighted by the depth n of each date. It is a change of frequency per day; this report shows it in ‰ per day (thousandths of frequency per day).`],
  depth: ["depth", `Mean depth: the mean of n (reads covering the position) over the dates of the series.`],
  score: ["score", `Score = |β| × (−log10 p): the program's score without its sign. This report only uses it to order lists.`],
  tag: ["the SRASel label", `SRASel's own label, fixed when the program ran: "pos" (shown here as up) when p < ${D0.p} and β > 0; "neg" (shown as down) when p < ${D0.p} and β < 0; none otherwise. Only alleles with |Δf| ≥ ${D0.df} are tested. The thresholds of the bar do not change it.`],
  pass: ["passes", `Whether the variant satisfies both thresholds of the selection bar right now (p at or below the value set, |Δf| at or above the value set). It does not depend on SRASel's label.`],
};
const hi = k => `<button class="hi" type="button" data-h="${k}" aria-label="What is ${HELP[k][0]}?" aria-describedby="h-${k}"></button>`;

/* ───────── tables ───────── */
const COLS = {
  _s:   ["Series", v => esc(pname(DATA.patients[v._i])), v => v._i, "", "Series"],
  aa:   ["Effect", v => esc(v.aa || ""), v => v.aa || "", "", "Amino acid change (reference residue, position, new residue)"],
  gene: ["Gene / protein", v => esc(v.gene || "non-coding") + (v.mp ? " · " + esc(v.mp[0][0]) : ""), v => v.gene || "", "", "Gene and, when the reference provides it, the mature protein"],
  pos:  ["Position", v => esc(where(v)), v => v.pos, "", "Position in the reference"],
  var:  ["Allele", v => esc(v.var.length > 8 ? v.var.slice(0, 8) + "…" : v.var), v => v.var, "", "Allele whose frequency is followed"],
  df:   ["Est. Δf", v => fmt(v.df, 3), v => v.df, "num", "", "df"],
  dfo:  ["Obs. Δf", v => fmt(v.dfo, 3), v => v.dfo, "num", "", "dfo"],
  p:    ["p", v => fp(v.p), v => v.p, "num", "", "p"],
  tag:  ["SRASel", v => tagTxt(v), v => v.tag || "", "", "", "tag"],
  cust: ["Passes", v => pass(v) ? "yes" : '<span class="muted">no</span>', v => pass(v) ? 1 : 0, "", "", "pass"],
  depth:["Depth", v => v.depth == null ? "–" : Math.round(v.depth), v => v.depth, "num", "", "depth"],
  ai:   ["aa", v => v.ai || "–", v => v.ai || 0, "num", "Amino acid position in the gene"],
  mpn:  ["Mature protein", v => v.mp ? v.mp.map(m => esc(m[0]) + " (aa " + m[3] + ")").join(" / ") : "–", v => v.mp ? v.mp[0][0] : "", "", "Mature protein and amino acid within it"],
  of:   ["Other reading frames", v => esc(v.of || ""), v => v.of || "", "", "Effect on overlapping genes"],
};
/* text the search box looks in: series, gene, protein, amino acid, positions, contig, allele, position:allele, label, SRASel label */
const SRCH = v => [pname(DATA.patients[v._i]), v.gene || "non-coding", v.aa, v.pos, v.cp, v.c, v.var, key(v), label(v), v.mp ? v.mp.map(m => m[0]).join(" ") : "", tagWord(v)].join(" ").toLowerCase();
/* TSV export: the values as stored in DATA (already rounded by the report: β 8 decimals, p 6, Δf 5, depth 1); only the observed Δf is computed here, from the counts */
const TSVC = [
  ["series", v => pname(DATA.patients[v._i])], ["gene", v => v.gene], ["mature_protein", v => v.mp ? v.mp.map(m => m[0]).join(" / ") : ""], ["aa_change", v => v.aa], ["aa_position", v => v.ai],
  ["pos_global", v => v.pos], ["contig", v => v.c], ["contig_pos", v => v.cp], ["allele", v => v.var], ["beta_per_day", v => v.beta], ["est_delta_f", v => v.df],
  ["obs_delta_f", v => v.dfo], ["p", v => v.p], ["srasel_label", v => v.tag], ["passes_bar_thresholds", v => pass(v) ? "yes" : "no"], ["mean_depth", v => v.depth],
  ["n_dates", v => v.days.length], ["other_frames", v => v.of]];
const tsvCell = x => x == null ? "" : String(x).replace(/[\t\r\n]+/g, " ");
const vtsv = rows => [TSVC.map(c => c[0]).join("\t"), ...rows.map(v => TSVC.map(c => tsvCell(c[1](v))).join("\t"))].join("\n") + "\n";
const slug = s => String(s).replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 40) || "all";
/* variant table: sortable (o.sort), searchable + paged + downloadable when o.id is given; a click or Enter on a row opens that variant.
   Without o.id it is a fixed list capped at o.cap rows. */
function vtable(host, vs, o) {
  const cols = o.cols;
  let rows = vs.slice();
  if (o.sort) {
    const k = COLS[st.sortKey] ? st.sortKey : "p", g = COLS[k][2], d = st.sortDir;
    rows.sort((a, b) => { const x = g(a), y = g(b); if (x == null && y == null) return 0; if (x == null) return 1; if (y == null) return -1; return (x < y ? -1 : x > y ? 1 : 0) * d || Math.abs(b.df || 0) - Math.abs(a.df || 0); });
  }
  const T = o.id ? (st.tbl[o.id] = st.tbl[o.id] || {q: "", page: 0, ps: o.ps || 100, sig: ""}) : null, q = T ? T.q.trim().toLowerCase() : "", n0 = rows.length;
  if (q) rows = rows.filter(v => SRCH(v).includes(q));
  const total = rows.length, ps = T ? T.ps : (o.cap || 500);
  if (T) { const sig = n0 + "|" + q + "|" + st.sortKey + st.sortDir; if (T.sig !== sig) { T.sig = sig; T.page = 0; } T.page = Math.min(T.page, Math.max(0, Math.ceil(total / ps) - 1)); }
  const from = T ? T.page * ps : 0, view = rows.slice(from, from + ps);
  host._vt = {vs, o, rows};
  let tv = host;
  if (T) {
    if (!host.querySelector(":scope > .tbar")) {
      host.innerHTML = `<div class="tbar"><input type="search" class="tq" placeholder="Search gene, position, amino acid, allele…" aria-label="Filter the rows of this table"><span class="tinfo" aria-live="polite"></span><span class="grow"></span>
        <label>Rows per page <select class="tps" aria-label="Rows per page">${[50, 100, 250, 500, 1000].map(n => `<option value="${n}">${n}</option>`).join("")}</select></label>
        <span class="pg"><button class="btn tprev" type="button">‹ Previous</button><span class="tpg"></span><button class="btn tnext" type="button">Next ›</button></span>
        <button class="btn ttsv" type="button" title="All rows of this table as filtered, with the values as stored in the report (the report rounds β to 8 decimals, p to 6, Δf to 5 and depth to 1; the engine's full-precision values are in processing/06_selection_analysis/*_variant_stats.tsv)">Download table (TSV)</button></div><div class="tview"></div>`;
      const redo = () => vtable(host, host._vt.vs, host._vt.o);
      host.querySelector(".tq").oninput = ev => { T.q = ev.target.value; redo(); };
      host.querySelector(".tps").onchange = ev => { T.ps = +ev.target.value; T.page = 0; redo(); };
      host.querySelector(".tprev").onclick = () => { T.page = Math.max(0, T.page - 1); redo(); };
      host.querySelector(".tnext").onclick = () => { T.page += 1; redo(); };
      host.querySelector(".ttsv").onclick = () => saveBlob(new Blob([vtsv(host._vt.rows)], {type: "text/tab-separated-values;charset=utf-8"}), `srasel_${host._vt.o.fname || "variants"}_${slug(scopeTitle())}_${new Date().toISOString().slice(0, 10)}.tsv`);
    }
    host.querySelector(".tq").value = T.q; host.querySelector(".tps").value = String(T.ps);
    const pages = Math.max(1, Math.ceil(total / ps));
    host.querySelector(".tinfo").textContent = total ? `${loc(from + 1)}–${loc(from + view.length)} of ${loc(total)} row${total === 1 ? "" : "s"}${q ? ` matching “${T.q.trim()}” (of ${loc(n0)})` : ""}` : (q ? `no row matches “${T.q.trim()}” (of ${loc(n0)})` : "no rows");
    host.querySelector(".tpg").textContent = `page ${T.page + 1} of ${pages}`;
    host.querySelector(".tprev").disabled = T.page <= 0; host.querySelector(".tnext").disabled = T.page >= pages - 1; host.querySelector(".ttsv").disabled = !total;
    tv = host.querySelector(":scope > .tview");
  }
  tv.innerHTML = `<div class="tw ${o.free ? "free" : ""}"><table><thead><tr>${cols.map(c => { const cd = COLS[c], on = o.sort && st.sortKey === c, h = cd[5] ? hi(cd[5]) : "";
      return `<th scope="col" class="${cd[3]}" ${cd[4] ? `title="${esc(cd[4])}"` : ""} ${o.sort ? `aria-sort="${on ? (st.sortDir > 0 ? "ascending" : "descending") : "none"}"` : ""}>${o.sort ? `<button class="thb" data-s="${c}" type="button">${cd[0]}${on ? (st.sortDir > 0 ? " ▲" : " ▼") : ""}</button>` : cd[0]}${h}</th>`; }).join("")}</tr></thead>
    <tbody>${view.map((v, j) => `<tr data-j="${j}" tabindex="0" class="${v === st.selV ? "sel" : ""}">${cols.map(c => `<td class="${COLS[c][3]}">${COLS[c][1](v)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>` +
    (!T && total > ps ? `<p class="cap">Showing the first ${ps} of ${loc(total)} rows.</p>` : "");
  tv.querySelectorAll("tbody tr").forEach(r => { const v = view[+r.dataset.j]; r.onclick = () => (o.pick || pickVar)(v); r.onkeydown = e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); (o.pick || pickVar)(v); } }; });
  if (o.sort) tv.querySelectorAll("th .thb").forEach(b => b.onclick = () => { const s = b.dataset.s; st.sortDir = st.sortKey === s ? -st.sortDir : (s === "p" || s === "pos" || s === "aa" || s === "gene" || s === "var" || s === "_s" ? 1 : -1); st.sortKey = s; o.redo(); });
  return total;
}

/* ───────── variant drawer ───────── */
const vd = $("#vd");
function pickVar(v) {
  st.selV = v; syncHash();
  const first = !document.body.classList.contains("vdo");
  document.body.classList.add("vdo"); vd.classList.add("open");
  openVar(v);
  if (first) render(); else if (st.onSel) st.onSel();
}
function closeVar() {
  if (!vd.classList.contains("open")) return;
  vd.classList.remove("open"); st.selV = null; document.body.classList.remove("vdo"); syncHash(); render();
}
function openVar(v) {
  const p = DATA.patients[v._i], R = refOf(p), same = p.variants.filter(x => x !== v && x.pos === v.pos && (x.c || "") === (v.c || ""));
  const rows = v.days.map((d, i) => ({d, k: v.k[i], n: v.n[i]})).sort((a, b) => a.d - b.d);
  vd.innerHTML = `<div class="vh"><b>${esc(label(v))}</b><button class="btn" id="vdx" type="button" aria-label="Close details">Close</button></div>
    <dl class="kv">
      <dt>Series</dt><dd>${esc(pname(p))}${DATA.groups.length > 1 ? ` <span class="muted">· ${esc(gname(p))}</span>` : ""}</dd>
      <dt>Position</dt><dd>${esc(where(v))}${R.contigs.length > 1 ? ` · global ${v.pos}` : ""}</dd>
      <dt>Gene / protein</dt><dd>${esc(v.gene || "non-coding")}${v.mp ? "<br>" + mpCell(v) : ""}</dd>
      <dt>Allele and effect</dt><dd>${esc(v.var)} · ${esc(v.aa || "–")}${v.of ? `<br><span class="small muted">other reading frames: ${esc(v.of)}</span>` : ""}</dd>
      <dt>Slope β${hi("beta")}</dt><dd>${ex(v.beta)} per day <span class="small muted">(${fmt(v.beta * 1000, 3)} ‰/day)</span></dd>
      <dt>Estimated Δf${hi("df")}</dt><dd>${ex(v.df)} <span class="small muted">β × follow-up (fit)</span></dd>
      <dt>Observed Δf${hi("dfo")}</dt><dd>${exd(v.dfo)} <span class="small muted">last − first date</span></dd>
      <dt>p${hi("p")}</dt><dd>${pex(v.p)}</dd>
      <dt>SRASel label${hi("tag")}</dt><dd>${tagWord(v)}</dd>
      <dt>Bar thresholds${hi("pass")}</dt><dd>${pass(v) ? "passes" : "does not pass"} <span class="small muted">(p ≤ ${fa(st.alpha)}, |Δf| ≥ ${st.delta})</span></dd>
      <dt>Mean depth${hi("depth")}</dt><dd>${v.depth == null ? "–" : ex(v.depth)} reads</dd>
    </dl>
    <div id="vdtr"></div><p class="cap">Frequency k / n of this allele on each date (points sized by reads n; dashed line = SRASel's weighted fit); the bars show n.</p>
    <details open><summary>Counts by date (${rows.length})</summary><div class="tw free"><table><thead><tr><th>Day</th><th>Sample</th><th class="num">Variant</th><th class="num">Coverage</th><th class="num">Frequency</th></tr></thead><tbody>
      ${rows.map(r => `<tr><td>${r.d}</td><td>${esc(sampleOf(p, r.d))}</td><td class="num">${loc(r.k)}</td><td class="num">${loc(r.n)}</td><td class="num">${r.n ? fmt(100 * r.k / r.n, 1) + " %" : "–"}</td></tr>`).join("")}</tbody></table></div></details>
    ${same.length ? `<details open><summary>Other variants at this position (${same.length})</summary>${same.map((x, j) => `<div class="alt" data-j="${j}" tabindex="0"><b>${esc(x.var)}</b> ${esc(x.aa || "")} · Δf ${ex(x.df)} · p ${pex(x.p)} · SRASel ${tagWord(x)}</div>`).join("")}</details>` : ""}
    <p><button class="btn" id="vdgo" type="button">Open in Trajectories</button></p>`;
  $("#vdx").onclick = closeVar;
  $("#vdgo").onclick = () => { st.pins = [v]; st.tab = "traj"; st.tview = "lines"; st.dynS = v._i; syncHash(); render(); };
  vd.querySelectorAll(".alt").forEach(a => { a.onclick = () => pickVar(same[+a.dataset.j]); a.onkeydown = e => { if (e.key === "Enter") pickVar(same[+a.dataset.j]); }; });
  dynChart($("#vdtr"), [v], {h: 230, cov: true});
}

/* ───────── selection bar ───────── */
const BARV = {summary: {gene: 1, dir: 1}, variants: {gene: 1, dir: 1}, traj: {gene: 1, dir: 1}, genes: {}, sim: {}, about: {}};
let geneSig = null;
function setGene(g) { st.gene = g; syncHash(); render(); }
/* thresholds: ONE state (st.alpha, st.delta); every input that shows them (bar number, bar slider, the copy over the Variants figure) is a view of it */
const sliderP = u => { const a = Math.pow(10, u); return a >= 0.995 ? 1 : +a.toPrecision(2); };
const sliderU = a => Math.log10(Math.max(a, 1e-9));
function syncThrInputs(from) {
  document.querySelectorAll("[data-thr=p]").forEach(i => { if (i.id !== from) i.value = i.type === "range" ? sliderU(st.alpha) : fa(st.alpha); });
  document.querySelectorAll("[data-thr=d]").forEach(i => { if (i.id !== from) i.value = st.delta; });
  document.querySelectorAll("[data-thr=pv]").forEach(o => o.textContent = fa(st.alpha));
}
let thrRaf = 0;
function setThr(a, d, from) {
  st.alpha = a; st.delta = d; syncThrInputs(from); syncHash();
  cancelAnimationFrame(thrRaf);
  thrRaf = requestAnimationFrame(() => { barUpdate(); hideTip(); if (st.onThr) st.onThr(); else render(); });
}
function buildBar() {
  if (DATA.patients.length > 1) {
    const many = DATA.groups.length > 1; let h = "";
    if (!many) h += `<option value="all">All series</option>`;
    DATA.groups.forEach((g, gi) => { const ids = DATA.patients.map((p, i) => i).filter(i => DATA.patients[i].g === gi); if (!ids.length) return;
      const opts = ids.map(i => `<option value="${i}">${esc(pname(DATA.patients[i]))}</option>`).join("");
      h += many ? `<optgroup label="${esc(g.name)}"><option value="g${gi}">All · ${esc(g.name)} (${ids.length})</option>${opts}</optgroup>` : opts; });
    $("#bSer").innerHTML = h; $("#bSer").value = String(st.cur); $("#lSer").hidden = false;
  }
  const rp = $("#bPr"); rp.min = Math.floor(Math.log10(PMIN / 1.1) * 100) / 100;
  let to; const later = f => e => { clearTimeout(to); to = setTimeout(() => f(e), 260); };
  $("#bP").oninput = later(e => { const v = parseFloat(e.target.value); if (v > 0 && v <= 1) setThr(v, st.delta, "bP"); });
  $("#bD").oninput = later(e => { const v = parseFloat(e.target.value); if (v >= 0 && v <= 1) setThr(st.alpha, v, "bD"); });
  rp.oninput = e => setThr(sliderP(+e.target.value), st.delta, "bPr");
  $("#bReset").onclick = () => setThr(D0.p, D0.df);
  syncThrInputs();
  $("#bGene").onchange = e => { st.gene = e.target.value; syncHash(); render(); };
  $("#bDir").onchange = e => { st.dir = e.target.value; syncHash(); render(); };
  $("#bSer").onchange = e => { const v = e.target.value; st.cur = (v === "all" || /^g\d+$/.test(v)) ? v : +v; st.selV = null; st.pins = []; st.dynS = null; st.hsel = null; st.gxw = null; syncHash(); closeVar(); render(); };
}
function barUpdate() {
  const f = BARV[st.tab], hasBar = f && (st.tab !== "about" || DATA.compare.length);
  $("#bar").hidden = !hasBar; if (!hasBar) return;
  $("#lGene").hidden = !f.gene; $("#lDir").hidden = !f.dir;
  const genes = [...new Set(scopeVars().map(v => v.gene || "non-coding"))].sort(), sig = genes.join("|");
  if (st.gene && !genes.includes(st.gene)) st.gene = "";
  if (sig !== geneSig) { geneSig = sig; $("#bGene").innerHTML = `<option value="">all</option>` + genes.map(g => `<option value="${esc(g)}">${esc(g)}</option>`).join(""); }
  $("#bGene").value = st.gene; $("#bDir").value = st.dir;
  // count line: always over all tested variants of the scope (gene / direction applied on the tabs that use them)
  const L = baseSeries(), all = L.flatMap(({p}) => p.variants), useF = !!(f.gene || f.dir), inF = v => !useF || (geneOK(v) && dirOK(v));
  const sel = all.filter(v => pass(v) && inF(v)), up = sel.filter(v => v.df > 0).length, dn = sel.filter(v => v.df < 0).length;
  const lab = sel.filter(v => v.tag).length, labAll = all.filter(v => v.tag && inF(v)).length;
  let t = `<b>${loc(sel.length)}</b> variant${sel.length === 1 ? "" : "s"} pass <span class="m">(p ≤ ${fa(st.alpha)}, |Δf| ≥ ${st.delta})</span> · up ${loc(up)} · down ${loc(dn)} · ${loc(lab)} carry SRASel's label` +
    (labAll !== lab ? ` <span class="m">(${loc(labAll)} labelled in all)</span>` : "") + (L.length > 1 ? ` <span class="m">· sum of ${L.length} series</span>` : "");
  $("#bReset").hidden = isDefault();
  $("#bCount").innerHTML = t;
}

/* ───────── tabs ───────── */
const TABS = [["summary", "Summary"], ["variants", "Variants"], ["traj", "Trajectories"], ["genes", "Genes"], ["quality", "Quality"]];
const hasVal = DATA.patients.some(p => p.checks || p.cards), hasSim = DATA.patients.some(p => p.truth);
if (hasSim) TABS.push(["sim", "Simulation"]);
if (hasVal) TABS.push(["val", "Validation"]);
TABS.push(["about", "About"]);
const TALIAS = {ov: "summary", res: "summary", land: "variants", sel: "variants", gen: "variants", tab: "variants", dyn: "traj", mat: "traj", gene: "genes", pac: "quality", div: "quality", cmd: "about", ref: "about"};
function setTab(t) { st.tab = t; if (t === "quality" || t === "about" || t === "val") closeVarSilent(); syncHash(); render(); }
function closeVarSilent() { if (vd.classList.contains("open")) { vd.classList.remove("open"); document.body.classList.remove("vdo"); } }
function buildNav() {
  $("#nav").innerHTML = TABS.map(t => `<button role="tab" id="tab-${t[0]}" data-t="${t[0]}" aria-controls="main" type="button">${t[1]}</button>`).join("");
  document.querySelectorAll("#nav button").forEach(b => { b.onclick = () => setTab(b.dataset.t);
    b.onkeydown = e => { const i = TABS.findIndex(t => t[0] === b.dataset.t), j = e.key === "ArrowRight" ? i + 1 : e.key === "ArrowLeft" ? i - 1 : null; if (j == null) return; e.preventDefault(); setTab(TABS[(j + TABS.length) % TABS.length][0]); $("#tab-" + st.tab).focus(); }; });
}
function drawNav() {
  document.querySelectorAll("#nav button").forEach(b => { const on = b.dataset.t === st.tab; b.setAttribute("aria-selected", on); b.tabIndex = on ? 0 : -1; });
  main.setAttribute("aria-labelledby", "tab-" + st.tab);
  if (st._nt !== st.tab) { st._nt = st.tab; notify("tab"); }
}
/* ── address and host contract (see the comment at the top of <body>) ── */
const HP = {embed: false, theme: ""};                                   // keys kept in the address although they are not part of the state
function syncHash() {
  const h = `tab=${st.tab}&p=${st.cur}` + (isDefault() ? "" : `&a=${st.alpha}&d=${st.delta}`) + (st.gene ? `&g=${encodeURIComponent(st.gene)}` : "") + (st.dir !== "both" ? `&dir=${st.dir}` : "") +
    (st.selV ? `&v=${st.selV._i}.${encodeURIComponent(key(st.selV))}` : "") + (HP.embed ? "&embed=1" : "") + (HP.theme ? `&theme=${HP.theme}` : "");
  try { history.replaceState(null, "", "#" + h); } catch (e) { try { location.hash = h; } catch (e2) {} }
}
function parseHash() {
  const h = {}; (location.hash || "").slice(1).split("&").filter(Boolean).forEach(x => { const i = x.indexOf("="); if (i > 0) { try { h[x.slice(0, i)] = decodeURIComponent(x.slice(i + 1)); } catch (e) {} } });
  return h;
}
const tabOf = h => { const t = h.tab || h.t, k = TALIAS[t] || t; return TABS.some(x => x[0] === k) ? k : null; };   // unknown ids are ignored
function setEmbed(on) { HP.embed = !!on; document.documentElement.classList.toggle("embed", HP.embed); }
function setTheme(t) { HP.theme = t; document.documentElement.dataset.theme = t; }
function notify(event) { if (parent === window) return; try { parent.postMessage({type: "srasel-report", event, tab: st.tab, tabs: TABS, embed: HP.embed}, "*"); } catch (e) {} }
function applyHost(m) {                                                 // the same keys from a hash (strings) or from a message (typed)
  if (m.theme === "light" || m.theme === "dark") setTheme(m.theme);
  if (m.embed != null) setEmbed(m.embed === true || m.embed === "1" || m.embed === "true");
  const t = tabOf(m); if (t && t !== st.tab) setTab(t);
}
addEventListener("hashchange", () => {
  const h = parseHash(); let ch = false;
  if (h.a > 0 && h.a <= 1 && +h.a !== st.alpha) { st.alpha = +h.a; ch = true; } if (h.d >= 0 && h.d <= 1 && h.d !== "" && +h.d !== st.delta) { st.delta = +h.d; ch = true; }
  if (h.g != null && h.g !== st.gene) { st.gene = h.g; ch = true; } if (["up", "down", "both"].includes(h.dir) && h.dir !== st.dir) { st.dir = h.dir; ch = true; }
  if (ch) { syncThrInputs(); render(); }
  applyHost(h);
});
addEventListener("message", ev => { const m = ev.data; if (parent === window || ev.source !== parent || !m || m.type !== "srasel-report") return; applyHost(m); });
const TABFN = {summary: () => tabSummary(), variants: () => tabVariants(), traj: () => tabTraj(), genes: () => tabGenes(), quality: () => tabQuality(), sim: () => tabSim(), val: () => tabVal(), about: () => tabAbout()};
function render() {
  closeZoom(); hideTip(); drawNav(); barUpdate(); st.onSel = null; st.onThr = null; TABFN[st.tab]();
  document.title = DATA.title;
}
const scopeTitle = () => multi() ? (st.cur === "all" ? "All series" : gname(SC()[0].p)) : pname(DATA.patients[st.cur]);

/* ───────── Summary ───────── */
function tabSummary() {
  const L = baseSeries(), all = L.flatMap(({p}) => p.variants), t = tally(all), ns = L.reduce((a, {p}) => a + p.samples.length, 0);
  const span = maxOf(L.flatMap(({p}) => p.samples.map(s => s.day)), 0), T = thr(), fl = (st.gene ? ` Gene: ${esc(st.gene)}.` : "") + (st.dir !== "both" ? ` Direction: ${st.dir} only.` : "");
  let lead;
  if (!t.nv) lead = "No variant has a statistic in this scope (the series may have fewer than 3 dates, or no variant passed the depth and frequency filters).";
  else lead = `<b>${loc(t.ns)}</b> of <b>${loc(t.nv)}</b> tested variants pass p ≤ ${fa(T.a)} and |Δf| ≥ ${T.d} (${loc(t.nsp)} position${t.nsp === 1 ? "" : "s"}; ${t.up} up, ${t.dn} down). ${loc(t.lab)} carry SRASel's own label (p &lt; ${D0.p}, |Δf| ≥ ${D0.df}, fixed when the program ran).${fl}`;
  main.innerHTML = `<section class="panel"><h2>${esc(scopeTitle())}</h2><p class="lead">${lead}</p>
    <div class="kpis"><div class="kpi"><div class="l">Samples</div><div class="v">${loc(ns)}</div><div class="s">${L.length} series</div></div>
      <div class="kpi"><div class="l">Follow-up</div><div class="v">${loc(span)} days</div><div class="s">${L.length > 1 ? "longest series" : "first to last sample"}</div></div>
      <div class="kpi"><div class="l">Variants tested</div><div class="v">${loc(t.nv)}</div><div class="s">${loc(t.np)} positions</div></div>
      <div class="kpi"><div class="l">Passing the thresholds</div><div class="v">${loc(t.ns)}</div><div class="s">${loc(t.nsp)} positions · up ${t.up} · down ${t.dn}</div></div></div></section>
    <section class="panel"><h2>Follow-up</h2><div id="sFol"></div><p class="cap">Each marker is one sample, placed at its day since the first sample of its series (spacing proportional to time); darker = higher mean depth; a red square = mean depth below 100×.</p></section>
    ${t.nv ? `<section class="panel"><h2>Along the genome</h2><div id="sGen"></div><p class="cap" id="sGenCap"></p></section>
    <section class="panel"><h2>Strongest changes</h2><p class="cap" style="margin-top:0">One row per position (the allele with the most evidence), ranked by |observed Δf| × −log10 p. Click a row for its trajectory.</p><div id="sTop"></div></section>` : ""}`;
  [["#sFol", ovFollow], ["#sGen", ovGenome]].forEach(([id, f]) => { const h = $(id); if (!h) return; f(h); h._re = f; decorate(h); });
  if (t.nv) ovTop($("#sTop"));
  st.onSel = () => { if ($("#sTop")) ovTop($("#sTop")); };
}
function ovTop(host) {
  const best = new Map();
  scopeVars().filter(inSel).forEach(v => { const k = posKey(v), o = best.get(k); if (!o || rank2(v) > rank2(o) || (rank2(v) === rank2(o) && v.df > o.df)) best.set(k, v); });
  const vs = [...best.values()].sort((a, b) => rank2(b) - rank2(a)), top = vs.slice(0, 10);
  if (!top.length) { host.innerHTML = `<p class="muted">No variant passes the current thresholds.</p>`; return; }
  vtable(host, top, {cols: [...(multi() ? ["_s"] : []), "aa", "gene", "pos", "var", "df", "dfo", "p", "tag"], free: true});
  host.insertAdjacentHTML("beforeend", `<p class="cap">${vs.length > 10 ? `Top 10 of ${loc(vs.length)} positions. ` : ""}<button class="lnk" id="sAll" type="button">See all variants in the Variants tab</button></p>`);
  $("#sAll").onclick = () => setTab("variants");
}

/* ───────── Variants ───────── */
function tabVariants() {
  const geno = st.vview === "genome", REF = scopeRef(), sg = REF.genes.slice().sort((a, b) => a.gstart - b.gstart);
  main.innerHTML = `<section class="panel"><div class="vb"><div class="seg" role="group" aria-label="Figure type"><button type="button" data-v="volcano" aria-pressed="${!geno}">Δf vs evidence</button><button type="button" data-v="genome" aria-pressed="${geno}">Along the genome</button></div>
      <span class="opts" id="vCtl" ${geno ? "" : "hidden"}><button class="btn" id="gzi" type="button" aria-label="Zoom in">+ zoom</button><button class="btn" id="gzo" type="button" aria-label="Zoom out">− zoom</button><button class="btn" id="gzr" type="button">Whole genome</button>
        <label>Go to gene <select id="gzg"><option value="">…</option>${sg.map((x, j) => `<option value="${j}">${esc(x.name)}</option>`).join("")}</select></label><span class="muted" id="vWin"></span></span>
      <span class="pq" title="The same p threshold as in the selection bar">p ≤ <input id="vPr" data-thr="p" type="range" min="${$("#bPr").min}" max="0" step="0.01" aria-label="p threshold (same control as the selection bar)"><output data-thr="pv"></output><span class="muted">· |Δf| ≥ <output id="vDv"></output></span></span></div>
      <div id="vFig"></div><p class="cap" id="vFigCap"></p></section>
    <section class="panel"><div class="vb" style="justify-content:space-between"><h2 id="vH" style="margin:0">Variants</h2><div class="seg" role="group" aria-label="Rows of the table"><button type="button" data-r="pass" aria-pressed="${st.vrows === "pass"}">passing</button><button type="button" data-r="all" aria-pressed="${st.vrows === "all"}">all tested</button></div></div><div id="vTab"></div></section>`;
  syncThrInputs();
  $("#vPr").oninput = e => setThr(sliderP(+e.target.value), st.delta, "vPr");
  document.querySelectorAll(".seg [data-r]").forEach(b => b.onclick = () => { st.vrows = b.dataset.r; document.querySelectorAll(".seg [data-r]").forEach(x => x.setAttribute("aria-pressed", x === b)); drawVariants(); });
  document.querySelectorAll(".seg [data-v]").forEach(b => b.onclick = () => { st.vview = b.dataset.v; tabVariants(); });
  if (geno) {
    $("#gzg").onchange = e => { if (e.target.value === "") return; const gg = sg[+e.target.value], pad = Math.max(30, (gg.gend - gg.gstart) * .05); st.gxw = [Math.max(1, gg.gstart - pad), Math.min(REF.total, gg.gend + pad)]; drawVariants(); };
    $("#gzr").onclick = () => { st.gxw = null; drawVariants(); };
    const zoom = k => { const w = st.gxw || [1, REF.total], c = (w[0] + w[1]) / 2, h = (w[1] - w[0]) / 2 * k; st.gxw = h >= REF.total / 2 ? null : [Math.max(1, c - h), Math.min(REF.total, c + h)]; drawVariants(); };
    $("#gzi").onclick = () => zoom(.5); $("#gzo").onclick = () => zoom(2);
  }
  st.onSel = drawVariants; st.onThr = drawVariants; drawVariants();
}
function drawVariants() {
  if ($("#vDv")) $("#vDv").textContent = st.delta;
  const geno = st.vview === "genome", REF = scopeRef(), all = scopeVars().filter(v => v.df != null);
  const w = geno ? (st.gxw || [1, REF.total]) : null, host = $("#vFig");
  if (!all.length) { host.innerHTML = `<p class="muted">No variant has a statistic in this scope.</p>`; $("#vTab").innerHTML = ""; $("#vH").textContent = "Variants"; return; }
  $("#vFigCap").textContent = geno ? "Each point is one tested variant: position in the reference (x) against its estimated Δf = β × follow-up (y); colour and ring as in the legend. Click a point for its trajectory."
    : "Each point is one tested variant: estimated Δf = β × follow-up (x) against −log10 of its permutation p (y); dashed lines are the thresholds of the bar. Click a point for its trajectory.";
  if (geno) { genomeX(host, REF, all, w); host._re = h => genomeX(h, REF, all, w); decorate(host);
    $("#vWin").textContent = st.gxw ? `window ${locOf(REF, Math.round(w[0]))} – ${locOf(REF, Math.round(w[1]))} (${loc(Math.round(w[1] - w[0] + 1))} nt)` : "whole genome"; }
  else { const vs = all.filter(v => v.p != null); volcano(host, vs); host._re = h => volcano(h, vs); decorate(host); }
  const allRows = st.vrows === "all";
  let rows = all.filter(v => allRows ? geneOK(v) && dirOK(v) : inSel(v)); if (geno && st.gxw) rows = rows.filter(v => v.pos >= w[0] && v.pos <= w[1]);
  $("#vH").textContent = `${loc(rows.length)} ${allRows ? "tested " : ""}variant${rows.length === 1 ? "" : "s"}${allRows ? "" : ` passing p ≤ ${fa(st.alpha)}, |Δf| ≥ ${st.delta}`}${geno && st.gxw ? " in the window" : ""}`;
  const cols = [...(multi() ? ["_s"] : []), "aa", "gene", "pos", "var", "df", "dfo", "p", "tag", ...(allRows ? ["cust"] : []), "depth"];
  if (!rows.length) { $("#vTab").innerHTML = `<p class="muted">No variant passes the current thresholds.</p>`; return; }
  vtable($("#vTab"), rows, {cols, sort: true, redo: drawVariants, id: "v", fname: "variants"});
}

/* ───────── Trajectories ───────── */
function tabTraj() {
  const lines = st.tview === "lines";
  main.innerHTML = `<section class="panel"><div class="vb"><div class="seg" role="group" aria-label="Trajectory view"><button type="button" data-v="lines" aria-pressed="${lines}">Lines</button><button type="button" data-v="heat" aria-pressed="${!lines}">Heatmap</button></div>
</div>
    <div id="tBody"></div></section>`;
  document.querySelectorAll(".seg [data-v]").forEach(b => b.onclick = () => { st.tview = b.dataset.v; tabTraj(); });
  lines ? trajLines() : trajHeat();
}
function trajLines() {
  $("#tBody").innerHTML = `<div class="dyn"><aside class="dlist"><label class="small muted" for="dq">Search</label><input id="dq" type="search" placeholder="position or amino acid" aria-label="Search variants"><div id="dlist"></div></aside>
    <div><div class="opts"><label><input type="checkbox" id="dlog"> log scale</label><label><input type="checkbox" id="dzoom"> fit axis to the maximum frequency</label><button class="btn" id="dclear" type="button">Clear comparison</button></div>
      <div id="dleg" class="legend"></div><div id="dch"></div><p class="cap">Allele frequency k / n on each date, with the days placed proportionally to time: a marker per date (area grows with the reads n; dates without reads are not drawn), the solid line joins them, the dashed line is SRASel's weighted fit.</p><div id="dinfo" class="small"></div></div></div>`;
  ["dq", "dlog", "dzoom"].forEach(id => $("#" + id).addEventListener("input", drawLines));
  $("#dclear").onclick = () => { st.pins = []; drawLines(); };
  st.onSel = drawLines; st.onThr = drawLines; drawLines();
}
function drawLines() {
  const q = $("#dq").value.trim().toLowerCase(), lim = 150;
  let vs = scopeVars().filter(v => v.p != null && v.df != null && inSel(v) && (!q || String(v.pos).includes(q) || (v.aa || "").toLowerCase().includes(q) || String(v.cp).includes(q)));
  vs.sort((a, b) => score(b) - score(a));
  const isPin = v => st.pins.includes(v), rows = vs.slice(0, lim);
  $("#dlist").innerHTML = `<div class="small muted" style="margin:6px 0 4px">${loc(vs.length)} variant${vs.length === 1 ? "" : "s"}${vs.length > lim ? ` (top ${lim} by |β|·−log10 p; search to find others)` : ""}. Tick up to 8 to compare.</div>` +
    rows.map((v, j) => `<div class="drow ${v === st.selV ? "sel" : ""}" data-j="${j}"><input type="checkbox" ${isPin(v) ? "checked" : ""} aria-label="Compare ${esc(labelS(v))}"><span class="dl" tabindex="0">${esc(labelS(v))}</span><span class="dp ${v.df > 0 ? "up" : "dn"}">${v.df > 0 ? "▲" : "▼"} ${fmt(v.df, 3)} · p ${fp(v.p)}</span></div>`).join("");
  $("#dlist").querySelectorAll(".drow").forEach(r => { const v = rows[+r.dataset.j], dl = r.querySelector(".dl");
    const choose = () => { st.selV = v; if (!isPin(v) && st.pins.length < 2) st.pins = []; syncHash(); drawLines(); if (vd.classList.contains("open")) openVar(v); };
    dl.onclick = choose; dl.onkeydown = e => { if (e.key === "Enter") choose(); };
    r.querySelector("input").onchange = e => { if (e.target.checked) { if (st.pins.length >= 8) { e.target.checked = false; return; } st.pins.push(v); } else st.pins = st.pins.filter(x => x !== v); drawLines(); }; });
  const cur = (st.selV && vs.includes(st.selV)) ? st.selV : vs[0];
  let show = st.pins.filter(v => vs.includes(v) || true); if (cur && show.length && !show.includes(cur)) show.push(cur); if (!show.length && cur) show = [cur];
  show = show.slice(0, 8);
  if (!show.length) { $("#dch").innerHTML = `<p class="muted">No variant passes the current thresholds.</p>`; $("#dleg").innerHTML = ""; $("#dinfo").innerHTML = ""; return; }
  const host = $("#dch"), o = {h: 340, cov: show.length === 1, log: $("#dlog").checked, zoom: $("#dzoom").checked};
  dynChart(host, show, o); host._re = h => dynChart(h, show, o); decorate(host);
  $("#dleg").innerHTML = show.map((v, i) => `<span>${show.length > 1 ? swatch(SHP[i % SHP.length], OKI[i % OKI.length]) : `<i class="dot" style="background:${dirCol(v)}"></i>`}${esc(labelS(v))}</span>`).join("");
  const v0 = show.length === 1 ? show[0] : cur;
  $("#dinfo").innerHTML = v0 ? `<b>${esc(labelS(v0))}</b> · β ${fmt(v0.beta * 1000, 3)} ‰/day · est. Δf ${ex(v0.df)} · obs. Δf ${exd(v0.dfo)} · p ${pex(v0.p)} · SRASel label: ${tagWord(v0)} · <button class="lnk" id="dopen" type="button">details</button>${show.length > 1 ? ` <span class="muted">(fit line only for the highlighted variant)</span>` : ""}` : "";
  if ($("#dopen")) $("#dopen").onclick = () => pickVar(v0);
}
function trajHeat() {
  const L = baseSeries(), ids = L.map(x => x.i);
  if (st.dynS == null || !ids.includes(st.dynS)) st.dynS = ids[0];
  $("#tBody").innerHTML = `<div class="opts">${ids.length > 1 ? `<label>Series <select id="mser">${ids.map(i => `<option value="${i}" ${i === st.dynS ? "selected" : ""}>${esc(pname(DATA.patients[i]))}</option>`).join("")}</select></label>` : ""}
      <label>Sort by <select id="msort" aria-label="Sort by"><option value="score">score |β|·−log10 p</option><option value="pos">position</option><option value="beta">slope β</option><option value="dfo">observed Δf</option></select></label>${hi("score")}
      <label>Rows <select id="mrows"><option>30</option><option>60</option><option>120</option><option>200</option></select></label></div>
    <div id="mat"></div><div id="matl"></div>`;
  if ($("#mser")) $("#mser").onchange = e => { st.dynS = +e.target.value; drawHeatmap(); };
  $("#msort").value = st.msort; $("#mrows").value = st.mrows;
  $("#msort").onchange = e => { st.msort = e.target.value; drawHeatmap(); }; $("#mrows").onchange = e => { st.mrows = +e.target.value; drawHeatmap(); };
  st.onSel = drawHeatmap; st.onThr = drawHeatmap; drawHeatmap();
}
function drawHeatmap() {
  const p = DATA.patients[st.dynS], host = $("#mat");
  const days = [...new Set(p.samples.map(s => s.day))].sort((a, b) => a - b), ids = days.map(d => p.samples.filter(s => s.day === d).map(s => s.id).join("/"));
  let vs = p.variants.filter(v => v.p != null && v.df != null && inSel(v));
  const sorter = {score: (a, b) => score(b) - score(a), pos: (a, b) => a.pos - b.pos, beta: (a, b) => b.beta - a.beta, dfo: (a, b) => (b.dfo == null ? -9 : b.dfo) - (a.dfo == null ? -9 : a.dfo)}[st.msort];
  const total = vs.length; vs.sort(sorter); vs = vs.slice(0, st.mrows);
  if (!vs.length || !days.length) { host.innerHTML = `<p class="muted">No variant passes the current thresholds.</p>`; $("#matl").innerHTML = ""; return; }
  const draw = h => {
    const vals = vs.map(v => days.map(d => { const i = v.days.indexOf(d); return i >= 0 && v.n[i] ? v.k[i] / v.n[i] : null; }));
    const labs = vs.map(v => { const t = label(v); return t.length > 40 ? t.slice(0, 38) + "…" : t; }), mx = Math.max(...days, 1);
    heat(h, {rows: labs, cols: days.map(d => "d" + d), vals, norm: v => v, color: seqColor, labels: days.length <= 12, cellText: v => (v * 100).toFixed(v < .1 ? 1 : 0), ml: 262, mb: 66, mt: 8, maxch: 17, maxh: 17 * vs.length, aria: "Frequency heat map, variant by sample",
      tip: (r, c, v) => { const q = vs[r], i = q.days.indexOf(days[c]); return `<b>${esc(label(q))}</b>day ${days[c]} · ${esc(ids[c])}<br>${v == null ? "no data in this sample" : `frequency ${fmt(v * 100, 2)} % (${loc(q.k[i])} of ${loc(q.n[i])} reads)`}`; },
      colLabels: (svg, m, cw, hh) => {
        const W = +svg.getAttribute("viewBox").split(" ")[2], rul = m.t + hh + 52, xr = scale(0, mx, m.l + cw / 2, W - m.r - cw / 2);
        el("line", {x1: xr(0), x2: xr(mx), y1: rul, y2: rul, stroke: "var(--muted)"}, svg);
        days.forEach((d, c) => { const cx = m.l + c * cw + cw / 2;
          if (cw > 26 || c % 2 === 0) el("text", {x: cx, y: m.t + hh + 13, "text-anchor": "middle"}, svg).textContent = "d" + d;
          el("line", {x1: cx, y1: m.t + hh + 18, x2: xr(d), y2: rul - 3, stroke: "var(--line)"}, svg); el("circle", {cx: xr(d), cy: rul, r: 2.6, fill: "var(--text2)"}, svg); });
        el("text", {x: m.l, y: rul + 14, style: "fill:var(--muted)"}, svg).textContent = "real time: days since the first sample (columns are the samples, equally spaced)";
        const rh = hh / vs.length;
        vs.forEach((v, r) => { const y0 = m.t + r * rh;
          mk(svg, v.df > 0 ? "up" : "down", 9, y0 + rh / 2, 3.6, {fill: dirCol(v), stroke: v.tag ? "var(--text)" : "none", "stroke-width": 1.4});
          const hit = el("rect", {x: 0, y: y0, width: m.l - 2, height: rh, fill: "transparent", style: "cursor:pointer"}, svg);
          hit.addEventListener("click", () => { if (!h._inZ) pickVar(v); }); hit.addEventListener("mousemove", ev => showTip(ev, tipOf(v))); hit.addEventListener("mouseleave", hideTip);
          if (v === st.selV) el("rect", {x: 0, y: y0, width: W, height: rh, fill: "none", stroke: "var(--text)", "stroke-width": 1.4}, svg); });
      }});
  };
  draw(host); host._re = draw; decorate(host);
  cbar($("#matl"), "allele frequency k / n on that sample", [0, .25, .5, .75, 1].map(u => [u, Math.round(u * 100) + " %"]), seqColor);
  $("#matl").insertAdjacentHTML("beforeend", `<p class="cap">One row per variant, one column per sample: the cell colour is the allele frequency k / n; <i class="nd"></i> hatched = no data (not 0 %). ${vs.length} of ${loc(total)} variants shown. Left mark: <i class="tri u"></i> up / <i class="tri d"></i> down (Δf sign), dark ring = SRASel label.</p>`);
}

/* ───────── Genes ───────── */
const wilson = (k, n) => { if (!n) return [0, 0]; const z = 1.96, p = k / n, d = 1 + z * z / n, c = p + z * z / (2 * n), a = z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)); return [(c - a) / d, (c + a) / d]; };
function tabGenes() {
  main.innerHTML = `<section class="panel"><h2>Results by gene</h2><div id="gbar"></div><p class="cap">Each dot is the fraction of a gene's positions with a statistic that pass the thresholds of the bar, with its Wilson 95 % interval (line); genes in genome order, the dashed line is the whole set; k/n = positions passing / positions with a statistic.</p><div id="gtab"></div></section>
    <section class="panel"><h2>Amino acid changes</h2><div class="opts"><label>Gene <select id="gsel"></select></label></div><div id="gaa"></div></section>`;
  st.onThr = drawGenes; drawGenes();
}
function drawGenes() {
  const REF = scopeRef(), all = scopeVars();
  if (!all.length) { $("#gbar").innerHTML = `<p class="muted">No variant has a statistic in this scope.</p>`; $("#gaa").innerHTML = ""; return; }
  const by = new Map();
  all.forEach(v => { const k = v.gene || "non-coding"; if (!by.has(k)) by.set(k, {name: k, pos: new Set(), pp: new Set(), lp: new Set(), nv: 0, mp: new Map()});
    const o = by.get(k); o.nv++; const pk = posKey(v); o.pos.add(pk); const s = inMode(v); if (s) o.pp.add(pk); if (v.tag) o.lp.add(pk);
    if (v.mp) v.mp.forEach(m => { if (!o.mp.has(m[0])) o.mp.set(m[0], {pos: new Set(), pp: new Set()}); const q = o.mp.get(m[0]); q.pos.add(pk); if (s) q.pp.add(pk); }); });
  const tot = {n: 0, k: 0}; by.forEach(o => { tot.n += o.pos.size; tot.k += o.pp.size; }); const f0 = tot.n ? tot.k / tot.n : 0;
  const gl = REF.genes.reduce((a, x) => (a[x.name] = x, a), {});
  const rows = [...by.values()].map(o => ({...o, len: gl[o.name] ? gl[o.name].gend - gl[o.name].gstart + 1 : null, gs: gl[o.name] ? gl[o.name].gstart : 1e12, n: o.pos.size, k: o.pp.size}));
  rows.sort((a, b) => a.gs - b.gs);
  const overl = REF.genes.some((a, i) => REF.genes.some((b, j) => i < j && a.contig === b.contig && a.gstart <= b.gend && b.gstart <= a.gend));
  const flat = []; rows.forEach(r => { flat.push(r); r.mp.forEach((q, name) => flat.push({name: "   ↳ " + name, n: q.pos.size, k: q.pp.size, sub: true, len: null})); });
  const host = $("#gbar"), draw = h => {
    const W = h.clientWidth || 800, rh = 20, m = {l: 200, r: 90, t: 24, b: 46}, H = m.t + flat.length * rh + m.b, x = scale(0, 1, m.l, W - m.r);
    const svg = el("svg", {viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Fraction of positions passing the thresholds, by gene"});
    [0, .25, .5, .75, 1].forEach(f => { el("line", {x1: x(f), x2: x(f), y1: m.t, y2: H - m.b, stroke: "var(--grid)"}, svg); el("text", {x: x(f), y: H - m.b + 14, "text-anchor": "middle"}, svg).textContent = Math.round(f * 100) + " %"; });
    el("text", {x: (m.l + W - m.r) / 2, y: H - 4, "text-anchor": "middle"}, svg).textContent = "positions passing the thresholds / positions with a statistic (%), Wilson 95 % interval";
    el("line", {x1: x(f0), x2: x(f0), y1: m.t - 6, y2: H - m.b, stroke: "var(--text)", "stroke-dasharray": "4 3"}, svg);
    // label in the top margin (rows start at m.t): to the right of the line, or to its left when it would pass the plot's right edge
    const wl = `whole set ${pc(tot.k, tot.n)}`, right = x(f0) + 4 + wl.length * 5.6 <= W - m.r;
    el("text", {x: right ? x(f0) + 4 : x(f0) - 4, y: m.t - 9, "text-anchor": right ? "start" : "end", style: "fill:var(--text2)", class: "gwhole"}, svg).textContent = wl;
    flat.forEach((r, j) => { const yy = m.t + j * rh + rh / 2, [lo, hi] = wilson(r.k, r.n), f = r.n ? r.k / r.n : 0;
      el("text", {x: m.l - 6, y: yy + 4, "text-anchor": "end", style: r.sub ? "fill:var(--muted)" : ""}, svg).textContent = r.name.length > 34 ? r.name.slice(0, 32) + "…" : r.name;
      el("line", {x1: x(lo), x2: x(hi), y1: yy, y2: yy, stroke: "var(--text2)", "stroke-width": 1.4}, svg);
      const c = el("circle", {cx: x(f), cy: yy, r: r.sub ? 3.2 : 4.4, fill: "var(--mark)"}, svg);
      c.addEventListener("mousemove", ev => showTip(ev, `<b>${esc(r.name.trim())}</b>${r.len ? `length ${loc(r.len)} nt<br>` : ""}positions with a statistic ${loc(r.n)}<br>passing ${loc(r.k)} (${pc(r.k, r.n)}; CI95 % ${wb(lo)}–${wb(hi)} %)${r.len ? `<br>evaluated positions per kb: ${(1000 * r.n / r.len).toFixed(0)}` : ""}`)); c.addEventListener("mouseleave", hideTip);
      el("text", {x: W - m.r + 12, y: yy + 4, style: "fill:var(--text2)"}, svg).textContent = `${r.k}/${r.n}`; });
    h.replaceChildren(svg);
  };
  draw(host); host._re = draw; decorate(host);
  $("#gtab").innerHTML = `<div class="tw free"><table><thead><tr><th>Gene</th><th class="num" title="Length of the CDS">Length (nt)</th><th class="num" title="Positions with a statistic (they pass the |Δf| prefilter and the depth filters)">Positions with a statistic</th><th class="num">Variants</th><th class="num">Positions passing</th><th class="num">Fraction (CI 95 %)</th><th class="num" title="Positions with SRASel's own label (independent of the thresholds of the bar)">SRASel-labelled positions</th></tr></thead><tbody>${rows.map(r => { const [lo, hi] = wilson(r.k, r.n); return `<tr><td>${esc(r.name)}</td><td class="num">${r.len ? loc(r.len) : "–"}</td><td class="num">${loc(r.n)}</td><td class="num">${loc(r.nv)}</td><td class="num">${loc(r.k)}</td><td class="num">${pc(r.k, r.n)} (${wb(lo)}–${wb(hi)})</td><td class="num">${loc(r.lp.size)}</td></tr>`; }).join("")}</tbody></table></div>
    <p class="cap">The fraction is relative to positions with a statistic, not to nucleotides of the gene.${overl ? " With overlapping genes each position is assigned to its main reading frame, so rows do not add up." : ""}</p>`;
  const sel = $("#gsel"), names = rows.map(r => r.name);
  sel.innerHTML = names.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("");
  if (!st.gsel || !names.includes(st.gsel)) st.gsel = st.gene && names.includes(st.gene) ? st.gene : (rows.slice().sort((a, b) => b.k - a.k)[0] || {}).name || names[0];
  sel.value = st.gsel; sel.onchange = e => { st.gsel = e.target.value; drawGeneAA(); }; drawGeneAA();
}
function drawGeneAA() {
  const name = st.gsel, vs = scopeVars().filter(v => (v.gene || "non-coding") === name && inMode(v)).sort((a, b) => (a.ai || 0) - (b.ai || 0) || a._i - b._i);
  const host = $("#gaa");
  if (!vs.length) { host.innerHTML = `<p class="muted">No variant of this gene passes the current thresholds.</p>`; return; }
  host.innerHTML = `<p class="cap" style="margin-top:0">${loc(vs.length)} variant${vs.length === 1 ? "" : "s"} in ${esc(name)}, by amino acid position. Click a row for its trajectory.</p><div id="gaat"></div>`;
  vtable($("#gaat"), vs, {cols: ["ai", "aa", ...(vs.some(v => v.mp) ? ["mpn"] : []), ...(multi() ? ["_s"] : []), "pos", "var", "df", "p", "tag", ...(vs.some(v => v.of) ? ["of"] : [])], id: "aa", fname: "amino_acid_changes_" + slug(name)});
}

/* ───────── Quality ───────── */
/* series that can be hidden from the legend (st.hid holds the indices of the hidden series); colour and marker shape stay with the series */
const serCol = (li, n) => n > 8 ? "var(--muted)" : OKI[li % OKI.length], serShape = (li, n) => n > 8 ? "circle" : SHP[li % SHP.length];
function serLegend(host, Ls, redraw) {
  if (Ls.length < 2) { host.innerHTML = ""; return; }
  host.innerHTML = Ls.map(({p, i}, li) => `<button type="button" class="lg" data-i="${i}" aria-pressed="${!st.hid.has(i)}" title="Show or hide this series">${swatch(serShape(li, Ls.length), serCol(li, Ls.length))}${esc(pname(p))}</button>`).join("") + `<span class="muted">click a name to show or hide it</span>`;
  host.querySelectorAll("button.lg").forEach(b => b.onclick = () => { const i = +b.dataset.i; st.hid.has(i) ? st.hid.delete(i) : st.hid.add(i); redraw(); });
}
function redrawSeries(Ls) {                                   // after a series was shown or hidden: legends and the line charts of the Quality tab
  const cb = () => redrawSeries(Ls);
  serLegend($("#cleg"), Ls, cb); if ($("#dlg")) serLegend($("#dlg"), Ls, cb);
  ["#cvg", "#dv1", "#dv3"].forEach(id => { const h = $(id); if (h && h._re && h.querySelector("svg")) { h._re(h); decorate(h); } });
}
function divLines(host, L0, acc, o) {
  const L = L0.filter(({i}) => !st.hid.has(i)), W = host.clientWidth || 560, H = 240 * HSCALE, m = {l: 74, r: 14, t: 12, b: 40};
  const svg = el("svg", {viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": o.title});
  const xs = L.flatMap(({p}) => p.samples.map(s => s.day)), ys = L.flatMap(({p}) => p.samples.map(s => acc(s, p))).filter(v => v != null && isFinite(v));
  const xmax = Math.max(1, ...xs), ymax = Math.max(1e-9, ...ys) * 1.08, ymin = o.log ? Math.max(1, Math.min(...ys, o.ref || Infinity) / 1.5) : 0, x = scale(0, xmax, m.l, W - m.r);
  const y = o.log ? (v => H - m.b - (Math.log10(Math.max(v, ymin)) - Math.log10(ymin)) / ((Math.log10(ymax) - Math.log10(ymin)) || 1) * (H - m.b - m.t)) : scale(0, ymax, H - m.b, m.t);
  (o.log ? [1, 2, 3, 5, 10, 20, 30, 50, 100, 200, 300, 500, 1000, 2000, 3000, 5000, 10000, 20000, 30000, 50000, 100000].filter(v => v >= ymin && v <= ymax) : niceTicks(ymax, 4)).forEach(v => { el("line", {x1: m.l, x2: W - m.r, y1: y(v), y2: y(v), stroke: "var(--grid)"}, svg); el("text", {x: m.l - 6, y: y(v) + 4, "text-anchor": "end"}, svg).textContent = o.unit(v); });
  if (o.ref) { el("line", {x1: m.l, x2: W - m.r, y1: y(o.ref), y2: y(o.ref), stroke: "var(--no)", "stroke-dasharray": "4 3"}, svg); el("text", {x: W - m.r - 2, y: y(o.ref) - 4, "text-anchor": "end", style: "fill:var(--no)"}, svg).textContent = o.ref + "×"; }
  niceTicks(xmax, Math.max(3, Math.min(6, Math.round((W - m.l - m.r) / 80)))).forEach(v => el("text", {x: x(v), y: H - 18, "text-anchor": "middle"}, svg).textContent = Math.round(v));
  el("text", {x: (m.l + W - m.r) / 2, y: H - 3, "text-anchor": "middle"}, svg).textContent = "time since the first sample of each series (days)";
  el("text", {transform: `translate(12 ${(m.t + H - m.b) / 2}) rotate(-90)`, "text-anchor": "middle"}, svg).textContent = o.ylab;
  L.forEach(({p, i}) => {
    const li = L0.findIndex(q => q.i === i), c = serCol(li, L0.length), pts = p.samples.map(s => [s.day, acc(s, p), s]).filter(q => q[1] != null && isFinite(q[1])); if (!pts.length) return;
    el("polyline", {points: pts.map(q => `${x(q[0])},${y(q[1])}`).join(" "), fill: "none", stroke: c, "stroke-width": 1.6, opacity: .9}, svg);
    pts.forEach(q => { const k = mk(svg, serShape(li, L0.length), x(q[0]), y(q[1]), 3.6, {fill: c, stroke: "var(--surface)", "stroke-width": 1});
      k.addEventListener("mousemove", ev => showTip(ev, `<b>${esc(pname(p))} · ${esc(q[2].id)}</b>day ${q[2].day}<br>${o.title}: ${o.exact ? o.exact(q[1]) : o.unit(q[1], 4)}${q[2].depth < 100 ? "<br><b>below 100×</b>" : ""}`)); k.addEventListener("mouseleave", hideTip); });
  });
  host.replaceChildren(svg);
}
function pairHeat(host, legend, p) {
  const S = p.samples, n = S.length, top = window._pairTop || maxOf(p.div.flat().filter(v => v != null && v > 0), 1e-9);
  const labs = S.map(s => s.id + " (d" + s.day + ")");
  heat(host, {rows: labs, cols: S.map(s => s.id), vals: p.div, norm: v => v / top, color: seqColor, labels: n <= 8,
    cellText: v => String(+v.toPrecision(2)), ml: 110, mb: 34, aria: "Divergence between time points",
    tip: (r, c, v) => `<b>${esc(labs[r])} ↔ ${esc(labs[c])}</b>mean divergence ${v == null ? "–" : sg(v)}<br>${loc(p.npos[r][c])} positions compared`,
    colLabels: (svg, m, cw, h) => S.forEach((s, c) => { if (cw > 26 || c % 2 === 0) el("text", {x: m.l + c * cw + cw / 2, y: m.t + h + 14, "text-anchor": "middle"}, svg).textContent = s.id; })});
  cbar(legend, "mean total variation distance per position between two samples", niceTicks(top, 4).map(t => [t / top, String(+t.toPrecision(6))]), seqColor);
}
function divHeat(host, legend, p) {
  const S = p.samples, B = p.bins, abs = st.hmode === "abs", R = refOf(p);
  let vals = p.hbin, top;
  if (abs) top = window._hbTop || maxOf(vals.flat().filter(v => v != null), 1e-9);
  else { vals = p.hbin.map(row => row.map((v, b) => v == null || p.hbin[0][b] == null ? null : v - p.hbin[0][b])); top = maxOf(vals.slice(1).flat().filter(v => v != null).map(Math.abs), 1e-9); }
  const labs = S.map(s => s.id + " (d" + s.day + ")");
  heat(host, {rows: labs, cols: B.map((b, i) => i), vals, norm: v => v / top, color: abs ? seqColor : divColor, labels: false, ml: 110, mb: 44, maxch: 26,
    aria: "Diversity along the genome by time point",
    tip: (r, c, v) => `<b>${esc(labs[r])}</b>${esc(B[c].contig)}:${B[c].start}–${B[c].end}<br>${abs ? "diversity" : "Δ diversity vs first time point"} ${v == null ? "no data" : (v >= 0 && !abs ? "+" : "") + sg(v)}`,
    colLabels: (svg, m, cw, h) => {
      const mkk = Math.max(1, Math.round(B.length / 10)); let pv0 = null;
      if (R.contigs.length > 1) B.forEach((b, c) => { if (b.contig !== pv0) el("text", {x: m.l + c * cw + 2, y: m.t + h + 14, "text-anchor": "start"}, svg).textContent = b.contig.replace(/^NC_0*/, "").slice(0, 8); pv0 = b.contig; });
      else B.forEach((b, c) => { if (c % mkk === 0) el("text", {x: m.l + c * cw, y: m.t + h + 14, "text-anchor": "start"}, svg).textContent = kfmt(b.start); });
      el("text", {x: m.l + (cw * B.length) / 2, y: m.t + h + 30, "text-anchor": "middle"}, svg).textContent = R.contigs.length > 1 ? "contig (windows in genome order)" : "position in the reference (nt, start of each window)";
      let prev = null;
      B.forEach((b, c) => { if (prev !== null && b.contig !== prev) el("line", {x1: m.l + c * cw, x2: m.l + c * cw, y1: m.t, y2: m.t + h + 4, stroke: "var(--text)", "stroke-width": 1.2}, svg); prev = b.contig; });
    }});
  cbar(legend, abs ? "mean heterozygosity 1 − Σf² of the positions in the window" : "change of heterozygosity from the first sample (← less diverse · more diverse →)",
    abs ? niceTicks(top, 4).map(t => [t / top, String(+t.toPrecision(6))]) : symT(top, niceTicks(top, 2)[1] || top).sort((a, b) => a - b).map(t => [(t / top + 1) / 2, (t > 0 ? "+" : "") + String(+t.toPrecision(6))]), abs ? seqColor : divColor, !abs);
}
function pacRow(i) {
  const p = DATA.patients[i], d = p.samples.map(s => s.day), dep = p.samples.map(s => s.depth).sort((a, b) => a - b), t = tally(p.variants, false);
  return {i, p, n: p.samples.length, span: Math.max(0, ...d) - Math.min(0, ...d), cov: dep.length ? dep[Math.floor(dep.length / 2)] : 0, low: dep.filter(x => x < 100).length, t,
    gaps: [...new Set(d)].sort((a, b) => a - b).map((x, k, a) => k ? x - a[k - 1] : 0).slice(1)};
}
function tabQuality() {
  const L = DATA.patients.map((p, i) => ({p, i})), Ls = L.filter(({p}) => p.samples.length), many = DATA.groups.length > 1;
  const low = Ls.flatMap(({p}) => p.samples.filter(s => s.depth < 100).map(s => `${pname(p)} ${s.id} (${Math.round(s.depth)}×)`));
  const thin = Ls.flatMap(({p}) => p.samples.filter(s => s.ncov < 0.9 * maxOf(p.samples.map(q => q.ncov), 0)).map(s => `${pname(p)} ${s.id} (${loc(s.ncov)} positions)`));
  const rows = L.map(({i}) => pacRow(i));
  main.innerHTML = `<section class="panel"><h2>Quality warnings</h2><div class="note ${low.length || thin.length ? "warn" : ""}">${low.length ? `Mean coverage below 100×: ${low.map(esc).join("; ")}.` : "No sample has a mean coverage below 100×."}<br>${thin.length ? `Fewer than 90 % of the positions covered, relative to the best sample of the series: ${thin.slice(0, 12).map(esc).join("; ")}${thin.length > 12 ? "…" : ""}.` : "All samples cover at least 90 % of the positions of their series."}</div></section>
    <section class="panel"><h2>Series</h2><div class="tw free"><table><thead><tr><th>Series</th><th class="num">Samples</th><th class="num">Follow-up (days)</th><th class="num" title="Smallest and largest interval between consecutive dates">Gaps (days)</th><th class="num">Median coverage</th><th class="num">Samples &lt; 100×</th><th class="num" title="Positions with a statistic">Evaluated positions</th><th class="num">Variants</th><th class="num">SRASel-labelled</th></tr></thead><tbody>
      ${rows.map(r => `<tr><td>${esc(pname(r.p))}${many ? ` <span class="muted">· ${esc(gname(r.p))}</span>` : ""}</td><td class="num">${r.n}</td><td class="num">${loc(r.span)}</td><td class="num">${r.gaps.length ? Math.min(...r.gaps) + " – " + Math.max(...r.gaps) : "–"}</td><td class="num">${loc(Math.round(r.cov))}×</td><td class="num ${r.low ? "bad" : ""}">${r.low}</td><td class="num">${loc(r.t.np)}</td><td class="num">${loc(r.t.nv)}</td><td class="num">${loc(r.t.lab)}</td></tr>`).join("")}</tbody></table></div></section>
    <section class="panel"><h2>Coverage</h2><div class="legend" id="cleg"></div><div id="cvg"></div><p class="cap">Mean depth of each sample (average over the positions with data) against its day, on a log scale; the red dashed line marks 100×.</p></section>
    <section class="panel"><details class="fold" id="divd" ${st.divOpen ? "open" : ""}><summary>Diversity and divergence</summary><div id="divb"></div></details></section>`;
  const cv = $("#cvg"), cd = h => divLines(h, Ls, s => s.depth, {title: "mean depth", ylab: "mean depth (reads, log scale)", unit: (v, d) => (d ? v.toFixed(0) : loc(Math.round(v))) + "×", exact: v => ex(v) + "×", log: true, ref: 100});
  serLegend($("#cleg"), Ls, () => redrawSeries(Ls));
  if (Ls.length) { cd(cv); cv._re = cd; decorate(cv); } else cv.innerHTML = `<p class="muted">No position × time matrix was found for these series.</p>`;
  const det = $("#divd"); det.ontoggle = () => { if (!det.isConnected) return; st.divOpen = det.open; if (det.open && !$("#divb").childElementCount) drawDiversity(Ls); };
  if (st.divOpen) drawDiversity(Ls);
}
function drawDiversity(Ls) {
  const b = $("#divb"); if (!Ls.length) { b.innerHTML = `<p class="muted">No matrices available.</p>`; return; }
  if (st.hsel == null || !Ls.some(x => x.i === st.hsel)) st.hsel = Ls[0].i;
  b.innerHTML = `<p class="cap" style="margin-top:0">Within each series (one virus, one reference); never compare series of different viruses.</p><div class="legend" id="dlg"></div>
    <div class="two"><div><h3>Heterozygosity</h3><div id="dv1"></div><p class="cap">Mean per-position heterozygosity (1 − Σf²) of each sample against its day.</p></div><div><h3>Divergence from the first sample</h3><div id="dv3"></div><p class="cap">Mean total variation distance between each sample and the first, against its day.</p></div></div>
    <div class="opts" style="margin-top:12px"><label>Series <select id="dhs">${Ls.map(({p, i}) => `<option value="${i}" ${i === st.hsel ? "selected" : ""}>${esc(pname(p))}</option>`).join("")}</select></label>
      <label><input type="checkbox" id="dcom"> common colour scale for the set</label>
      <label>Diversity per window <select id="hm"><option value="abs">absolute</option><option value="delta">change from the first sample</option></select></label></div>
    <p class="small" id="dnote"></p>
    <div class="two"><div><h3>Divergence between all pairs of samples</h3><div id="hp"></div><div id="hpl"></div><p class="cap">Each cell is the mean total variation distance between two samples, over the positions covered in both.</p></div><div><h3>Diversity along the genome</h3><div id="hd"></div><div id="hdl"></div><p class="cap">Each cell is the diversity of one sample (row) in one window of the genome (column).</p></div></div>`;
  const dv = (id, acc, o) => { const h = $("#" + id), f = x => divLines(x, Ls, acc, o); f(h); h._re = f; decorate(h); };
  dv("dv1", s => s.h, {title: "mean heterozygosity", ylab: "mean heterozygosity 1 − Σf²", unit: (v, d) => v.toFixed(d || 4), exact: v => ex(v)});
  dv("dv3", (s, p) => { const j = p.samples.indexOf(s); return j >= 0 && p.div && p.div[0] ? p.div[0][j] : null; }, {title: "divergence from the first sample", ylab: "mean total variation distance", unit: (v, d) => v.toFixed(d || 4), exact: v => ex(v)});
  serLegend($("#dlg"), Ls, () => redrawSeries(Ls));
  $("#dhs").onchange = e => { st.hsel = +e.target.value; drawHeat(); }; $("#dcom").checked = st.hcommon; $("#dcom").onchange = e => { st.hcommon = e.target.checked; drawHeat(); };
  $("#hm").value = st.hmode; $("#hm").onchange = e => { st.hmode = e.target.value; drawHeat(); }; drawHeat();
}
function drawHeat() {
  const p = DATA.patients[st.hsel], grp = DATA.patients.filter(q => q.g === p.g && q.samples.length);
  const topOwn = maxOf(p.div.flat().filter(v => v != null && v > 0), 1e-9), topCom = maxOf(grp.flatMap(q => q.div.flat().filter(v => v != null && v > 0)), 1e-9);
  window._pairTop = st.hcommon ? topCom : null; window._hbTop = st.hcommon ? maxOf(grp.flatMap(q => q.hbin.flat().filter(v => v != null)), 1e-9) : null;
  $("#dnote").innerHTML = st.hcommon ? `Common scale for the ${grp.length} series of the set (maximum divergence ${sg(topCom)}).` : `Own scale of this series (maximum divergence ${sg(topOwn)}; the set reaches ${sg(topCom)}): do not compare colour intensity with another series, or tick the common scale.`;
  const hp = $("#hp"), hd = $("#hd"); pairHeat(hp, $("#hpl"), p); divHeat(hd, $("#hdl"), p);
  hp._re = h => pairHeat(h, $("#hpl"), p); hd._re = h => divHeat(h, $("#hdl"), p); decorate(hp); decorate(hd);
}

/* ───────── About ───────── */
const refLine = R => R.contigs.map(c => `<code>${esc(c.name)}</code> (${loc(c.length)} nt${c.topology ? ", " + esc(c.topology) : ""}${c.description ? " · " + esc(c.description) : ""})`).join("<br>");
function tabAbout() {
  const pr = DATA.params, cmd = String(DATA.cmd || "");
  main.innerHTML = `<section class="panel"><h2>Analysis parameters</h2><dl class="kv">
      <dt>Test</dt><dd>permutation p with ${D0.nperm} permutations (minimum p ${(1 / (D0.nperm + 1)).toFixed(5)})</dd>
      <dt>SRASel label</dt><dd>p &lt; 0.05 and |estimated Δf| ≥ ${D0.df}; the label is fixed when the program runs</dd>
      <dt>Thresholds of the bar</dt><dd>p ≤ α and |estimated Δf| ≥ δ over all tested variants; by default SRASel's own values (p ${D0.p}, |Δf| ${D0.df})</dd>
      <dt>Minimum depth</dt><dd>${pr.min_depth} reads per position</dd>
      <dt>Minimum frequency</dt><dd>${pr.min_maf} (lower alleles are treated as error)</dd>
      <dt>Estimated Δf</dt><dd>β × days of follow-up, from the weighted fit</dd>
      <dt>Observed Δf</dt><dd>last − first date with data</dd></dl></section>
    <section class="panel"><h2>Reference and annotation</h2>${DATA.groups.map((g, gi) => `<p>${DATA.groups.length > 1 ? `<b>${esc(g.name)}</b><br>` : ""}Reference for mapping and reading frames (<code>${esc(g.ref_dir)}</code>):<br>${refLine(DATA.refs[gi])}<br>${DATA.refs[gi].n_cds} CDS with their reading frame${(DATA.refs[gi].mp || []).length ? `; ${DATA.refs[gi].mp.length} mature proteins annotated (shown only, not used in the analysis)` : ""}.</p>`).join("")}</section>
    <section class="panel"><h2>Provenance</h2><p>${DATA.prov ? Object.entries(DATA.prov).map(([k, v]) => `${esc(k)} ${esc(v)}`).join(" · ") : "–"}</p>
      <p class="muted" style="margin-bottom:2px">Command</p><pre>${esc(cmd)}</pre>
      <p class="cap">Folders read: ${[...new Set(DATA.processing)].map(x => "<code>" + esc(x) + "</code>").join(", ")}.</p></section>
    <div id="cmp"></div>`;
  if (DATA.compare.length) updRef();
}

/* ── mapping reference: aligned to the NCBI reference, to the patient consensus, or original BAMs ── */
const cmpKey = v => v.cn ? v.cn + ":" + v.var : null;
const aaLet = s => (String(s || "").match(/[A-Z*]|amb/g) || []).join("");
function cmpMaps(c) { return c.series.map(i => { const m = new Map(); DATA.patients[i].variants.forEach(v => { const k = cmpKey(v); if (k && !m.has(k)) m.set(k, v); }); return m; }); }
function agreeScatter(host, MA, MB, la, lb) {
  const W = host.clientWidth || 520, H = 300 * HSCALE, m = {l: 46, r: 14, t: 10, b: 40};
  const svg = el("svg", {viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Δf in two references"});
  const lim = Math.max(1, Math.ceil(maxOf([...MA.values(), ...MB.values()].map(v => Math.abs(v.df == null ? 0 : v.df)), 0) * 4) / 4), x = scale(-lim, lim, m.l, W - m.r), y = scale(-lim, lim, H - m.b, m.t), dft = symT(lim, lim <= 1 ? .5 : 1);
  dft.forEach(v => { el("line", {x1: x(v), x2: x(v), y1: m.t, y2: H - m.b, stroke: v === 0 ? "var(--muted)" : "var(--grid)"}, svg); el("text", {x: x(v), y: H - m.b + 14, "text-anchor": "middle"}, svg).textContent = v;
    el("line", {x1: m.l, x2: W - m.r, y1: y(v), y2: y(v), stroke: v === 0 ? "var(--muted)" : "var(--grid)"}, svg); el("text", {x: m.l - 6, y: y(v) + 4, "text-anchor": "end"}, svg).textContent = v; });
  el("line", {x1: x(-lim), y1: y(-lim), x2: x(lim), y2: y(lim), stroke: "var(--text2)", "stroke-dasharray": "5 4", opacity: .6}, svg);
  el("text", {x: (m.l + W - m.r) / 2, y: H - 4, "text-anchor": "middle"}, svg).textContent = "Estimated Δf · " + la;
  el("text", {transform: `translate(11 ${(m.t + H - m.b) / 2}) rotate(-90)`, "text-anchor": "middle"}, svg).textContent = "Estimated Δf · " + lb;
  const pts = [];
  MA.forEach((va, k) => { const vb = MB.get(k); if (vb && va.df != null && vb.df != null) pts.push({va, vb, a: inMode(va), b: inMode(vb)}); });
  const col = q => q.a && q.b ? "var(--mark)" : (q.a || q.b) ? "var(--warn)" : "var(--neutral)", shp = q => q.a && q.b ? "circle" : (q.a || q.b) ? "diamond" : "circle";
  [pts.filter(q => !q.a && !q.b), pts.filter(q => q.a !== q.b), pts.filter(q => q.a && q.b)].forEach(arr => arr.forEach(q => {
    const c = mk(svg, shp(q), x(q.va.df), y(q.vb.df), q.a || q.b ? 4.6 : 2.8, {fill: col(q), opacity: q.a || q.b ? .9 : .4, stroke: "var(--surface)", "stroke-width": 1});
    c.addEventListener("mousemove", ev => showTip(ev, `<b>${esc(label(q.va))}</b>${esc(la)}: Δf ${ex(q.va.df)} · p ${pex(q.va.p)}<br>${esc(lb)}: Δf ${ex(q.vb.df)} · p ${pex(q.vb.p)}`)); c.addEventListener("mouseleave", hideTip); }));
  host.replaceChildren(svg);
}
function updRef() {
  const selTxt = `p ≤ ${fa(st.alpha)}, |Δf| ≥ ${st.delta}`;
  $("#cmp").innerHTML = DATA.compare.map((c, ci) => {
    const lab = c.labels;
    return `<section class="panel"><h2>Mapping reference · ${esc(c.title)}</h2><p class="small">${c.text || ""}</p>
    <p class="cap">Variants passing the thresholds of the bar (${selTxt}) with each reference.</p><div class="tw free"><table id="cm${ci}"></table></div>
    <h3>Agreement between references</h3><p class="cap" style="margin-top:0">Variants are paired by canonical position (<code>coord_map.tsv</code>) and allele; the amino acid, by <code>aa_map.tsv</code>.</p>
    <div class="tw free"><table id="ca${ci}"></table></div>
    <div class="two">${c.series.slice(1).map((s, k) => `<div><div id="cs${ci}_${k}"></div><p class="cap">Δf with ${esc(lab[0])} (x) and with ${esc(lab[k + 1])} (y). Dark blue circle: in the selection in both; amber diamond: in one; gray circle: in neither (dashed line: equal Δf).</p></div>`).join("")}</div>
    <h3>Discordant variants</h3><p class="cap" style="margin-top:0">In the selection with only one reference; “not tested” = absent from that analysis.</p><div class="tw"><table id="cd${ci}"></table></div></section>`; }).join("");
  DATA.compare.forEach((c, ci) => {
    const Ms = cmpMaps(c), Ps = c.series.map(i => DATA.patients[i]), lab = c.labels;
    const sets = Ms.map(m => new Set([...m.entries()].filter(([k, v]) => inMode(v)).map(([k]) => k)));
    $("#cm" + ci).innerHTML = "<thead><tr><th>Mode</th><th>Mapping reference</th><th class=\"num\">With statistic</th><th class=\"num\">In selection</th><th class=\"num\">Up</th><th class=\"num\">Down</th><th class=\"num\">SRASel-labelled</th></tr></thead><tbody>" +
      Ps.map((p, k) => { const ok = p.variants.filter(inMode); return `<tr><td><b>${esc(lab[k])}</b></td><td class="small" style="white-space:normal;min-width:260px">${esc(p.ref_note || gname(p))}</td><td class="num">${p.n_tested}</td><td class="num"><b>${ok.length}</b></td><td class="num">${ok.filter(v => v.df > 0).length}</td><td class="num">${ok.filter(v => v.df < 0).length}</td><td class="num">${p.n_sel}</td></tr>`; }).join("") + "</tbody>";
    const rows = [];
    for (let a = 0; a < Ps.length; a++) for (let b = a + 1; b < Ps.length; b++) {
      const both = [...sets[a]].filter(k => sets[b].has(k)), onlyA = sets[a].size - both.length, onlyB = sets[b].size - both.length;
      let g = 0, aa = 0, num = 0, n = 0;
      both.forEach(k => { const va = Ms[a].get(k), vb = Ms[b].get(k); n++; g += (va.gene === vb.gene); aa += (aaLet(va.aa) === aaLet(vb.aa)); num += (va.ca && va.ca === vb.ca) || (!va.gene && !vb.gene); });
      const un = both.length + onlyA + onlyB, pcx = x => n ? (100 * x / n).toFixed(0) + " %" : "–";
      rows.push(`<tr><td>${esc(lab[a])} ↔ ${esc(lab[b])}</td><td class="num">${both.length}</td><td class="num">${onlyA}</td><td class="num">${onlyB}</td><td class="num"><b>${un ? (both.length / un).toFixed(2) : "–"}</b></td><td class="num">${pcx(g)}</td><td class="num">${pcx(aa)}</td><td class="num">${pcx(num)}</td></tr>`);
    }
    $("#ca" + ci).innerHTML = "<thead><tr><th>Pair</th><th class=\"num\">Common</th><th class=\"num\">Only the 1st</th><th class=\"num\">Only the 2nd</th><th class=\"num\">Agreement (Jaccard)</th><th class=\"num\">Same gene</th><th class=\"num\">Same aa</th><th class=\"num\">Same numbering</th></tr></thead><tbody>" + rows.join("") + "</tbody>";
    c.series.slice(1).forEach((s, k) => { const h = $(`#cs${ci}_${k}`), f = x => agreeScatter(x, Ms[0], Ms[k + 1], lab[0], lab[k + 1]); f(h); h._re = f; decorate(h); });
    const disc = [], all = new Set(sets.flatMap(x => [...x]));
    all.forEach(k => { const inn = sets.map(x => x.has(k)); if (inn.some(Boolean) && !inn.every(Boolean)) disc.push(k); });
    const first = k => Ms.map(m => m.get(k)).find(Boolean);
    disc.sort((a, b) => Math.min(...Ms.map(m => m.get(a) ? m.get(a).p : 1)) - Math.min(...Ms.map(m => m.get(b) ? m.get(b).p : 1)));
    if (!disc.length) { $("#cd" + ci).outerHTML = `<p class="muted">None.</p>`; return; }
    $("#cd" + ci).innerHTML = `<thead><tr><th>Effect</th><th>Gene</th><th>Canonical nt</th><th>Allele</th>${lab.map(l => `<th>${esc(l)}</th>`).join("")}</tr></thead><tbody>` +
      disc.slice(0, 60).map(k => { const v = first(k); return `<tr><td>${esc(v.aa)}</td><td>${esc(v.gene)}</td><td>${v.cn}</td><td>${esc(v.var.slice(0, 8))}</td>` +
        Ms.map(m => { const w = m.get(k); return w ? `<td class="${inMode(w) ? "ok" : "muted"}">${inMode(w) ? "in " : "out "}Δf ${fmt(w.df)} · p ${fp(w.p)}</td>` : '<td class="muted">not tested</td>'; }).join("") + "</tr>"; }).join("") + "</tbody>" +
      (disc.length > 60 ? `<caption class="cap">first 60 of ${disc.length}</caption>` : "");
  });
}

/* ───────── Validation (only with --notes: results already published) ───────── */
function tabVal() {
  const L = SC().filter(({p}) => !multi() || p.checks || p.cards), ic = {ok: "ok", no: "no", info: "info"};
  main.innerHTML = `<p class="cap">Checks against published results (this tab exists only when the report is built with <code>--notes</code>).</p>` +
    (L.map(({p, i}) => `<section class="panel"><h2>${esc(pname(p))}</h2>
      ${p.checks ? `<ul class="checks">${p.checks.map(c => `<li><b class="${c[0] === "ok" ? "ok" : c[0] === "no" ? "bad" : "muted"}">${esc(ic[c[0]] || c[0])}</b> · ${esc(c[1])}<br><span class="small muted">${esc(c[2])}</span></li>`).join("")}</ul>` : "<p class='muted'>No checks for this series.</p>"}
      ${p.sites && p.sites.length ? '<p class="cap">Sites from the literature (click to see the trajectory even if the variant is not labelled):</p><div class="opts">' + p.sites.map((e, k) => `<button class="btn" data-x="${i}:${k}" type="button">${esc(e.why)}</button>`).join("") + "</div>" : ""}
      <div id="vtraj${i}"></div>${(p.cards || []).map(c => `<h3>${esc(c[0])}</h3><div>${c[1]}</div>`).join("")}</section>`).join("") || "<section class='panel'><p class='muted'>No checks for these series.</p></section>");
  document.querySelectorAll("[data-x]").forEach(b => b.onclick = () => { const [i, k] = b.dataset.x.split(":").map(Number), e = DATA.patients[i].sites[k];
    $("#vtraj" + i).innerHTML = `<p class="small"><b>${esc(e.why)}</b></p><div id="vt${i}"></div>`;
    dynChart($("#vt" + i), [{pos: e.pos, var: e.var, days: e.days, k: e.k, n: e.n, df: null, beta: null, _i: i, _r: refOf(DATA.patients[i]), gene: "", aa: ""}], {h: 260}); });
}

/* ───────── Simulation: known ground truth ───────── */
const TCOL = {P: "#6A4FD0", M: "#CC79A7", I: "#009E73", "N:iid": "#8A94A6", "N:drift": "#E69F00", "": "#C9D1DC"};
const TNAME = {P: "planted (should rise)", M: "mirror allele (should fall)", I: "planted indel", "N:iid": "neutral, independent noise", "N:drift": "neutral, with drift", "": "no information"};
const passAt = (v, a, d) => v.p != null && v.df != null && v.p <= a + 1e-12 && Math.abs(v.df) >= d - 1e-12;
const pct = (a, b) => b ? (100 * a / b).toFixed(1) + " %" : "–";
function simCounts(p, a, d) {
  const vs = p.variants, T = p.truth, pl = vs.filter(v => v.t === "P" || v.t === "I");
  const det = pl.filter(v => passAt(v, a, d) && (v.t === "I" || v.df > 0));
  const hi = pl.filter(v => v.t === "P" && v.td != null && v.td >= 0.3), lo = pl.filter(v => v.t === "P" && v.td != null && v.td < 0.3);
  const fpc = cls => { const pos = {}; vs.filter(v => v.t === "N:" + cls).forEach(v => { pos[v.pos] = pos[v.pos] || passAt(v, a, d); }); const k = Object.keys(pos); return {fp: k.filter(x => pos[x]).length, n: k.length}; };
  const oth = new Set(vs.filter(v => v.t === "" && passAt(v, a, d)).map(v => v.pos)).size;
  return {nPl: T.planted.length, ev: pl.length, det: det.length, hi: [hi.filter(v => passAt(v, a, d) && v.df > 0).length, hi.length],
          lo: [lo.filter(v => passAt(v, a, d) && v.df > 0).length, lo.length], iid: fpc("iid"), drift: fpc("drift"), oth};
}
function tabSim() {
  const L = SC().filter(({p}) => p.truth), T = thr();
  if (!L.length) { main.innerHTML = `<section class="panel"><p class="muted">The series in this scope have no known ground truth (--truth was not passed).</p></section>`; return; }
  if (st.simS == null || !L.some(x => x.i === st.simS)) st.simS = L[0].i;
  main.innerHTML = `<section class="panel"><h2>Simulation with known ground truth</h2><p class="cap" style="margin-top:0">Planted variants (rising or falling) and neutral positions (independent noise or drift). Thresholds in use: p ≤ ${fa(T.a)}, |Δf| ≥ ${T.d} (change them in the bar above).</p>
    ${L.length > 1 ? `<div class="tw free"><table id="smt"></table></div>` : ""}</section>
    <section class="panel"><h2 id="sh"></h2><div class="kpis" id="scards"></div></section>
    <section class="panel"><h2>Each variant against the truth</h2><div id="ssc"></div><p class="cap">Every tested variant as in the Variants tab (estimated Δf against −log10 p), coloured by its known class in the simulation.</p></section>
    <section class="panel"><h2>Sensitivity and false positives by p threshold</h2><div id="scv"></div><p class="cap">Detected fraction of planted variants and fraction of neutral positions passing, at the current |Δf|; the vertical line is the current p.</p></section>
    <section class="panel"><h2>Planted variants</h2><div class="tw"><table id="ptab"></table></div></section>`;
  if (L.length > 1) {
    const tt = {nPl: 0, det: 0, iid: [0, 0], der: [0, 0]};
    const rows = L.map(({p, i}) => { const c = simCounts(p, T.a, T.d); tt.nPl += c.nPl; tt.det += c.det; tt.iid[0] += c.iid.fp; tt.iid[1] += c.iid.n; tt.der[0] += c.drift.fp; tt.der[1] += c.drift.n;
      return `<tr data-i="${i}" tabindex="0" style="cursor:pointer" class="${i === st.simS ? "sel" : ""}"><td>${esc(pname(p))}</td><td class="num">${c.nPl}</td><td class="num">${c.det}</td><td class="num"><b>${pct(c.det, c.nPl)}</b></td><td class="num">${c.iid.fp}/${c.iid.n}</td><td class="num">${pct(c.iid.fp, c.iid.n)}</td><td class="num">${c.drift.n ? pct(c.drift.fp, c.drift.n) : "–"}</td><td class="num">${c.oth}</td></tr>`; });
    $("#smt").innerHTML = "<thead><tr><th>Series</th><th class=\"num\">Planted</th><th class=\"num\">Detected</th><th class=\"num\">Sensitivity</th><th class=\"num\">FP (iid)</th><th class=\"num\">FP (iid) %</th><th class=\"num\">FP (drift) %</th><th class=\"num\">Others passing</th></tr></thead><tbody>" + rows.join("") +
      `<tr><td><b>Total</b></td><td class="num"><b>${tt.nPl}</b></td><td class="num"><b>${tt.det}</b></td><td class="num"><b>${pct(tt.det, tt.nPl)}</b></td><td class="num">${tt.iid[0]}/${tt.iid[1]}</td><td class="num"><b>${pct(tt.iid[0], tt.iid[1])}</b></td><td class="num"><b>${tt.der[1] ? pct(tt.der[0], tt.der[1]) : "–"}</b></td><td></td></tr></tbody>`;
    document.querySelectorAll("#smt tbody tr[data-i]").forEach(r => { const f = () => { st.simS = +r.dataset.i; tabSim(); }; r.onclick = f; r.onkeydown = e => { if (e.key === "Enter") f(); }; });
  }
  const p = DATA.patients[st.simS], c = simCounts(p, T.a, T.d);
  $("#sh").textContent = "Results · " + pname(p);
  $("#scards").innerHTML = `<div class="kpi"><div class="l">Sensitivity</div><div class="v">${pct(c.det, c.nPl)}</div><div class="s">${c.det} of ${c.nPl} planted detected in the right direction${c.nPl > c.ev ? ` (${c.nPl - c.ev} not evaluable: low depth)` : ""}; change ≥ 0.3: ${pct(c.hi[0], c.hi[1])}, &lt; 0.3: ${pct(c.lo[0], c.lo[1])}</div></div>
    <div class="kpi"><div class="l">False positives · noise</div><div class="v">${pct(c.iid.fp, c.iid.n)}</div><div class="s">${c.iid.fp} of ${c.iid.n} neutral positions (about ${(100 * T.a).toFixed(0)} % expected)</div></div>
    <div class="kpi"><div class="l">False positives · drift</div><div class="v">${pct(c.drift.fp, c.drift.n)}</div><div class="s">${c.drift.fp} of ${c.drift.n}; with drift the test assumes exchangeable dates (known limitation)</div></div>
    <div class="kpi"><div class="l">Other positions passing</div><div class="v">${c.oth}</div><div class="s">no plan, no neutral label</div></div>`;
  const vs = p.variants.filter(v => v.df != null && v.p != null), sc = $("#ssc");
  const lg = Object.keys(TNAME).map(k => `<span><i class="dot" style="background:${TCOL[k]}"></i>${TNAME[k]}</span>`).join("");
  const draw = h => volcano(h, vs, {fill: v => TCOL[v.t || ""], legend: lg}); draw(sc); sc._re = draw; decorate(sc);
  const sv = $("#scv"), cv = h => simCurve(h, p); cv(sv); sv._re = cv; decorate(sv);
  const Tp = p.truth.planted, byPos = {};
  p.variants.forEach(v => { (byPos[v.pos] = byPos[v.pos] || []).push(v); });
  const rows = Tp.map(q => { const w = (byPos[q.g] || []).filter(v => q.kind === "snv" ? v.var === q.alt : v.var[0] === "+" || v.var[0] === "-"); return {q, v: w[0]}; });
  $("#ptab").innerHTML = "<thead><tr><th>Position</th><th>Type</th><th>Planted change</th><th>Gene / effect</th><th class=\"num\">β (‰/day)</th><th class=\"num\">p</th><th class=\"num\">Observed Δf</th><th>Result</th></tr></thead><tbody>" +
    rows.map(({q, v}) => { const ok = v && passAt(v, T.a, T.d) && (q.kind !== "snv" || v.df > 0);
      return `<tr><td>${esc(q.c)}:${q.cp}</td><td>${esc(q.kind)}</td><td>${q.df != null ? "Δf ≈ " + fmt(q.df) : "–"}</td><td>${v ? esc((v.gene || "non-coding") + " " + v.aa) : "–"}</td><td class="num">${v ? fmt(v.beta * 1000, 2) : "–"}</td><td class="num">${v ? fp(v.p) : "–"}</td><td class="num">${v ? fmt(v.df) : "–"}</td>
      <td>${!v ? '<span class="muted">not evaluated</span>' : ok ? '<span class="ok">detected</span>' : '<span class="bad">not detected at these thresholds</span>'}</td></tr>`; }).join("") + "</tbody>";
}
function simCurve(host, p) {
  const T = thr(), W = host.clientWidth || 700, H = 240 * HSCALE, m = {l: 46, r: 14, t: 12, b: 36};
  const svg = el("svg", {viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Sensitivity and false positives by p threshold"});
  const lo = Math.log10(PMIN), hi = Math.log10(0.5), x = scale(lo, hi, m.l, W - m.r), y = scale(0, 1, H - m.b, m.t);
  [0, .25, .5, .75, 1].forEach(t => { el("line", {x1: m.l, x2: W - m.r, y1: y(t), y2: y(t), stroke: "var(--grid)"}, svg); el("text", {x: m.l - 6, y: y(t) + 4, "text-anchor": "end"}, svg).textContent = Math.round(t * 100) + " %"; });
  [PMIN, 0.001, 0.01, 0.05, 0.2].filter(a => a >= PMIN).forEach(a => { el("text", {x: x(Math.log10(a)), y: H - m.b + 15, "text-anchor": "middle"}, svg).textContent = +a.toPrecision(2); });
  el("text", {x: (m.l + W - m.r) / 2, y: H - 3, "text-anchor": "middle"}, svg).textContent = "p threshold (logarithmic scale); y = fraction of the class that passes it";
  const pts = []; for (let k = 0; k <= 40; k++) { const a = Math.pow(10, lo + (hi - lo) * k / 40); pts.push([a, simCounts(p, a, T.d)]); }
  const line = (f, col, dash) => el("polyline", {points: pts.map(q => `${x(Math.log10(q[0]))},${y(f(q[1]))}`).join(" "), fill: "none", stroke: col, "stroke-width": 2.2, "stroke-dasharray": dash || null}, svg);
  line(c => c.nPl ? c.det / c.nPl : 0, TCOL.P); line(c => c.iid.n ? c.iid.fp / c.iid.n : 0, TCOL["N:iid"], "7 3"); line(c => c.drift.n ? c.drift.fp / c.drift.n : 0, TCOL["N:drift"], "2 3");
  el("line", {x1: x(Math.log10(Math.max(T.a, PMIN))), x2: x(Math.log10(Math.max(T.a, PMIN))), y1: m.t, y2: H - m.b, stroke: "var(--text2)", "stroke-dasharray": "5 4"}, svg);
  const cur = el("line", {y1: m.t, y2: H - m.b, stroke: "var(--acc)", opacity: 0}, svg);
  const ov = el("rect", {x: m.l, y: m.t, width: W - m.l - m.r, height: H - m.t - m.b, fill: "transparent"}, svg);
  ov.addEventListener("mousemove", ev => { const r = svg.getBoundingClientRect(), vx = svg.viewBox.baseVal.x + (ev.clientX - r.left) / r.width * svg.viewBox.baseVal.width;
    const a = Math.pow(10, lo + (hi - lo) * Math.max(0, Math.min(1, (vx - m.l) / (W - m.l - m.r)))), c = simCounts(p, a, T.d);
    cur.setAttribute("x1", x(Math.log10(a))); cur.setAttribute("x2", x(Math.log10(a))); cur.setAttribute("opacity", .8);
    showTip(ev, `<b>p ≤ ${a < 0.001 ? a.toExponential(1) : a.toFixed(3)}</b>sensitivity ${pct(c.det, c.nPl)} (${c.det}/${c.nPl})<br>false positives, noise ${pct(c.iid.fp, c.iid.n)}<br>false positives, drift ${c.drift.n ? pct(c.drift.fp, c.drift.n) : "–"}`); });
  ov.addEventListener("mouseleave", () => { cur.setAttribute("opacity", 0); hideTip(); });
  host.replaceChildren(svg);
  const lg = document.createElement("div"); lg.className = "legend";
  lg.innerHTML = `<span><i class="dot" style="background:${TCOL.P}"></i>planted detected (solid)</span><span><i class="dot" style="background:${TCOL["N:iid"]}"></i>noise passing (long dashes)</span><span><i class="dot" style="background:${TCOL["N:drift"]}"></i>drift passing (dots)</span>`; host.appendChild(lg);
}

/* ───────── enlarge, zoom and export ───────── */
function decorate(host) {
  host.classList.add("zh");
  const old = host.querySelector(":scope > .zb"); if (old) old.remove();
  if (!host.querySelector("svg")) return;
  const b = document.createElement("div"); b.className = "zb";
  b.innerHTML = '<button type="button" title="Open full screen (wheel = zoom, drag = pan)">Enlarge</button><button type="button" data-f="svg" title="Download the figure as SVG (vector)">SVG</button><button type="button" data-f="png" title="Download the figure as PNG (high resolution)">PNG</button>';
  b.querySelector("button:not([data-f])").onclick = () => openZoom(host);
  b.querySelectorAll("button[data-f]").forEach(x => x.onclick = () => downloadFigure(host, x.dataset.f));
  host.appendChild(b);
}
function svgForExport(svg) {
  const cs = getComputedStyle(document.documentElement), c = svg.cloneNode(true), vb = svg.viewBox.baseVal;
  const sub = t => t.replace(/var\((--[\w-]+)\)/g, (_, n) => cs.getPropertyValue(n).trim() || "#000");
  [c, ...c.querySelectorAll("*")].forEach(n => ["fill", "stroke", "style"].forEach(a => { const v = n.getAttribute(a); if (v && v.includes("var(")) n.setAttribute(a, sub(v)); }));
  c.setAttribute("xmlns", NS); c.setAttribute("width", vb.width); c.setAttribute("height", vb.height); c.removeAttribute("style");
  const sty = document.createElementNS(NS, "style"); sty.textContent = `text{fill:${cs.getPropertyValue("--text2").trim()};font:11px system-ui,-apple-system,"Segoe UI",Helvetica,Arial,sans-serif}`;
  const bg = document.createElementNS(NS, "rect"); [["x", vb.x], ["y", vb.y], ["width", vb.width], ["height", vb.height], ["fill", cs.getPropertyValue("--surface").trim()]].forEach(([k, v]) => bg.setAttribute(k, v));
  c.insertBefore(bg, c.firstChild); c.insertBefore(sty, c.firstChild);
  return c;
}
function figureCanvas(host, k = 2) {
  const svg = host.querySelector("svg"), c = svgForExport(svg), vb = svg.viewBox.baseVal, xml = new XMLSerializer().serializeToString(c);
  return new Promise((ok, no) => { const img = new Image(), url = URL.createObjectURL(new Blob([xml], {type: "image/svg+xml;charset=utf-8"}));
    img.onload = () => { const cv = document.createElement("canvas"); cv.width = Math.round(vb.width * k); cv.height = Math.round(vb.height * k);
      const x = cv.getContext("2d"); x.drawImage(img, 0, 0, cv.width, cv.height); URL.revokeObjectURL(url); ok(cv); };
    img.onerror = () => { URL.revokeObjectURL(url); no(new Error("the figure could not be drawn")); }; img.src = url; });
}
function saveBlob(blob, name) { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); }
async function downloadFigure(host, kind) {
  const name = "srasel_" + (host.id || "figure") + "_" + new Date().toISOString().slice(0, 10);
  if (kind === "svg") { saveBlob(new Blob([new XMLSerializer().serializeToString(svgForExport(host.querySelector("svg")))], {type: "image/svg+xml"}), name + ".svg"); return; }
  const cv = await figureCanvas(host); cv.toBlob(b => saveBlob(b, name + ".png"), "image/png");
}
let zsvg = null;
function panZoom(svg) {
  const b = svg.viewBox.baseVal, V0 = {x: b.x, y: b.y, w: b.width, h: b.height}; let V = {...V0}, moved = false, drag = null;
  const set = () => svg.setAttribute("viewBox", `${V.x} ${V.y} ${V.w} ${V.h}`);
  const clamp = () => { V.x = Math.max(V0.x, Math.min(V0.x + V0.w - V.w, V.x)); V.y = Math.max(V0.y, Math.min(V0.y + V0.h - V.h, V.y)); };
  const zoom = (k, px, py) => { const nw = Math.min(V0.w, Math.max(V0.w / 60, V.w * k)), kk = nw / V.w;
    px = px == null ? V.x + V.w / 2 : px; py = py == null ? V.y + V.h / 2 : py;
    V = {x: px - (px - V.x) * kk, y: py - (py - V.y) * kk, w: nw, h: V.h * kk}; clamp(); set(); };
  const pt = ev => { const r = svg.getBoundingClientRect(); return [V.x + (ev.clientX - r.left) / r.width * V.w, V.y + (ev.clientY - r.top) / r.height * V.h]; };
  svg.addEventListener("wheel", ev => { ev.preventDefault(); const [px, py] = pt(ev); zoom(ev.deltaY < 0 ? 0.8 : 1.25, px, py); }, {passive: false});
  svg.addEventListener("mousedown", ev => { drag = {x: ev.clientX, y: ev.clientY, V: {...V}}; moved = false; });
  addEventListener("mousemove", ev => { if (!drag) return; const r = svg.getBoundingClientRect(), dx = ev.clientX - drag.x, dy = ev.clientY - drag.y;
    if (Math.abs(dx) + Math.abs(dy) > 4) { moved = true; hideTip(); }
    if (moved) { V.x = drag.V.x - dx / r.width * V.w; V.y = drag.V.y - dy / r.height * V.h; clamp(); set(); } });
  addEventListener("mouseup", () => { drag = null; });
  svg.addEventListener("click", ev => { if (moved) { ev.stopPropagation(); ev.preventDefault(); moved = false; } }, true);
  svg.addEventListener("dblclick", () => { V = {...V0}; set(); });
  svg._zoom = zoom; svg._reset = () => { V = {...V0}; set(); };
}
function openZoom(host) {
  const zm = $("#zm"), body = $("#zbody"); hideTip();
  const svg0 = host.querySelector("svg"), vb = svg0.viewBox.baseVal, sec = host.closest(".panel"), h2 = sec && sec.querySelector("h2");
  $("#zt").textContent = h2 ? h2.textContent : (svg0.getAttribute("aria-label") || "");
  zm.style.display = "block"; body.replaceChildren();
  const h = document.createElement("div"); h._inZ = true; body.appendChild(h);
  HSCALE = Math.max(1, Math.min(3, (body.clientHeight - 24) / (vb.height || 300)));
  try { h._re = host._re; host._re(h); } finally { HSCALE = 1; }
  const svg = h.querySelector("svg"); if (svg) { panZoom(svg); zsvg = svg; }
  document.body.style.overflow = "hidden"; $("#zx").focus();
}
function closeZoom() { const zm = $("#zm"); if (zm.style.display !== "none") { zm.style.display = "none"; $("#zbody").replaceChildren(); zsvg = null; document.body.style.overflow = ""; hideTip(); } }
$("#zx").onclick = closeZoom; $("#zin").onclick = () => zsvg && zsvg._zoom(0.7); $("#zout").onclick = () => zsvg && zsvg._zoom(1.4); $("#zrs").onclick = () => zsvg && zsvg._reset();
$("#zm").addEventListener("mousedown", e => { if (e.target === $("#zm")) closeZoom(); });
addEventListener("keydown", e => { if (e.key !== "Escape") return; if (htip.style.display === "block") hideHelp(); else if ($("#zm").style.display === "block") closeZoom(); else closeVar(); });

/* ───────── startup ───────── */
$("#h1").textContent = DATA.title; $("#sub").textContent = DATA.subtitle || "";
$("#theme").onclick = () => { const r = document.documentElement; r.dataset.theme = getComputedStyle(r).colorScheme === "dark" ? "light" : "dark"; };
$("#helpdefs").innerHTML = Object.entries(HELP).map(([k, v]) => `<span id="h-${k}">${esc(v[1])}</span>`).join("");
document.querySelectorAll(".hi[data-h]:not([aria-describedby])").forEach(b => b.setAttribute("aria-describedby", "h-" + b.dataset.h));
const htip = $("#htip");
function showHelp(b) {
  const r = b.getBoundingClientRect(); htip.textContent = HELP[b.dataset.h][1]; htip.style.display = "block"; b.setAttribute("aria-expanded", "true");
  const w = htip.offsetWidth, h = htip.offsetHeight; let y = r.bottom + 6; if (y + h > innerHeight - 8) y = r.top - h - 6;
  htip.style.left = Math.min(Math.max(8, r.left + r.width / 2 - w / 2), Math.max(8, innerWidth - w - 8)) + "px"; htip.style.top = Math.max(8, y) + "px";
}
function hideHelp() { htip.style.display = "none"; document.querySelectorAll(".hi[aria-expanded]").forEach(b => b.removeAttribute("aria-expanded")); }
const hiOf = ev => ev.target.closest && ev.target.closest(".hi[data-h]");
document.addEventListener("mouseover", ev => { const b = hiOf(ev); if (b) showHelp(b); });
document.addEventListener("mouseout", ev => { const b = hiOf(ev); if (b && document.activeElement !== b) hideHelp(); });
document.addEventListener("focusin", ev => { const b = hiOf(ev); if (b) showHelp(b); else hideHelp(); });
document.addEventListener("focusout", ev => { if (hiOf(ev)) hideHelp(); });
document.addEventListener("click", ev => { const b = hiOf(ev); if (b) showHelp(b); else hideHelp(); });
addEventListener("scroll", hideHelp, true);
(function () {
  const h = parseHash();
  if (h.theme) applyHost({theme: h.theme}); if (h.embed != null) applyHost({embed: h.embed});
  const t = tabOf(h); if (t) st.tab = t;
  if (h.p === "all" ? DATA.groups.length === 1 : (/^g\d+$/.test(h.p || "") ? DATA.patients.some(p => p.g === +h.p.slice(1)) : false)) st.cur = h.p; else if (h.p && /^\d+$/.test(h.p) && DATA.patients[+h.p]) st.cur = +h.p;
  if (h.a > 0 && h.a <= 1) st.alpha = +h.a; if (h.d >= 0 && h.d <= 1 && h.d !== "") st.delta = +h.d;
  if (h.g) st.gene = h.g; if (["up", "down"].includes(h.dir)) st.dir = h.dir;
  window._initV = h.v || null;
})();
let rz; addEventListener("resize", () => { clearTimeout(rz); rz = setTimeout(() => render(), 200); });
buildNav(); buildBar(); render();
if (window._initV) { const q = window._initV, j = q.indexOf("."), pp = DATA.patients[+q.slice(0, j)], vv = pp && pp.variants.find(x => key(x) === q.slice(j + 1)); if (vv) pickVar(vv); }
notify("ready");
</script>
</body>
</html>
'''

#!/usr/bin/env python3



REPORT_BASES = "ACGT"
CODE_RE = r"^(-?\d+)/(\d+)/A(\d+)C(\d+)T(\d+)G(\d+)N(\d+)/"
N_BINS = 60


def num(x, nd=6):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return None if not np.isfinite(v) else round(v, nd)


def lst(s):
    return json.loads(s) if isinstance(s, str) and s.startswith("[") else []


# ───────────────────────── reference ─────────────────────────
def load_ref(ref_dir: Path):
    cpath, fpath = ref_dir / "contigs.tsv", ref_dir / "features.tsv"
    for p in (cpath, fpath):
        if not p.is_file():
            fail(f"Missing file {p}", "the report needs the prepared reference (step 0).",
                    "Run: srasel prepare-reference --refs <accession(s)> --email <email> --outdir " + str(ref_dir))
    contigs = read_contigs(cpath)
    feats = pd.read_csv(fpath, sep="\t", keep_default_na=False)
    cds = feats[feats["type"] == "CDS"]
    genes, used = [], set()
    for _, r in cds.iterrows():
        nm = r["name"] or r["short_name"] or r["product"]
        if nm in used and r["product"]:       # different CDSs with the same gene (e.g. ORF1a / ORF1ab): use the product
            nm = r["product"]
        if not nm:
            continue
        used.add(nm)
        genes.append(dict(name=str(nm), gstart=int(r["global_start"]), gend=int(r["global_end"]),
                          contig=r["contig"], strand=r["strand"], product=str(r["product"])))
    total = contigs[-1]["offset"] + contigs[-1]["length"]
    mp = []                      # mature proteins (mat_peptide) of the reference: only to DISPLAY them (not used in any calculation)
    cm_path = ref_dir / "cds_model.tsv"
    if cm_path.is_file():
        cm = pd.read_csv(cm_path, sep="\t", keep_default_na=False)
        gene_of = dict(zip(cm["cds_id"], cm["gene"]))
        for _, r in feats[feats["type"] == "mat_peptide"].iterrows():
            g, a, b = gene_of.get(r["parent_cds"]), str(r["aa_start"]).strip(), str(r["aa_end"]).strip()
            if g and a.isdigit() and b.isdigit():
                prod, short = str(r["product"]), str(r["short_name"])
                mp.append(dict(c=r["contig"], g=str(g), n=prod if (not short or short.lower() == prod.lower()) else f"{prod} ({short})", a=int(a), b=int(b),
                               gs=int(r["global_start"]) if str(r["global_start"]).strip().isdigit() else None, ge=int(r["global_end"]) if str(r["global_end"]).strip().isdigit() else None))
    return dict(contigs=[dict(name=c["contig"], offset=int(c["offset"]), length=int(c["length"]),
                              topology=c.get("topology", ""), description=c.get("description", "")) for c in contigs],
                genes=genes, total=int(total), n_cds=len(genes), mp=mp), contigs


# ───────────────────────── position×time matrices ─────────────────────────
def read_matrix(path: Path, total: int, min_depth: int, min_maf: float):
    """→ (sorted tokens, days, F[s,L,4] filtered frequencies, ok[s,L], mean depth per sample)."""
    m = pd.read_csv(path, sep="\t", dtype=str, keep_default_na=False)
    pos = m.iloc[:, 0].astype(int).to_numpy()
    toks = list(m.columns[1:])
    S = len(toks)
    cnt = np.zeros((S, total, 4), np.float32)
    days, depth_mean = [], []
    for s, t in enumerate(toks):
        e = m[t].str.extract(CODE_RE)
        ok = e[0].notna().to_numpy()
        days.append(int(e[0][ok].iloc[0]) if ok.any() else 0)
        idx = pos[ok] - 1
        c = e.loc[ok, [2, 3, 5, 4]].astype(np.float32).to_numpy()          # A, C, G, T (the code stores A C T G)
        cnt[s, idx, :] = c
        depth_mean.append(float(e.loc[ok, 1].astype(float).mean()) if ok.any() else 0.0)
    order = sorted(range(S), key=lambda i: (days[i], toks[i]))
    toks = [toks[i] for i in order]; days = [days[i] for i in order]
    depth_mean = [depth_mean[i] for i in order]; cnt = cnt[order]
    tot = cnt.sum(2)
    ok = tot >= min_depth
    with np.errstate(invalid="ignore", divide="ignore"):
        f = cnt / tot[..., None]
        f[f < min_maf] = 0
        s2 = f.sum(2)
        f = f / s2[..., None]
    ok &= np.isfinite(s2) & (s2 > 0)
    f = np.nan_to_num(f)
    return toks, days, f.astype(np.float32), ok, depth_mean


def diversity_tables(F, ok, ref):
    S, L, _ = F.shape
    H = 1.0 - (F ** 2).sum(2)
    H[~ok] = np.nan
    mean_h = [num(np.nanmean(H[s]), 6) if ok[s].any() else None for s in range(S)]
    # divergence between all pairs
    div = [[None] * S for _ in range(S)]
    npos = [[0] * S for _ in range(S)]
    for i in range(S):
        for j in range(i, S):
            both = ok[i] & ok[j]
            n = int(both.sum())
            npos[i][j] = npos[j][i] = n
            if n:
                d = float(0.5 * np.abs(F[i][both] - F[j][both]).sum(1).mean())
                div[i][j] = div[j][i] = round(d, 6)
    # windows along the genome (per contig)
    W = max(100, int(round(sum(c["length"] for c in ref["contigs"]) / N_BINS)))
    bins = []
    for c in ref["contigs"]:
        nb = max(1, int(round(c["length"] / W)))
        edges = np.linspace(0, c["length"], nb + 1).round().astype(int)
        for b in range(nb):
            bins.append(dict(contig=c["name"], start=int(edges[b]) + 1, end=int(edges[b + 1]),
                             g0=c["offset"] + int(edges[b]), g1=c["offset"] + int(edges[b + 1])))
    Hb = []
    for s in range(S):
        row = []
        for b in bins:
            seg_ok = ok[s, b["g0"]:b["g1"]]
            row.append(num(np.nanmean(H[s, b["g0"]:b["g1"]]), 6) if seg_ok.mean() >= 0.3 else None)
        Hb.append(row)
    return mean_h, div, npos, bins, Hb



# ───────────────────────── known ground truth (simulations) ─────────────────────────
def load_truth(pref, ref, variants, truth_path, neutral_path):
    """Label each variant with what is known about it in a SIMULATION.
    t = P (planted allele, should RISE) · M (its mirror allele, should FALL) · I (planted indel) · N:iid / N:drift (no selection)
    Returns (list of planted variants, number of neutral positions per class)."""
    offs = {c["name"]: c["offset"] for c in ref["contigs"]}
    planted = []
    if truth_path:
        pl = pd.read_csv(truth_path, sep="\t", keep_default_na=False, dtype=str)
        for _, r in pl.iterrows():
            if "patient" in pl.columns and r["patient"] not in ("", pref):
                continue
            planted.append(dict(g=offs.get(r["contig"], 0) + int(r["pos"]), c=r["contig"], cp=int(r["pos"]), ref=r["ref"], alt=r["alt"],
                                kind=r.get("kind", "snv") or "snv", df=num(r.get("delta_f")), slope=num(r.get("slope"))))
    neutral = {}
    if neutral_path:
        nt = pd.read_csv(neutral_path, sep="\t", keep_default_na=False, dtype=str)
        for _, r in nt.iterrows():
            if "patient" in nt.columns and r["patient"] not in ("", pref):
                continue
            neutral[offs.get(r["contig"], 0) + int(r["pos"])] = "drift" if r["class"].startswith("drift") or r["class"].startswith("deriva") else r["class"]
    byg = {}
    for q in planted:
        byg.setdefault(q["g"], []).append(q)
    for v in variants:
        t = ""
        for q in byg.get(v["pos"], []):
            if q["kind"] == "snv":
                t = "P" if v["var"] == q["alt"] else "M" if v["var"] == q["ref"] else t
                if t == "P":
                    v["td"] = q["df"]
            elif v["var"][:1] in "+-":
                t = "I"
        if not t and v["pos"] in neutral:
            t = "N:" + neutral[v["pos"]]
        v["t"] = t
    cnt = {}
    for g_, c_ in neutral.items():
        cnt[c_] = cnt.get(c_, 0) + 1
    return planted, cnt

# ───────────────────────── patient ─────────────────────────
def load_canon(canon_dir: Path):
    """coord_map.tsv / aa_map.tsv from srasel transfer-annotation: own position and amino acid → canonical reference (e.g. HXB2)."""
    cm = pd.read_csv(canon_dir / "coord_map.tsv", sep="\t", keep_default_na=False)
    am = pd.read_csv(canon_dir / "aa_map.tsv", sep="\t", keep_default_na=False)
    return ({(r.contig, int(r.pos)): int(r.canon_pos) for r in cm.itertuples()},
            {(r.gene, int(r.aa_idx)): int(r.canon_aa_idx) for r in am.itertuples()})


def load_patient(proc: Path, pref: str, ref, args, notes, canon=None):
    sel_dir, mat_dir = proc / "06_selection_analysis", proc / "04_position_time_matrices"
    rd = lambda p: pd.read_csv(p, sep="\t", keep_default_na=False)
    vs = rd(sel_dir / f"{pref}_variant_stats.tsv")
    sel = rd(sel_dir / f"{pref}_selected_ranked.tsv") if (sel_dir / f"{pref}_selected_ranked.tsv").is_file() else vs.iloc[0:0]
    variants = []
    for _, r in vs.iterrows():
        variants.append(dict(
            pos=int(r["pos"]), c=r.get("contig", ""), cp=num(r.get("contig_pos")), var=str(r["var"]),
            gene=str(r.get("aa_gene") or r.get("gene") or ""), aa=str(r.get("aa_change", "")), ai=num(r.get("aa_idx")),
            of=str(r.get("other_frames", "")), beta=num(r["beta"], 8), p=num(r["pval"], 6),
            df=num(r["delta_f"], 5), tag=str(r["tag"]), depth=num(r.get("depth"), 1),
            days=lst(r["day"]), k=lst(r["k"]), n=lst(r["n"])))
    for v in variants:                                    # mature protein (visualization only): name, range in the ORF and position within it
        if ref.get("mp") and v["ai"]:
            hit = [[m["n"], m["a"], m["b"], int(v["ai"]) - m["a"] + 1] for m in ref["mp"]
                   if m["g"] == v["gene"] and m["a"] <= int(v["ai"]) <= m["b"] and (not v["c"] or m["c"] == v["c"])]
            if hit:
                v["mp"] = hit
    for v in variants:                                    # canonical numbering (to compare analyses with a different reference)
        if canon:
            v["cn"] = canon[0].get((v["c"], int(v["cp"] if v["cp"] is not None else 0)), 0)
            v["ca"] = canon[1].get((v["gene"], int(v["ai"])), 0) if v["ai"] else 0
        else:
            v["cn"], v["ca"] = v["pos"], int(v["ai"] or 0)
    truth = None
    if args.truth or args.neutral:
        planted, ncnt = load_truth(pref, ref, variants, args.truth, args.neutral)
        truth = dict(planted=planted, neutral=ncnt)
    out = dict(key=pref, variants=variants, n_tested=len(vs), n_sel=len(sel), truth=truth,
               n_pos=int((sel["tag"] == "pos").sum()) if len(sel) else 0,
               n_neg=int((sel["tag"] == "neg").sum()) if len(sel) else 0)
    # sites added by hand (literature): read from long.tsv
    sites = []
    lp = sel_dir / f"{pref}_long.tsv"
    for pos, var, why in notes.get("sites", []):
        if not lp.is_file():
            break
        lg = pd.read_csv(lp, sep="\t")
        g = lg[(lg.pos == pos) & (lg["var"] == var)]
        dn = lg[lg.pos == pos][["day", "n"]].drop_duplicates("day").sort_values("day")
        g = dn.merge(g[["day", "k"]], on="day", how="left").fillna({"k": 0})
        sites.append(dict(pos=int(pos), var=var, why=why, days=g["day"].astype(int).tolist(),
                          k=g["k"].astype(int).tolist(), n=g["n"].astype(int).tolist()))
    out["sites"] = sites
    mpath = mat_dir / f"{pref}.tsv"
    if mpath.is_file():
        toks, days, F, ok, dmean = read_matrix(mpath, ref["total"], args.min_depth, args.min_maf)
        mean_h, div, npos, bins, Hb = diversity_tables(F, ok, ref)
        out["samples"] = [dict(id=t, day=d, depth=round(dm, 1), h=h, ncov=int(ok[i].sum()))
                          for i, (t, d, dm, h) in enumerate(zip(toks, days, dmean, mean_h))]
        out["div"], out["npos"], out["bins"], out["hbin"] = div, npos, bins, Hb
    else:
        disclaimer(f"Missing {mpath}: depth and heat maps of {pref} are omitted.")
        out["samples"] = []
    for k in ("title", "subtitle", "name", "checks", "cards"):
        if k in notes:
            out[k] = notes[k]
    return out


_HOME_PATH = re.compile(r"(?:file://)?/(?:Users|home|Volumes|private|mnt)/[^\"'<>\n\r;,()]*")
_ABS_PATH = re.compile(r"(?<![\w./:])/(?:[^\s\"'<>/:,;()]+/){2,}[^\s\"'<>/:,;()]+")


def _short_paths(o):
    """Absolute paths → “…/second-to-last/last” (the report can be shared without revealing private folders)."""
    if isinstance(o, str):
        o = _HOME_PATH.sub(lambda m: "…/" + "/".join(m.group(0).rstrip().split("/")[-2:]), o)
        return _ABS_PATH.sub(lambda m: "…/" + "/".join(m.group(0).split("/")[-2:]), o)
    if isinstance(o, list):
        return [_short_paths(x) for x in o]
    if isinstance(o, dict):
        return {k: _short_paths(v) for k, v in o.items()}
    return o


def _json_for_script(data):
    """JSON to embed inside an HTML <script>. [validation 2026-11-11, E2] A gene/product name containing "</script>" or "<!--" would break out of the
    script (it ran in Chrome). "<\\/" and "<\\!--" are the same string for JavaScript, so the report behaves identically."""
    return json.dumps(data, separators=(",", ":"), allow_nan=False).replace("</", "<\\/").replace("<!--", "<\\!--")


def _report_command(args):
    """Command line shown in the report (About tab): each argument is shortened on its own, so that the options between two paths are not lost."""
    return "srasel report " + " ".join((a if args.full_paths else _short_paths(a)) if not re.search(r"\s", a) else repr(a) for a in sys.argv[1:])


def main_report():
    ap = argparse.ArgumentParser(description=SRASEL_REPORT_DOC, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--ref-dir", type=Path, help="folder from srasel prepare-reference")
    ap.add_argument("--config", type=Path, default=None,
                    help="JSON with SEVERAL datasets and references in a single report: {title,subtitle,notes,groups:[{name,ref_dir,series:[{processing,"
                         "key,name,id,mode,canon,notes_key,ref_note}]}],comparisons:[{title,text,series:[id…],labels:[…]}]}")
    ap.add_argument("--processing", nargs="+", type=Path,
                    help="folder(s) with 04_position_time_matrices/ and 06_selection_analysis/")
    ap.add_argument("-o", "--out", default="srasel_report.html", type=Path)
    ap.add_argument("--title", default="SRASel 2.0 · report")
    ap.add_argument("--subtitle", default="")
    ap.add_argument("--notes", type=Path, default=None,
                    help="optional JSON {prefix: {name,title,subtitle,checks:[[ok|no|info,title,text]],"
                         "cards:[[title,html]],sites:[[pos,allele,reason]]}}")
    ap.add_argument("--truth", type=Path, default=None,
                    help="plan.tsv of a SIMULATION (contig,pos,ref,alt[,kind,patient,delta_f]): adds the “Simulation” tab "
                         "with sensitivity and false positives against the known ground truth")
    ap.add_argument("--neutral", type=Path, default=None,
                    help="neutral.tsv of the simulation (patient,contig,pos,alt,class): positions WITHOUT selection (class iid or drift)")
    ap.add_argument("--min-depth", type=int, default=100, help="minimum depth per position (default 100)")
    ap.add_argument("--min-maf", type=float, default=0.01,
                    help="alleles below this frequency are treated as error (default 0.01)")
    ap.add_argument("--freq-delta", type=float, default=0.03, help="initial |Δf| threshold (default 0.03)")
    ap.add_argument("--full-paths", action="store_true",
                    help="keep absolute paths in the report (by default they are shortened to the last two folders so it can be shared)")
    ap.add_argument("--p", type=float, default=0.05, help="initial p threshold (default 0.05)")
    ap.add_argument("--nperm", type=int, default=2000,
                    help="permutations used in SRASel (sets the minimum p = 1/nperm) (default 2000)")
    args = ap.parse_args()

    if args.config:                                       # several references / datasets in a single report
        cfg = json.loads(args.config.read_text())
        args.title = cfg.get("title", args.title); args.subtitle = cfg.get("subtitle", args.subtitle)
        notes_all = json.loads(Path(cfg["notes"]).read_text()) if cfg.get("notes") else {}
    else:
        if not args.ref_dir or not args.processing:
            fail("--ref-dir and --processing (or --config) are missing", "it is not known which reference or which results to read.",
                    "Use --ref-dir <ref> --processing <folder(s)>  or  --config report.json")
        cfg = dict(groups=[dict(name=args.title, ref_dir=str(args.ref_dir), series=[dict(processing=str(x)) for x in args.processing])])
        notes_all = json.loads(args.notes.read_text()) if args.notes else {}
    refs, groups, patients = [], [], []
    for gi, grp in enumerate(cfg["groups"]):
        ref, _ = load_ref(Path(grp["ref_dir"]))
        refs.append(ref); groups.append(dict(name=grp["name"], note=grp.get("note", ""), ref_dir=grp["ref_dir"]))
        for sp in grp["series"]:
            proc = Path(sp["processing"]); sel_dir = proc / "06_selection_analysis"
            files = sorted(sel_dir.glob("*_variant_stats.tsv")) if sel_dir.is_dir() else []
            if sp.get("key"):
                files = [f for f in files if f.name == f"{sp['key']}_variant_stats.tsv"]
            if not files:
                fail(f"No *_variant_stats.tsv in {sel_dir}", "srasel selection (step 6) has not been run or the path is different.",
                        "Run srasel selection and pass --processing <folder containing 06_selection_analysis>.")
            canon = load_canon(Path(sp["canon"])) if sp.get("canon") else None
            for f in files:
                pref = f.name[:-len("_variant_stats.tsv")]
                nt = dict(notes_all.get(sp.get("notes_key", pref), {}))
                for k in ("name", "title", "subtitle"):
                    if sp.get(k):
                        nt[k] = sp[k]
                pt = load_patient(proc, pref, ref, args, nt, canon)
                pt["g"] = gi; pt["mode"] = sp.get("mode", ""); pt["sid"] = sp.get("id", pref)
                pt["ref_note"] = sp.get("ref_note", "")
                patients.append(pt)
                print(f"✔  {groups[-1]['name']} · {pt.get('name', pref)}: {pt['n_tested']} variants with a statistic, {pt['n_sel']} tagged")
    compare = cfg.get("comparisons", [])
    for c in compare:                                     # series names → indices
        ids = {p["sid"]: i for i, p in enumerate(patients)}
        c["series"] = [ids[x] for x in c["series"]]
    data = dict(refs=refs, groups=groups, patients=patients, compare=compare, title=args.title, subtitle=args.subtitle,
                defaults=dict(p=args.p, df=args.freq_delta, nperm=args.nperm),
                params=dict(min_depth=args.min_depth, min_maf=args.min_maf),
                cmd=_report_command(args),
                processing=[sp["processing"] for g in cfg["groups"] for sp in g["series"]], ref_dir=", ".join(g["ref_dir"] for g in cfg["groups"]))
    import Bio
    data["prov"] = dict(srasel="2.0", generated=datetime.now().strftime("%Y-%m-%d"), python=sys.version.split()[0], numpy=np.__version__,
                        pandas=pd.__version__, biopython=Bio.__version__)
    if not args.full_paths:
        cmd_shown = data["cmd"]                           # already shortened argument by argument
        data = _short_paths(data)
        data["cmd"] = cmd_shown
    tpl = REPORT_TEMPLATE
    payload = _json_for_script(data)
    html = tpl.replace("/*__DATA__*/null", payload)
    args.out.write_text(html)
    print(f"✔  {args.out} ({len(html) // 1024} KB)")


# ════════════════════════════════════════════════════════════════════════════════════════════════════
# Coordination of the complete pipeline from BAM
# ════════════════════════════════════════════════════════════════════════════════════════════════════
SRASEL_RUN_DOC = r"""
srasel run – SRASel 2.0 from start to finish from your BAM files, on your computer
────────────────────────────────────────────────────────────────────────────
You provide the BAM files (one per sample) and the dates; the program finds or uses the reference, CHECKS that your BAM files fall where
they should in it and, only then, counts, annotates and analyzes. It performs steps 0 to 7 (reference → counting per
position → integrity → matrices → annotation → SRASel → HTML report).

  1) The simplest: a table with one row per sample (columns: bam, patient, date; tab-separated)

        srasel run --samples samples.tsv --virus "SARS-CoV-2" --email you@email --out results

     samples.tsv:             bam                     patient    date
                              /data/p1_day0.bam       P1         23/03/2020
                              /data/p1_day7.bam       P1         30/03/2020
     (date: dd/mm/yyyy, dd/mm/yy or yyyy-mm-dd; two BAM files of the same patient and day = replicates)

  2) Without a table (most convenient with many samples): a folder with the BAM files and a dates file

        srasel run --bams folder_with_bams/ --dates dates.tsv --virus "…" --email you@email

     dates.tsv (tab-separated, one row per BAM):   bam_name_without_.bam   date   [patient]
                              P1-1      23/03/2020
                              P1-2      2020-03-30
                              P1-3      6.4.2020
     · The name must be that of the BAM in the folder, without “.bam” (subfolders are also searched). If it does not match, it says which ones.
     · Date in any format: 23/03/2020, 2020-03-23, 23.3.20, 23-Mar-2020, 20200323, with time… or days since the
       first sample (0, 7, 14). dd/mm versus mm/dd is decided by looking at the whole file (if there is a value >12 it is clear;
       otherwise day/month is assumed and a warning is given).
     · If each sample is SEVERAL BAM files (one per consensus fragment, as in HIVEVO), use --samples with a 4th column “fragment” (F1, F2…) and
       --fragments table.tsv (fragment, start, end in consensus coordinates, or a GenBank with “fragment” features): each fragment is counted
       with its piece of the consensus, positions are brought to the consensus and overlaps are summed.
     · The patient comes from the name (P1-3 → patient P1) or from the 3rd column; with --patient NAME if all are from the same one.
       Two BAM files of the same patient and day are treated as replicates.

How the reference is decided (in this order of priority):
  --ref ACC[,ACC…]      NCBI accession(s); one accession per segment if the virus is segmented
  --ref-file x.gb       your GenBank (own annotated reference, without internet)
  --fasta ref.fa --genes list   your sequence WITHOUT GenBank + a LIST of genes with positions and strand (TSV table or GFF3); see `srasel make-genbank -h`
  --consensus x.fa      YOUR consensus (the BAM files are aligned to it). An annotated NCBI reference is needed from which to
                        transfer the genes: --consensus-source ACC, or --virus "name" and the program picks the most similar
  --virus "name"        searches NCBI for the RefSeq references of that virus and picks the one that fits your BAM files (same number of
                        contigs and same length). If there are several possible ones it shows them and asks you to choose
  (none of the above)   uses the contig names in the header of your BAM files if they are NCBI accessions

What is checked BEFORE counting (if something fails, it stops and says what to do):
  · every contig of the BAM files exists in the reference (name, or same name without version, or --alias) and has the same length;
  · if the BAM header carries the md5 of the sequence (M5), it matches the reference;
  · rate of differences between the reads and the reference (samtools stats): a wrong reference or one with different
    numbering gives many more differences than normal in a within-host infection;
  · which contigs/segments receive reads and how many;
  · the genes of the reference are translated the same as the NCBI proteins (step 0), and every CDS transferred from a consensus
    is validated (no internal stops, identity with the NCBI protein).
  With --check-only it performs only these checks and finishes.

Programs needed in the PATH (conda install -c bioconda samtools bam-readcount minimap2) and Python with Biopython, numpy,
pandas, joblib, matplotlib, tqdm and scipy. If anything is missing, the program says so at the start.
"""

#!/usr/bin/env python3

SELF = Path(__file__).resolve()

ERR_WARN, ERR_FAIL = 0.03, 0.20       # read–reference difference rate: warning / stop
MIN_READS_CONTIG = 100                # minimum reads to say that a contig “receives reads”


def say(msg=""):
    print(msg, flush=True)


def ok(msg):
    say(f"  ✔ {msg}")


def warn(msg):
    say(f"  ⚠ {msg}")


# ───────────────────────── external utilities ─────────────────────────
def need_tools(tools):
    miss = [t for t in tools if not shutil.which(t)]
    if miss:
        fail(f"Programs missing from the PATH: {', '.join(miss)}",
                "SRASel needs samtools and bam-readcount (and minimap2 if you transfer annotation to a consensus).",
                "conda install -c bioconda samtools bam-readcount minimap2   (and run the command again)")


def run(cmd, log, **kw):
    cmd = [str(c) for c in cmd]
    log.write("$ " + " ".join(cmd) + "\n"); log.flush()
    r = subprocess.run(cmd, capture_output=True, text=True, **kw)
    if r.stderr:
        log.write(r.stderr[-2000:] + "\n")
    if r.returncode:
        fail(f"Failed: {' '.join(cmd)[:150]}", f"exit code {r.returncode}: {(r.stderr or r.stdout)[-300:].strip()}",
                f"check {log.name}")
    return r


# ───────────────────────── samples and dates ─────────────────────────
MONTHS = {m: i for i, m in enumerate("jan feb mar apr may jun jul aug sep oct nov dec".split(), 1)}
MONTHS.update(ene=1, abr=4, ago=8, dic=12)
REL_BASE = date(2000, 1, 1)          # relative days (0, 7, 14…) → fictitious dates; only the differences matter


def parse_dates(raws, where=""):
    """Dates in any format → list of date. Separators / - . or space, month in letters (23-Mar-2020), yyyymmdd and,
    if all are small integers, days since the first sample. dd/mm versus mm/dd is decided by looking at the WHOLE file:
    a value >12 in the 1st position ⇒ day first; in the 2nd ⇒ month first; if it cannot be known, day first and a warning is given."""
    toks = []
    for s in raws:
        t = re.split(r"[T ](?=\d{1,2}:\d{2})", s.strip())[0]            # removes the time (Excel: “2020-03-23 00:00:00”)
        toks.append((s, re.findall(r"[A-Za-zñÑ]+|\d+", t)))
    rel = [len(t) == 1 and t[0].isdigit() and len(t[0]) != 8 for _, t in toks]
    if any(rel):
        if not all(rel):
            fail(f"Relative days and dates are mixed ({where or 'file'})", "some rows are integers (0, 7, 14…) and others are dates.",
                    "use a single style throughout the file")
        return [REL_BASE + timedelta(days=int(t[0])) for _, t in toks]
    nums = [(int(t[0]), int(t[1])) for _, t in toks if len(t) == 3 and all(x.isdigit() for x in t) and len(t[0]) != 4]
    a12, b12 = any(a > 12 for a, _ in nums), any(b > 12 for _, b in nums)
    if a12 and b12:
        fail(f"The dates ({where or 'file'}) mix day/month and month/day", "there are values >12 in the first two positions.",
                "use the same order in all rows")
    dayfirst = not b12
    if not a12 and not b12 and any(a != b and a <= 12 and b <= 12 for a, b in nums):
        warn(f"Ambiguous dates in {where or 'the file'} (e.g. {next(s for s, t in toks if len(t) == 3 and len(t[0]) != 4)}): "
             "no value >12 clarifies the order; interpreted as DAY/MONTH/YEAR. If this is not right, write the dates as yyyy-mm-dd.")
    out = []
    for s, t in toks:
        try:
            if len(t) == 1 and len(t[0]) == 8:                                       # yyyymmdd
                y, m, d = int(t[0][:4]), int(t[0][4:6]), int(t[0][6:])
            elif len(t) == 3 and any(x.isalpha() for x in t):                        # 23-Mar-2020, Mar 23 2020
                mo = next(MONTHS[x[:3].lower()] for x in t if x.isalpha() and x[:3].lower() in MONTHS)
                n = sorted((int(x) for x in t if x.isdigit()), key=lambda v: v > 31)
                d, y = n[0], n[1]; m = mo
            elif len(t) == 3 and len(t[0]) == 4:                                     # yyyy-mm-dd
                y, m, d = int(t[0]), int(t[1]), int(t[2])
            elif len(t) == 3:
                a, b, y = int(t[0]), int(t[1]), int(t[2])
                d, m = (a, b) if dayfirst else (b, a)
            else:
                raise ValueError
            if y < 100:
                y += 2000 if y < 70 else 1900
        except (ValueError, StopIteration):
            fail(f"Cannot parse the date “{s}”" + (f" ({where})" if where else ""), "it does not match any usual format (23/03/2020, 2020-03-23, 23.3.20, 23-Mar-2020, "
                    "20200323 or days since the first sample: 0, 7, 14).", "correct it or write it as yyyy-mm-dd")
        try:                                    # [validation 2026-11-10, N13] a recognised format but an impossible day (31/04/20) gets its own message
            out.append(date(y, m, d))
        except ValueError:
            fail(f"Cannot parse the date “{s}”" + (f" ({where})" if where else ""), "it is not a valid calendar date (day or month out of range).",
                 "correct it or write it as yyyy-mm-dd")
    return out


def safe(s):
    return re.sub(r"[^A-Za-z0-9_.]+", "_", s.strip()).strip("_")


def read_dates_file(path):
    """dates.tsv: BAM name (without .bam) <TAB> date [<TAB> patient]. Also accepts a comma or ; as separator."""
    rows = []
    for ln in open(path, encoding="utf-8-sig"):
        ln = ln.rstrip("\r\n")
        if not ln.strip() or ln.lstrip().startswith("#"):
            continue
        f = ln.split("\t")
        if len(f) < 2:
            f = re.split(r"\s*[,;]\s*", ln) if re.search(r"[,;]", ln) else ln.split(None, 2)
        if len(f) < 2:
            fail(f"Cannot parse this line of {path}: “{ln[:60]}”", "expected BAM name, tab, and date.", "fix it")
        rows.append([x.strip() for x in f])
    # optional header (e.g., “bam  date”): the first row if its 2nd column has no digit
    if rows and not re.search(r"\d", rows[0][1]):
        rows = rows[1:]
    return rows


def stem_of(name):
    n = Path(name).name
    return n[:-4] if n.lower().endswith(".bam") else n


def load_samples(a):
    """→ list of dict(sid, bam, patient, date) with ids <patient>-<n>[a|b…].
    Two forms: --samples table (BAM with path, patient, date) or --bams folder(s) + --dates (BAM name, date[, patient])."""
    rows = []
    if a.samples:
        raw = []
        with open(a.samples, newline="", encoding="utf-8-sig") as f:
            # [validation 2026-11-10, N2] only blank lines, comments and a header (first row whose date column has no digit) are skipped;
            # any other row that cannot be used stops the run (before, rows without a usable date were dropped silently)
            for i, r in enumerate(csv.reader(f, delimiter="\t"), 1):
                if not any(x.strip() for x in r) or r[0].lstrip().startswith("#"):
                    continue
                if not raw and len(r) >= 3 and not re.search(r"\d", r[2]) and not re.search(r"\.bam$", r[0].strip(), re.I):
                    continue                                                          # header (bam  patient  date …)
                if len(r) < 3 or not r[0].strip() or not r[1].strip() or not re.search(r"\d", r[2]):
                    fail(f"Line {i} of {a.samples} cannot be used: “{chr(9).join(r)[:80]}”",
                         "each row needs the BAM path, the patient and a date, separated by tabs.",
                         "fill in the missing value, or delete the row (or start it with #) if that BAM should not be analysed")
                raw.append((Path(r[0].strip()).expanduser(), safe(r[1]), r[2], r[3].strip() if len(r) > 3 else ""))
        ds = parse_dates([r[2] for r in raw], a.samples)
        rows = [(b, p, d, fr) for (b, p, _, fr), d in zip(raw, ds)]
    else:
        if not a.bams or not a.dates:
            fail("You have not told me which BAMs to use or their dates", "--bams folder/ and --dates dates.tsv are required (or else --samples table.tsv).",
                    "see the beginning of `srasel run -h`")
        files = []
        for b in a.bams:
            b = Path(b).expanduser()
            if not b.exists():       # [input check 2026-11-18] a mistyped --bams path used to be reported as "1 BAM without a date"
                fail(f"--bams: “{b}” does not exist", "it is neither a folder with BAM files nor a .bam file.",
                     "check the path (a folder with the BAM files, or the .bam files themselves)")
            files += sorted(b.rglob("*.bam")) if b.is_dir() else [b]
        by_name = {}
        for fp in files:
            by_name.setdefault(stem_of(fp.name), []).append(fp)
        dup = {k: v for k, v in by_name.items() if len(v) > 1}
        if dup:
            k, v = next(iter(dup.items()))
            fail(f"There are several BAMs named “{k}”: {v[0]} and {v[1]}", "the BAM name is the key that links each BAM to its date.",
                    "rename them so they are unique, or use --samples with the full path of each one")
        lower = {k.lower(): k for k in by_name}
        drows = read_dates_file(a.dates)
        ds = parse_dates([r[1] for r in drows], a.dates)
        used = set()
        for r, d in zip(drows, ds):
            k = stem_of(r[0])
            k = k if k in by_name else lower.get(k.lower())
            if k is None:
                warn(f"{a.dates}: “{r[0]}” does not match any BAM in the folder (ignored).")
                continue
            used.add(k)
            if len(r) >= 3 and r[2]:
                pat = safe(r[2])
            else:
                m = re.match(r"^(.*)-(\d+)([a-z]?)$", k)
                pat = safe(m.group(1)) if m else (safe(a.patient) if a.patient else None)
            if pat is None:
                fail(f"Cannot tell which patient “{k}” belongs to", "its name is not <patient>-<n> and there is no third column with the patient.",
                        "name the BAMs <patient>-<n> (P1-1, P1-2…), add the patient as a third column of the dates file, or, if all are from the "
                        "same patient, use --patient NAME")
            rows.append((by_name[k][0], pat, d, ""))
        sin = sorted(set(by_name) - used)
        if sin:
            fail(f"{len(sin)} BAM without a date in {a.dates}: {', '.join(sin[:6])}{'…' if len(sin) > 6 else ''}",
                    "each BAM needs its date; the BAM name (without .bam) must be identical in the folder and in the dates file.",
                    "add those rows, or remove the BAMs you do not want to analyze from the folder")
    if not rows:
        fail("No samples", "the table is empty or the folder has no .bam files.", "check --samples / --bams")
    # [validation 2026-11-10, N1] the same BAM file in two rows would be analysed as two time points (identical reads, invented date)
    seen_bam = {}
    for bam, pat, d, fr in rows:
        key = str(bam.resolve()) if bam.exists() else str(bam)
        if key in seen_bam:
            fail(f"The same BAM appears twice: {bam} ({seen_bam[key]} and {pat} {d})",
                 "one BAM file is one sample; listing it twice would turn the same reads into two time points.",
                 "keep one row per BAM (same-day replicates must be different BAM files)")
        seen_bam[key] = f"{pat} {d}"
    out, per = [], defaultdict(list)
    for bam, pat, d, fr in rows:
        if not bam.exists():
            fail(f"The BAM {bam} does not exist", "the path in the table does not point to a file.", "fix it (use absolute paths)")
        per[pat].append((d, bam, fr))
    if any(fr for l in per.values() for _, _, fr in l):
        if not all(fr for l in per.values() for _, _, fr in l):
            fail("You mix BAMs with a fragment and BAMs without one", "if the “fragment” column exists, all rows must have it.", "fill in or remove the 4th column")
        for pat, l in sorted(per.items()):                  # one SAMPLE = several BAMs (one per fragment) of the same patient and date
            days = sorted({d for d, _, _ in l})
            if len(days) < 3:
                warn(f"{pat}: only {len(days)} distinct date(s); SRASel needs ≥3 to fit a slope.")
            for n, d in enumerate(days, 1):
                fb = {}
                for dd, b, fr in l:
                    if dd == d:
                        if fr in fb:
                            fail(f"Fragment {fr} of {pat} appears twice at date {d}", "a sample has one BAM per fragment.", "remove the duplicate")
                        fb[fr] = b
                out.append(dict(sid=f"{pat}-{n}", bam=next(iter(fb.values())), patient=pat, date=d, frags=fb))
        return out
    for pat, l in sorted(per.items()):
        days = sorted({d for d, _, _ in l})
        if len(days) < 3:
            warn(f"{pat}: only {len(days)} distinct date(s); SRASel needs ≥3 to fit a slope.")
        for n, d in enumerate(days, 1):
            same = sorted(b for dd, b, _ in l if dd == d)
            for j, b in enumerate(same):
                sid = f"{pat}-{n}{chr(97 + j) if len(same) > 1 else ''}"
                out.append(dict(sid=sid, bam=b, patient=pat, date=d))
    return out


# ───────────────────────── header and indexes of the BAMs ─────────────────────────
def bam_header(bam, log):
    r = run(["samtools", "view", "-H", bam], log)
    sq, so = [], ""
    for ln in r.stdout.splitlines():
        f = ln.split("\t")
        if f[0] == "@SQ":
            d = dict(x.split(":", 1) for x in f[1:] if ":" in x)
            sq.append(dict(name=d.get("SN"), length=int(d.get("LN", 0)), m5=d.get("M5")))
        elif f[0] == "@HD":
            so = dict(x.split(":", 1) for x in f[1:] if ":" in x).get("SO", "")
    return sq, so


def _htslib_read_error(stderr):
    """First htslib error line ([E::…], e.g. truncated or corrupt BGZF block) in a tool's stderr, or ''."""
    return next((ln.strip() for ln in (stderr or "").splitlines() if ln.startswith("[E::") or "truncated file" in ln), "")


def _link_and_index(bam, dst, threads, log, sid):
    """Link + index of ONE BAM in work/bams; if it is not coordinate-sorted, a copy is sorted. Returns the header (@SQ)."""
    # [validation 2026-11-10] a truncated BAM that already had a .bai went through with a partial count and exit 0
    qc = subprocess.run(["samtools", "quickcheck", "-v", str(bam)], capture_output=True, text=True)
    if qc.returncode:
        fail(f"{sid}: the BAM {bam} is damaged or truncated", "`samtools quickcheck` rejects it (missing end-of-file block or bad header).",
             "re-create or re-download that BAM")
    sq, so = bam_header(bam, log)
    if dst.exists() or dst.is_symlink():
        dst.unlink()
    if so == "coordinate":
        dst.symlink_to(Path(bam).resolve())
        idx = next((Path(str(bam) + e) for e in (".bai", ".csi") if Path(str(bam) + e).exists()), None)
        if idx is None and Path(str(bam)[:-4] + ".bai").exists():
            idx = Path(str(bam)[:-4] + ".bai")
        if idx is not None:
            shutil.copy(idx, str(dst) + idx.suffix)
        else:
            run(["samtools", "index", "-@", threads, dst], log)
    else:
        warn(f"{sid}: the BAM is not coordinate-sorted (SO:{so or 'no data'}); a copy is sorted.")
        run(["samtools", "sort", "-@", threads, "-o", dst, bam], log)
        run(["samtools", "index", "-@", threads, dst], log)
    return sq


def prepare_bams(samples, work, threads, log):
    """Links + index in work/bams (does not touch your folder). If the BAM is not coordinate-sorted, it is sorted.
    A sample with `frags` (one BAM per fragment) links each fragment as <sample>_<fragment>.bam."""
    d = work / "bams"; d.mkdir(parents=True, exist_ok=True)
    for s in samples:
        if s.get("frags"):
            s["frag_bams"], s["frag_sq"] = {}, {}
            for f, bam in s["frags"].items():
                dst = d / f"{s['sid']}_{f}.bam"
                s["frag_sq"][f] = _link_and_index(bam, dst, threads, log, f"{s['sid']} {f}")
                s["frag_bams"][f] = dst
            s["sq"] = next(iter(s["frag_sq"].values()))
            s["work_bam"] = next(iter(s["frag_bams"].values()))
        else:
            s["sq"] = _link_and_index(s["bam"], d / f"{s['sid']}.bam", threads, log, s["sid"])
            s["work_bam"] = d / f"{s['sid']}.bam"
    return d


# ───────────────────────── samples split into fragments (e.g., HIVEVO: one BAM per fragment F1…F6) ─────────────────────────
def read_fragments(path=None, gbs=()):
    """Fragments {nombre: (inicio, fin)} (name: (start, end)) in reference coordinates (1-based, both inclusive): from a TSV table
    (fragment, start, end) or from the `fragment` features (note = name) of a GenBank."""
    frag = {}
    if path:
        for n, ln in enumerate(Path(path).read_text(encoding="utf-8-sig").splitlines()):
            f = [x.strip() for x in ln.split("\t")]
            if len(f) < 3 or ln.startswith("#") or not f[1].isdigit():
                continue
            frag[f[0]] = (int(f[1]), int(f[2]))
    for g in gbs:
        for rec in SeqIO.parse(str(g), "genbank"):
            for ft in rec.features:
                if ft.type == "fragment" and ft.qualifiers.get("note"):
                    frag.setdefault(ft.qualifiers["note"][0], (int(ft.location.start) + 1, int(ft.location.end)))
    return frag


def check_fragments(samples, ref, frags, work, log):
    """Each fragment BAM must have a contig with the LENGTH of the fragment and plausible differences from that stretch of the reference."""
    seqs = fasta_seqs(ref / "reference.fna")
    if len(seqs) != 1:
        fail("Samples split into fragments need a reference with a SINGLE contig", f"the reference has {len(seqs)}: {list(seqs)[:5]}.",
             "use the full consensus of the patient as a single sequence")
    seq = next(iter(seqs.values()))
    names = {f for s in samples for f in s["frag_bams"]}
    miss = sorted(names - set(frags))
    if miss:
        fail(f"Fragments without positions: {', '.join(miss)}", f"known: {sorted(frags)}.",
             "pass them with --fragments table.tsv (fragment, start, end) or use a GenBank with “fragment” features (note = name)")
    rep, errs = {}, []
    for f in sorted(names):
        a, b = frags[f]
        if not 1 <= a <= b <= len(seq):
            fail(f"Fragment {f} ({a}-{b}) is outside the reference (length {len(seq)})", "the positions do not fit in the sequence.", "fix --fragments")
    for s in samples:
        sid_err, reads = 0.0, 0
        for f, bam in s["frag_bams"].items():
            a, b = frags[f]
            sq = s["frag_sq"][f]
            idx = run(["samtools", "idxstats", bam], log).stdout
            per = {l.split("\t")[0]: (int(l.split("\t")[1]), int(l.split("\t")[2])) for l in idx.splitlines() if l and not l.startswith("*")}
            name = max(per, key=lambda k: per[k][1])
            if per[name][0] != b - a + 1:
                fail(f"{s['sid']} {f}: contig {name} is {per[name][0]} bp but fragment {f} is {b - a + 1} bp ({a}-{b})",
                     "this BAM is not aligned to that stretch of the consensus: the counts would fall at wrong positions.",
                     "use the exact consensus they were aligned to or fix --fragments")
            fa = work / "frag_fa" / f"{s['sid']}_{f}.fa"; fa.parent.mkdir(parents=True, exist_ok=True)
            fa.write_text(f">{name}\n{seq[a - 1:b]}\n")
            head = subprocess.Popen(["samtools", "view", "-h", "-F", "0x904", str(bam)], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
            txt = "".join(itertools.islice(head.stdout, 200000)); head.stdout.close(); head.wait()
            st = subprocess.run(["samtools", "stats", "-r", str(fa), "-"], input=txt, capture_output=True, text=True).stdout
            d = {l.split("\t")[1].rstrip(":"): float(l.split("\t")[2]) for l in st.splitlines() if l.startswith("SN\t")}
            e = d.get("mismatches", 0) / d["bases mapped (cigar)"] if d.get("bases mapped (cigar)") else 1.0
            if e > ERR_FAIL:
                fail(f"{s['sid']} {f}: {e:.1%} of the bases differ from the fragment", "too many for an infection: wrong reference.", "check the consensus")
            sid_err, reads = max(sid_err, e), reads + per[name][1]
        rep[s["sid"]] = dict(err=sid_err, per={"consenso": reads}, mapped=reads)
        errs.append(sid_err)
    ok(f"{len(names)} fragment(s) ({', '.join(sorted(names))}): each BAM has the same length as its stretch of the consensus.")
    (warn if max(errs) > ERR_WARN else ok)(f"Read–consensus differences: from {min(errs):.2%} to {max(errs):.2%}.")
    return rep


def count_fragmented(s, seq, contig, frags, work, out_path):
    """bam-readcount of each fragment with its stretch of consensus; positions converted to consensus coordinates; overlaps are SUMMED."""
    depth, refb, counts = defaultdict(int), {}, defaultdict(lambda: defaultdict(int))
    chk = bad = 0
    for f, bam in s["frag_bams"].items():
        a, b = frags[f]
        idx = subprocess.run(["samtools", "idxstats", str(bam)], capture_output=True, text=True).stdout.splitlines()
        name = max((l.split("\t") for l in idx if not l.startswith("*")), key=lambda x: int(x[2]))[0]
        fa = work / "frag_fa" / f"{s['sid']}_{f}.fa"; fa.parent.mkdir(parents=True, exist_ok=True)
        fa.write_text(f">{name}\n{seq[a - 1:b]}\n")
        r = subprocess.run(["bam-readcount", "-q", "20", "-b", "20", "-w", "0", "-f", str(fa), str(bam)], capture_output=True, text=True)
        if r.returncode:
            fail(f"bam-readcount failed on {Path(str(bam)).name}", r.stderr[-300:], "check that the BAM is sorted and indexed")
        if _htslib_read_error(r.stderr):        # [validation 2026-11-10] partial table on a corrupt BAM
            fail(f"The BAM {Path(str(bam)).name} could not be read to the end", f"bam-readcount reported: {_htslib_read_error(r.stderr)[:200]}",
                 "re-create or re-download it (check it with `samtools quickcheck -v`)")
        for ln in r.stdout.splitlines():
            x = ln.split("\t")
            g = int(x[1]) + a - 1
            chk += 1; bad += x[2].upper() != seq[g - 1]
            refb[g] = seq[g - 1]; depth[g] += int(x[3])
            for tok in x[4:]:
                k, _, rest = tok.partition(":")
                k = refb[g] if k == "=" else k
                counts[g][k] += int(rest.split(":")[0])
    with open(out_path, "w") as fo:
        for g in sorted(depth):
            fo.write("\t".join([contig, str(g), refb[g], str(depth[g])] + [f"{k}:{n}:0:0:0:0:0:0:0:0:0:0" for k, n in counts[g].items() if n]) + "\n")
    return len(depth), chk, bad


# ───────────────────────── NCBI: search for and choose a reference ─────────────────────────
def _get(url):
    for k in range(5):
        try:
            return urllib.request.urlopen(url, timeout=60).read().decode()
        except Exception:
            time.sleep(2 * (k + 1))
    fail("Could not reach NCBI", "no internet or NCBI is busy.",
            "check the connection, or pass your own reference with --ref-file / --ref from a GenBank you already have")


def ncbi_summary(term, email, retmax=60):
    q = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
    pre = f"&tool=srasel&email={urllib.parse.quote(email)}" if email else "&tool=srasel"
    ids = json.loads(_get(q + f"esearch.fcgi?db=nuccore&retmode=json&retmax={retmax}&term=" + urllib.parse.quote(term) + pre))["esearchresult"]["idlist"]
    if not ids:
        return []
    time.sleep(0.4)
    d = json.loads(_get(q + "esummary.fcgi?db=nuccore&retmode=json&id=" + ",".join(ids) + pre))["result"]
    return [dict(acc=d[i]["accessionversion"], length=int(d[i]["slen"]), title=d[i]["title"], organism=d[i].get("organism", "")) for i in ids]


def find_by_virus(name, sq, email, interactive, yes):
    """RefSeq groups (one group = one genome, with all its segments) → the one that matches the contigs of the BAMs."""
    say(f"  Searching NCBI for the RefSeq references of “{name}”…")
    cand = ncbi_summary(f'"{name}"[Organism] AND srcdb_refseq[PROP]', email) or \
        ncbi_summary(f'{name}[All Fields] AND srcdb_refseq[PROP]', email)
    if not cand:
        fail(f"NCBI returns no RefSeq reference for “{name}”", "the name does not match any organism.",
                "try another name (e.g., “Severe acute respiratory syndrome coronavirus 2”, “Norovirus GII”, “Influenza A virus”) "
                "or pass --ref with the accession")
    groups = defaultdict(list)
    for c in cand:
        groups[c["organism"] or c["title"]].append(c)
    bam_len = sorted(x["length"] for x in sq)

    def score(g):
        gl = sorted(x["length"] for x in g)
        if gl == bam_len:
            return 3
        if len(bam_len) == 1 and bam_len[0] in gl:
            return 2
        return 1 if set(bam_len) <= set(gl) else 0
    ranked = sorted(groups.items(), key=lambda kv: (-score(kv[1]), -len(kv[1])))
    best = [kv for kv in ranked if score(kv[1]) == score(ranked[0][1])]
    if score(ranked[0][1]) >= 2 and len(best) == 1:
        org, g = best[0]
        ok(f"{org}: {len(g)} contig(s) with the same length as your BAMs → {', '.join(x['acc'] for x in g)}")
        return [x["acc"] for x in g]
    say(("  The RefSeq reference of that virus does not match" if len(ranked) == 1 else
         "  There are several possible references and none matches") +
        f" exactly the length of your contigs ({', '.join(str(x) for x in bam_len)} bp):")
    for i, (org, g) in enumerate(ranked[:8], 1):
        say(f"    {i}. {org} · {len(g)} contig(s) · {', '.join(str(x['length']) for x in g)} bp · {', '.join(x['acc'] for x in g)}")
    near = [(org, g) for org, g in ranked if len(g) == len(bam_len) and
            all(abs(x - y) <= max(8, 0.01 * y) for x, y in zip(sorted(z["length"] for z in g), bam_len))]
    if near:
        org, g = near[0]
        say(f"  → “{org}” almost matches (lengths within ±1 %): your BAMs seem aligned to another strain of the same virus. If you have its FASTA:\n"
            f"      --consensus your.fasta --consensus-source {' '.join(x['acc'] for x in g)}")
    if interactive and not yes:
        try:
            k = int(input("  Which one is it? (number, 0 = none): ").strip())
        except ValueError:
            k = 0
        if 1 <= k <= len(ranked[:8]):
            return [x["acc"] for x in ranked[k - 1][1]]
    fail("Cannot decide the reference without guessing", "the contigs of your BAMs do not have the same length as any RefSeq reference of the virus.",
            "tell me which one it is with --ref ACCESSION (the one you used to align), or with --consensus if you aligned to your own consensus")


def accessions_from_header(sq, email):
    """If the contig names of the BAMs are NCBI accessions with the same length, that is the reference."""
    accs = []
    for x in sq:
        if not re.match(r"^[A-Z]{1,2}_?\d{5,8}(\.\d+)?$", x["name"] or ""):
            return None
        hit = ncbi_summary(f"{x['name']}[Accession]", email, 5)
        hit = [h for h in hit if h["acc"].split(".")[0] == x["name"].split(".")[0] and h["length"] == x["length"]]
        if not hit:
            return None
        accs.append(hit[0]["acc"])
    return accs


# ───────────────────────── prepare the reference ─────────────────────────
def pick_source_for_consensus(cons, name, email, work, log):
    """RefSeq of the virus most similar to the consensus (minimap2: aligned bases)."""
    cand = ncbi_summary(f'"{name}"[Organism] AND srcdb_refseq[PROP]', email) if name else []
    if not cand:
        fail("Cannot tell which reference to transfer the genes from onto your consensus", "--consensus-source ACCESSION is missing and there is no --virus.",
                "give --consensus-source (RefSeq or annotated GenBank of the same virus/genotype) or --virus “name”")
    best, best_n = None, -1
    for c in cand[:12]:
        fa = work / f"_cand_{c['acc']}.fa"
        fa.write_text(_get("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&rettype=fasta&retmode=text&id=" + c["acc"]))
        time.sleep(0.4)
        r = run(["minimap2", "-x", "asm20", "-c", fa, cons], log)
        n = sum(int(ln.split("\t")[9]) for ln in r.stdout.splitlines() if ln.count("\t") >= 9)
        if n > best_n:
            best, best_n = c, n
        fa.unlink()
    ok(f"Annotated reference most similar to your consensus: {best['acc']} ({best['title'][:70]}) · {best_n} aligned bases")
    return best["acc"]


# ───────────────────────── Reference from FASTA + gene list (GFF3 or table) ─────────────────────────
MAKE_GENBANK_DOC = r"""srasel make-genbank · converts your FASTA and a gene LIST into an annotated GenBank (for --ref-file / prepare-reference)

When you do not have a GenBank of the reference or of the consensus, pass the sequence (FASTA) and where each gene/protein is:

    srasel make-genbank --fasta my_consensus.fa --genes genes.tsv -o my_reference.gb
    srasel prepare-reference --refs my_reference.gb --outdir reference

--genes is a tab-separated TABLE with a header, or a GFF3 (.gff/.gff3). Table columns:

    contig  gene  start  end  strand   [type]  [product]  [codon_start]  [transl_table]

  contig        name of the sequence in the FASTA (the SAME one used by your BAMs)
  gene          name of the gene/protein (ORF1, VP1, HA…)
  start, end    1-based positions, both inclusive, in contig coordinates (start < end always)
  strand        + or -   (also 1/-1, plus/minus, fwd/rev)
  type          CDS (default) or mat_peptide (mature peptide, with coordinates in nt)
  codon_start   1, 2 or 3: where the first codon starts (default 1)   ·   transl_table: NCBI genetic code (default 1)

A gene with INTRONS or several stretches (e.g., M2 of influenza) is written in SEVERAL rows with the same contig+gene+type: they are joined in the
reading order (on the - strand they are read from higher to lower position). In a GFF3, stretches with the same ID form one gene and the column
“phase” gives the codon_start. A warning is issued if a gene does not have a length that is a multiple of 3 or has an internal stop codon (nothing is corrected)."""
_STRANDS = {"+": 1, "plus": 1, "1": 1, "+1": 1, "fwd": 1, "forward": 1, "-": -1, "minus": -1, "-1": -1, "rev": -1, "reverse": -1}


def _strand_of(x, where):
    k = str(x).strip().lower()
    if k not in _STRANDS:
        fail(f"Cannot parse the strand “{x}” ({where})", "accepted values: + - 1 -1 plus minus fwd rev.", "fix it in the gene list")
    return _STRANDS[k]


def read_gene_list(path: Path) -> list:
    """Gene stretches from a TSV table or a GFF3 → [dict(contig,key,gene,type,start,end,strand,product,codon_start,transl_table)]."""
    text = Path(path).read_text(encoding="utf-8-sig")
    rows = []
    if Path(path).suffix.lower() in (".gff", ".gff3") or text.lstrip().startswith("##gff"):
        for n, ln in enumerate(text.splitlines(), 1):
            if not ln.strip() or ln.startswith("#"):
                continue
            f = ln.split("\t")
            if len(f) < 9:
                fail(f"Line {n} of {Path(path).name} does not have the 9 columns of a GFF3", "the file does not look like a valid GFF3.", "check the format or use the gene table")
            contig, _, typ, a, b, _, st, phase, attrs = f[:9]
            if typ not in ("CDS", "mat_peptide"):
                continue
            at = dict(x.split("=", 1) for x in attrs.split(";") if "=" in x)
            ident = at.get("ID") or at.get("Parent") or ""
            gene = at.get("gene") or at.get("Name") or re.sub(r"^cds-", "", ident) or f"{contig}_{a}"
            rows.append(dict(contig=contig, key=ident or gene, gene=gene, type=typ, start=int(a), end=int(b), strand=_strand_of(st, f"line {n}"),
                             product=at.get("product") or at.get("Name") or gene, codon_start=int(phase) + 1 if phase in ("0", "1", "2") else 1,
                             transl_table=int(at.get("transl_table", 1))))
    else:
        lines = [l for l in text.splitlines() if l.strip() and not l.lstrip().startswith("#")]
        if not lines:
            fail(f"{Path(path).name} is empty", "there is no gene row.", "add the header and the genes")
        head = [h.strip().lower() for h in lines[0].split("\t")]
        alias = {"chrom": "contig", "seqid": "contig", "name": "gene", "from": "start", "to": "end", "stop": "end"}
        head = [alias.get(h, h) for h in head]
        miss = [c for c in ("contig", "gene", "start", "end", "strand") if c not in head]
        if miss:
            fail(f"The gene list is missing columns: {', '.join(miss)}", f"header found: {head}.",
                 "use the header: contig, gene, start, end, strand (and optional type, product, codon_start, transl_table), separated by tabs")
        for n, ln in enumerate(lines[1:], 2):
            d = dict(zip(head, [x.strip() for x in ln.split("\t")]))
            try:
                typ = d.get("type") or "CDS"
                rows.append(dict(contig=d["contig"], key=d["gene"] + "|" + typ, gene=d["gene"], type=typ, start=int(d["start"]), end=int(d["end"]),
                                 strand=_strand_of(d["strand"], f"row {n}"), product=d.get("product") or d["gene"],
                                 codon_start=int(d.get("codon_start") or 1), transl_table=int(d.get("transl_table") or 1)))
            except (KeyError, ValueError):
                fail(f"Cannot parse row {n} of {Path(path).name}: “{ln[:60]}”", "start, end, codon_start and transl_table must be numbers.", "fix it")
    return rows


def genes_to_genbank(fasta: Path, genes: Path, out_gb: Path) -> list:
    """FASTA + gene list → annotated GenBank. Returns the list of warnings (corrects nothing)."""
    recs = {r.id: r for r in SeqIO.parse(str(fasta), "fasta")}
    if not recs:
        fail(f"{Path(fasta).name} contains no sequences", "it is not a valid FASTA.", "check the file")
    rows, warns = read_gene_list(genes), []
    groups = collections.OrderedDict()
    for r in rows:
        if r["contig"] not in recs:
            fail(f"The contig “{r['contig']}” of the gene list is not in the FASTA", f"the FASTA has: {list(recs)[:6]}.",
                 "use the same names in the list as in the FASTA (and as in your BAMs)")
        if not 1 <= r["start"] <= r["end"] <= len(recs[r["contig"]].seq):
            fail(f"Positions outside the contig in “{r['gene']}”: {r['start']}-{r['end']} (the contig length is {len(recs[r['contig']].seq)})",
                 "start must be ≤ end and lie within the sequence.", "fix the list (1-based positions, both inclusive)")
        groups.setdefault((r["contig"], r["type"], r["key"]), []).append(r)
    for rec in recs.values():
        rec.seq = Seq(str(rec.seq).upper())
        rec.name = rec.id[:16]
        rec.description = f"{rec.id} (annotation from a gene list)"
        rec.annotations["molecule_type"] = "RNA"
        rec.features = []
    for (contig, typ, _), parts in groups.items():
        st = parts[0]["strand"]
        parts = sorted(parts, key=lambda x: x["start"], reverse=(st == -1))          # reading order
        loc = [FeatureLocation(x["start"] - 1, x["end"], strand=st) for x in parts]
        ft = SeqFeature(loc[0] if len(loc) == 1 else CompoundLocation(loc), type=typ)
        ft.qualifiers = {"gene": [parts[0]["gene"]], "product": [parts[0]["product"]]}
        if typ == "CDS":
            ft.qualifiers["codon_start"] = [str(parts[0]["codon_start"])]
            ft.qualifiers["transl_table"] = [str(parts[0]["transl_table"])]
            seq = ft.location.extract(recs[contig].seq)[parts[0]["codon_start"] - 1:]
            prot = str(seq[:len(seq) // 3 * 3].translate(table=parts[0]["transl_table"]))
            if len(seq) % 3:
                warns.append(f"{parts[0]['gene']}: the length ({len(seq)} nt) is not a multiple of 3")
            if "*" in prot[:-1]:
                warns.append(f"{parts[0]['gene']}: has an internal stop codon (aa {prot.index('*') + 1}); check positions, strand or codon_start")
        recs[contig].features.append(ft)
    for rec in recs.values():
        rec.features.sort(key=lambda f: int(f.location.start))
    SeqIO.write(list(recs.values()), str(out_gb), "genbank")
    return warns


def main_make_genbank():
    ap = argparse.ArgumentParser(description=MAKE_GENBANK_DOC, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--fasta", required=True, type=Path, help="FASTA of the reference or of the consensus")
    ap.add_argument("--genes", required=True, type=Path, help="gene list (TSV table or GFF3)")
    ap.add_argument("-o", "--out", required=True, type=Path, help="GenBank to be written")
    a = ap.parse_args()
    warns = genes_to_genbank(a.fasta, a.genes, a.out)
    n = sum(1 for r in SeqIO.parse(str(a.out), "genbank") for f in r.features if f.type == "CDS")
    print(f"✔  {a.out}  ({n} CDS)")
    for w in warns:
        print(f"  ⚠ {w}")


def build_reference(a, sq, email, work, out, log, interactive):
    ref = out / "reference"
    py = sys.executable
    kind = ""
    if a.ref_file:
        run([py, SELF, "prepare-reference", "--refs", *a.ref_file, "--outdir", ref], log)
        kind = "own GenBank (" + ", ".join(Path(x).name for x in a.ref_file) + ")"
    elif a.fasta or a.genes:
        if not (a.fasta and a.genes):
            fail("To annotate from a list, both --fasta and --genes are needed", "you gave only one of the two.",
                 "pass the sequence (--fasta) and the gene list or GFF3 (--genes), or a GenBank with --ref-file")
        gb = out / "reference_input.gb"
        run([py, SELF, "make-genbank", "--fasta", a.fasta, "--genes", a.genes, "-o", gb], log)
        run([py, SELF, "prepare-reference", "--refs", gb, "--outdir", ref], log)
        kind = f"FASTA {Path(a.fasta).name} + gene list {Path(a.genes).name}"
    elif a.consensus:
        src = a.consensus_source or [pick_source_for_consensus(a.consensus, a.virus, email, work, log)]
        tr = out / "reference_transfer"
        run([py, SELF, "transfer-annotation", "--query", a.consensus, "--source", *src, "--outdir", tr,
             "--email", email or "", "--cache-dir", out / "gb_cache"], log)
        run([py, SELF, "prepare-reference", "--refs", tr / "annotated.gb", "--outdir", ref], log)
        for f in ("coord_map.tsv", "aa_map.tsv", "transfer_report.tsv"):
            shutil.copy(tr / f, ref / f)
        kind = f"own consensus {Path(a.consensus).name} with the annotation transferred from {' '.join(src)}"
    else:
        if a.ref:
            accs = [x for x in re.split(r"[,\s]+", a.ref) if x]
        elif a.virus:
            accs = find_by_virus(a.virus, sq, email, interactive, a.yes)
        else:
            accs = accessions_from_header(sq, email)
            if not accs:
                fail("Cannot tell which the reference is", "you gave none of --ref, --ref-file, --consensus or --virus, and the contig names "
                        f"of the BAMs ({', '.join(x['name'] for x in sq[:4])}…) are not NCBI accessions with the expected length.",
                        "pass --virus “virus name” (I look it up) or --ref ACCESSION")
            ok(f"The header of your BAMs already states the reference: {', '.join(accs)}")
        run([py, SELF, "prepare-reference", "--refs", *accs, "--email", email or "", "--outdir", ref,
             "--cache-dir", out / "gb_cache"], log)
        kind = "NCBI " + ", ".join(accs)
    return ref, kind


# ───────────────────────── check that the BAMs fall where they should ─────────────────────────
def fasta_seqs(path):
    seqs, name = {}, None
    for ln in open(path):
        if ln.startswith(">"):
            name = ln[1:].split()[0]; seqs[name] = []
        elif name:
            seqs[name].append(ln.strip())
    return {k: "".join(v).upper() for k, v in seqs.items()}


def match_contigs(sq, contigs, alias):
    """BAM contig → reference contig (exact name / alias / without version). Otherwise, by length 1↔1."""
    res = {}
    for x in sq:
        c = resolve_contig(x["name"], contigs, alias)
        res[x["name"]] = c
    if any(v is None for v in res.values()):
        lens = Counter(c["length"] for c in contigs)
        for x in sq:
            if res[x["name"]] is None:
                cand = [c for c in contigs if c["length"] == x["length"]]
                if len(cand) == 1 and lens[x["length"]] == 1 and Counter(y["length"] for y in sq)[x["length"]] == 1:
                    res[x["name"]] = cand[0]
    return res


def check_bams(samples, ref, work, threads, log, alias):
    """Returns (alias to use, report per sample). Stops with a clear message if something does not fit."""
    contigs = read_contigs(ref / "contigs.tsv")
    seqs = fasta_seqs(ref / "reference.fna")
    md5 = {k: hashlib.md5(v.encode()).hexdigest() for k, v in seqs.items()}
    sq0 = samples[0]["sq"]
    m = match_contigs(sq0, contigs, alias)
    bad = [k for k, v in m.items() if v is None]
    if bad:
        fail(f"The contigs of your BAMs are not in the reference: {', '.join(bad[:5])}",
                f"the reference has {[(c['contig'], c['length']) for c in contigs]} and your BAMs {[(x['name'], x['length']) for x in sq0]}.",
                "align (or realign) to that reference, or pass the correct one with --ref/--ref-file/--consensus; if only the name "
                "of the contig differs, use --alias NAME_IN_BAM=NAME_IN_REFERENCE")
    new_alias = dict(alias)
    for x in sq0:
        c = m[x["name"]]
        if x["length"] != c["length"]:
            fail(f"Contig {x['name']} is {x['length']} bp in your BAMs but {c['length']} bp in the reference {c['contig']}",
                    "it is not the same sequence: the positions would not match and the selected sites would be shifted.",
                    "use the reference you aligned to (--ref / --ref-file) or your consensus (--consensus)")
        if x["m5"] and x["m5"].lower() != md5[c["contig"]]:
            fail(f"The md5 of {x['name']} in your BAMs (M5) does not match the reference {c['contig']}",
                    "same length but different sequence (another strain or version).",
                    "use the exact sequence you aligned to; if it was your own consensus, pass it with --consensus")
        if x["name"] != c["contig"]:
            new_alias[x["name"]] = c["contig"]
            warn(f"The contig is called “{x['name']}” in the BAMs and “{c['contig']}” in the reference; same length: they are paired.")
    for s in samples[1:]:
        if [(x["name"], x["length"]) for x in s["sq"]] != [(x["name"], x["length"]) for x in sq0]:
            fail(f"{s['sid']} has different contigs from the rest", "all BAMs of an analysis must be aligned to the same reference.",
                    "realign the different BAMs or split them into another analysis")
    ok("The contigs of the BAMs match the reference (name and length" + (", md5" if sq0[0]["m5"] else "") + ").")

    # FASTA with the BAM names, in case they differ (bam-readcount matches them by name)
    fa = ref / "reference.fna"
    if new_alias != alias or any(x["name"] != m[x["name"]]["contig"] for x in sq0):
        fa = work / "reference.bamnames.fna"
        with open(fa, "w") as fo:
            for x in sq0:
                fo.write(f">{x['name']}\n{seqs[m[x['name']]['contig']]}\n")
    rep = {}
    nreads = 2 * 10 ** 5
    for s in samples:
        view = subprocess.Popen(["samtools", "view", "-h", "-F", "0x904", str(s["work_bam"])], stdout=subprocess.PIPE,
                                stderr=subprocess.DEVNULL, text=True)
        head = "".join(itertools.islice(view.stdout, nreads))             # the first nreads lines (header included), like `head -n`
        view.stdout.close(); view.wait()
        log.write(f"$ samtools view -h -F 0x904 {s['work_bam']} | head -n {nreads} | samtools stats -r {fa} -\n")
        st = subprocess.run(["samtools", "stats", "-r", str(fa), "-"], input=head, capture_output=True, text=True).stdout
        d = {}
        for ln in st.splitlines():
            if ln.startswith("SN\t"):
                k, v = ln.split("\t")[1:3]; d[k.rstrip(":")] = float(v)
        mapped, mism = d.get("bases mapped (cigar)", 0), d.get("mismatches", 0)
        err = mism / mapped if mapped else 1.0
        idx = run(["samtools", "idxstats", s["work_bam"]], log).stdout
        per = {l.split("\t")[0]: int(l.split("\t")[2]) for l in idx.splitlines() if l and not l.startswith("*")}
        rep[s["sid"]] = dict(err=err, mapped=int(d.get("reads mapped", 0)), per=per)
        if mapped == 0 or sum(per.values()) < MIN_READS_CONTIG:
            fail(f"{s['sid']}: almost no aligned reads ({sum(per.values())})", "empty BAM or aligned to something else.",
                    "check the BAM (samtools flagstat) and that it is from this virus")
        if err > ERR_FAIL:
            fail(f"{s['sid']}: {err:.1%} of the aligned bases differ from the reference",
                    "this is much more than normal in an infection (<3 %); it is usually a reference of another genotype/strain, another numbering "
                    "or a BAM aligned to another sequence.", "check the reference (--virus looks for the closest one; --consensus if you aligned to a consensus)")
    errs = [r["err"] for r in rep.values()]
    msg = f"Read–reference differences: from {min(errs):.2%} to {max(errs):.2%} (median {sorted(errs)[len(errs) // 2]:.2%})."
    (warn if max(errs) > ERR_WARN else ok)(msg + (" Somewhat high: is the reference of the same genotype?" if max(errs) > ERR_WARN else ""))
    tot = Counter()
    for r in rep.values():
        tot.update(r["per"])
    for x in sq0:
        n = tot[x["name"]]
        (ok if n >= MIN_READS_CONTIG * len(samples) else warn)(f"{x['name']} ({x['length']} bp): {n:,} reads in total")
    return new_alias, fa, rep


# ───────────────────────── resume (--resume): completion markers ─────────────────────────
# A stage counts as finished only if its marker exists, written AFTER it ended correctly and carrying the fingerprint of its inputs
# and parameters. An interruption (Ctrl-C, kill, failure) leaves no marker, so the stage is redone whole; a half-written output is never reused.
def _fingerprint(*parts) -> str:
    return hashlib.sha256(json.dumps(parts, sort_keys=True, default=str).encode()).hexdigest()


def _versions_id():
    """Fingerprint of the program: this file + samtools and bam-readcount versions. If it changes, what was reused can no longer be trusted."""
    v = [hashlib.sha256(Path(__file__).read_bytes()).hexdigest()]
    for tool in ("samtools", "bam-readcount"):
        try:
            r = subprocess.run([tool, "--version"], capture_output=True, text=True, timeout=30)
            v.append((r.stdout + r.stderr).strip()[:300])
        except (OSError, subprocess.SubprocessError):
            v.append("")
    return v


def _file_id(p):
    st = os.stat(p)                                   # follows symlinks: the real BAM is looked at
    return [str(Path(p).resolve()), st.st_size, st.st_mtime_ns]


def _content_id(*paths):
    """Fingerprint of the CONTENT (the reference is regenerated on every run, so its modification time is useless)."""
    return [hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths if Path(p).exists()]


def stage_reusable(a, marker, fp, outputs=()):
    return bool(getattr(a, "resume", False)) and marker.exists() and marker.read_text().strip() == fp \
        and all(Path(x).exists() for x in outputs)


def stage_done(marker, fp):
    marker.parent.mkdir(parents=True, exist_ok=True)
    tmp = marker.with_name(marker.name + ".tmp")
    tmp.write_text(fp + "\n")
    os.replace(tmp, marker)


# ───────────────────────── pipeline (steps 2–7) ─────────────────────────
def pipeline(a, samples, ref, fa, alias, out, log):
    py, jobs = sys.executable, a.threads
    pr, work = out / "processing", out / "work"
    a_frags = getattr(a, "frags_map", None)
    (pr / "02_rc").mkdir(parents=True, exist_ok=True)
    with open(out / "dates.tsv", "w") as fo:
        for s in samples:
            fo.write(f"{s['sid']}\t{format_dmy(s['date'])}\n")       # [validation 2026-11-10, N14] 4-digit year when 2 digits would be ambiguous
    say("\nStep 2 · per-position count (bam-readcount -q20 -b20 -w0)")

    marks = pr / ".resume"
    versions = _versions_id()

    def rc(s):
        o = pr / "02_rc" / f"{s['sid']}_RG_readcount.txt"
        t = time.time()
        mk = marks / f"rc_{s['sid']}.ok"
        s["rc_fp"] = _fingerprint("rc", versions, [_file_id(b) for b in (s.get("frag_bams") or {"": s["work_bam"]}).values()], _content_id(fa),
                                  a_frags if s.get("frag_bams") else None)
        if stage_reusable(a, mk, s["rc_fp"], [o]):
            return f"{s['sid']}: count reused (--resume)"
        mk.unlink(missing_ok=True)
        if s.get("frag_bams"):
            seqs = fasta_seqs(ref / "reference.fna"); contig = next(iter(seqs))
            n, chk, bad = count_fragmented(s, seqs[contig], contig, a_frags, work, o)
            stage_done(mk, s["rc_fp"])
            return f"{s['sid']}: {n} positions from {len(s['frag_bams'])} fragment(s) ({time.time() - t:.0f} s)"
        with open(o, "w") as fo:
            r = subprocess.run(["bam-readcount", "-q", "20", "-b", "20", "-w", "0", "-f", str(fa), str(s["work_bam"])], stdout=fo,
                               stderr=subprocess.PIPE, text=True)
        if r.returncode:
            fail(f"bam-readcount failed on {s['sid']}", r.stderr[-300:], "check that the BAM is sorted and indexed")
        if _htslib_read_error(r.stderr):        # [validation 2026-11-10] bam-readcount exits 0 with a PARTIAL table on a corrupt BAM
            o.unlink(missing_ok=True)
            fail(f"The BAM of {s['sid']} could not be read to the end", f"bam-readcount reported: {_htslib_read_error(r.stderr)[:200]}",
                 f"re-create or re-download {s['bam']} (check it with `samtools quickcheck -v`)")
        n = sum(1 for _ in open(o))
        stage_done(mk, s["rc_fp"])
        return f"{s['sid']}: {n} positions ({time.time() - t:.0f} s)"
    with ThreadPoolExecutor(max(1, jobs)) as ex:
        for msg in ex.map(rc, samples):
            ok(msg)
    al = [x for k, v in alias.items() for x in ("--alias", f"{k}={v}")]
    say("\nSteps 3-5 · integrity, position×time matrices and annotation")
    mk35 = marks / "stages_3_5.ok"
    fp35 = _fingerprint("3-5", versions, [s["rc_fp"] for s in samples], (out / "dates.tsv").read_text(), _content_id(ref / "contigs.tsv", ref / "reference.fna", ref / "cds_model.tsv", ref / "features.tsv"), alias)
    if stage_reusable(a, mk35, fp35, [pr / "05_annotated_tables"]) and list((pr / "05_annotated_tables").glob("*_genes.tsv")):
        ok("integrity, matrices and annotation reused (--resume)")
    else:
        mk35.unlink(missing_ok=True)
        run([py, SELF, "integrity", "--ref-dir", ref], log, cwd=out)
        (pr / "04_position_time_matrices").mkdir(exist_ok=True); (pr / "05_annotated_tables").mkdir(exist_ok=True)
        (pr / "06_selection_analysis").mkdir(exist_ok=True)
        pats = [d for d in sorted((pr / "03_integrity_checked").iterdir()) if d.is_dir()]
        if not pats:
            fail("No patient passes the integrity check", "see the integrity report in processing/03_integrity_checked.",
                    "look at the log and the dates; ≥97 % depth coverage of the reference and ≥3 dates are needed")
        for d in pats:
            run([py, SELF, "build-tables", d, "--ref-dir", ref, *al], log, cwd=out)
            shutil.move(str(d / f"{d.name}.tsv"), pr / "04_position_time_matrices" / f"{d.name}.tsv")
        run([py, SELF, "annotate", "--tsv-dir", "processing/04_position_time_matrices", "--ref-dir", ref,
             "--out-dir", "processing/05_annotated_tables"], log, cwd=out)
        stage_done(mk35, fp35)
        ok(f"{len(pats)} patient(s) ready to analyze")
    say("\nStep 6 · SRASel (permutations; takes longer with more variants)")
    files = sorted(str(p) for p in (pr / "05_annotated_tables").glob("*_genes.tsv"))
    mk6 = marks / "stage_6.ok"
    fp6 = _fingerprint("6", fp35, a.nperm, a.seed, a.freq_delta, "0.95", "10")        # --threads does not change the result (tested)
    if stage_reusable(a, mk6, fp6, [pr / "06_selection_analysis"]) and list((pr / "06_selection_analysis").glob("*_variant_stats.tsv")):
        ok("SRASel analysis reused (--resume)")
    else:
        mk6.unlink(missing_ok=True)
        run([py, SELF, "selection", *files, "--outdir", "processing/06_selection_analysis", "--times", "dates.tsv", "--nperm", a.nperm,
             "--jobs", jobs, "--seed", a.seed, "--freq-delta", a.freq_delta, "--thr-clear", "0.95", "--first-k-min", "10"], log, cwd=out)
        stage_done(mk6, fp6)
    res = {}
    for p in sorted((pr / "06_selection_analysis").glob("*_variant_stats.tsv")):
        rows = list(csv.DictReader(open(p), delimiter="\t"))
        res[p.name.replace("_variant_stats.tsv", "")] = (len(rows), sum(1 for r in rows if r.get("tag")))
    if not res:                                 # [validation 2026-11-10, N6] before, step 7 failed with "selection has not been run"
        fail("No variant passed the analysis filters, so there is nothing to test or report",
             "a variant needs >= 100 reads supporting it on at least one date, to be seen on >= 3 dates, and a fitted frequency change "
             f"|Δf| >= {a.freq_delta}.", "check that each patient has >= 3 dates with good coverage and that the BAMs match the reference "
             "(the checks are in commands.log)")
    if not a.no_report:
        say("\nStep 7 · HTML report")
        run([py, SELF, "report", "--ref-dir", ref, "--processing", pr, "-o", out / "report.html",
             "--freq-delta", a.freq_delta, "--nperm", a.nperm], log)      # without --nperm the report assumed 2000 (p floor, alpha slider)
        ok(f"{out / 'report.html'}")
    return res


def write_summary(out, a, kind, ref, samples, rep, res):
    L = ["# SRASel 2.0 analysis summary", "",
         f"* Reference: **{kind}** → `{ref}`", f"* Samples: {len(samples)} · patients: {len({s['patient'] for s in samples})}",
         f"* Parameters: p<0.05 by permutation ({a.nperm}), |Δf| ≥ {a.freq_delta}, seed {a.seed}", "",
         "## Preliminary checks", "", "| Sample | Differences from the reference | Aligned reads |", "|---|---|---|"]
    for sid, r in rep.items():
        L.append(f"| {sid} | {r['err']:.2%} | {sum(r['per'].values()):,} |")
    L += ["", "## Result per patient", "", "| Patient | Variants with a statistic | Labeled (p<0.05 and |Δf|≥threshold) |", "|---|---|---|"]
    L += [f"| {k} | {n} | {t} |" for k, (n, t) in res.items()]
    # [validation 2026-11-10, N6] patients without statistics were silently absent from the summary
    for p in sorted({s["patient"] for s in samples} - set(res)):
        nd = len({s["date"] for s in samples if s["patient"] == p})
        L.append(f"| {p} | not analysed: {nd} date(s)" + (" (>= 3 needed)" if nd < 3 else ", no variant passed the filters") + " | – |")
    # [owner decision 2026-11-21] the closing caveat sentence was removed (text only; no table, column or number changes)
    L += ["", "The genes/codons come from `reference/REFERENCE_REPORT.txt` and `reference/cds_model.tsv`."]
    (out / "SUMMARY.md").write_text("\n".join(L) + "\n")


def main_run():
    ap = argparse.ArgumentParser(description=SRASEL_RUN_DOC, formatter_class=argparse.RawDescriptionHelpFormatter)
    g = ap.add_argument_group("your data")
    g.add_argument("--samples", help="TSV table: bam, patient, date")
    g.add_argument("--bams", nargs="+", help="folder(s) or .bam files named <patient>-<n>.bam")
    g.add_argument("--dates", help="with --bams: file “BAM name without .bam <TAB> date [<TAB> patient]”; any date format")
    g.add_argument("--patient", help="with --bams: patient name if all BAMs are from the same patient and are not named <patient>-<n>")
    g = ap.add_argument_group("reference")
    g.add_argument("--virus", help="virus name: the RefSeq reference is searched for in NCBI")
    g.add_argument("--ref", help="NCBI accession(s), comma-separated (one per segment)")
    g.add_argument("--ref-file", nargs="+", help="own annotated GenBank(s) (no internet)")
    g.add_argument("--fragments", type=Path, help="if each sample is SEVERAL BAMs (one per fragment, e.g., HIVEVO): table fragment<TAB>start<TAB>end "
                                                  "in consensus coordinates (or a GenBank with “fragment” features); in --samples add the 4th column “fragment”")
    g.add_argument("--fasta", type=Path, help="FASTA of your reference or consensus, when you do NOT have a GenBank (used with --genes)")
    g.add_argument("--genes", type=Path, help="list of genes/proteins with positions and strand (TSV table or GFF3); see `srasel make-genbank -h`")
    g.add_argument("--consensus", help="FASTA of your consensus (the BAMs are aligned to it)")
    g.add_argument("--consensus-source", nargs="+", help="annotated accession(s) from which to transfer the genes to the consensus (one per segment)")
    g.add_argument("--alias", action="append", default=[], metavar="BAM=REF", help="contig name in the BAM = name in the reference")
    g = ap.add_argument_group("execution")
    g.add_argument("--out", default="srasel_out", help="results folder (default srasel_out)")
    g.add_argument("--email", default=os.environ.get("NCBI_EMAIL", ""), help="email for NCBI (or NCBI_EMAIL variable)")
    g.add_argument("--threads", type=int, default=max(1, (os.cpu_count() or 2) // 2), help="cores used (default: half of those available); does not change the results")
    g.add_argument("--nperm", type=int, default=2000, help="permutations of the p-value test (default %(default)s)")
    g.add_argument("--freq-delta", type=float, default=0.03, help="minimum |Δf| (fitted change over the follow-up) for a variant to be tested and labelled (default %(default)s)")
    g.add_argument("--seed", type=int, default=1, help="seed of the permutation test (default 1: the same input always gives the same p-values; change it to see how much they move)")
    g.add_argument("--check-only", action="store_true", help="only check the reference and BAMs, without analyzing")
    g.add_argument("--no-report", action="store_true", help="skip step 7 (the HTML report)")
    g.add_argument("--resume", action="store_true",
                   help="reuse what is already computed in --out: each count and each finished stage with the SAME inputs and parameters is skipped "
                        "(if a BAM, the reference, the dates or --nperm/--seed/--freq-delta change, that stage and the following ones are redone)")
    g.add_argument("--yes", action="store_true", help="do not ask (if in doubt, stop)")
    a = ap.parse_args()
    out = Path(a.out).expanduser().resolve(); work = out / "work"
    # [validation 2026-11-11, E1] --out already holding an analysis, without --resume: the old tables of processing/ would be processed again with the
    # new samples (traceback in build-tables, stale SUMMARY.md / report.html left behind). Stop and say what to do; nothing is deleted.
    prev = out / "processing"
    if prev.is_dir() and any(prev.iterdir()) and not a.resume and not a.check_only:
        fail(f"The output folder {out} already holds an analysis", "mixing the files of two runs gives wrong or failing results.",
             "choose another --out, add --resume to continue that same analysis, or delete the folder (or its processing/ part) if you want to start over")
    work.mkdir(parents=True, exist_ok=True)
    (out / "reference" / "reference.fna.fai").unlink(missing_ok=True)       # [E1] samtools index of an OLD reference.fna is rebuilt when needed; a stale one gave "almost no aligned reads"
    log = open(out / "commands.log", "a")
    interactive = sys.stdin.isatty()
    alias = dict(x.split("=", 1) for x in a.alias)
    need_tools(["samtools", "bam-readcount"] + (["minimap2"] if a.consensus else []))
    say("SRASel 2.0 · analysis from BAM\n\n[1] Samples and BAMs")
    samples = load_samples(a)
    # [validation 2026-11-10, N6] no patient with >= 3 dates: nothing can be tested, so stop now instead of failing at step 7
    ndates = {p: len({s["date"] for s in samples if s["patient"] == p}) for p in {s["patient"] for s in samples}}
    if all(n < 3 for n in ndates.values()):
        fail("No patient has 3 or more different dates", f"the slope test needs >= 3 dates per patient; here: "
             + ", ".join(f"{p} {n}" for p, n in sorted(ndates.items())) + ".",
             "add samples from more dates (5 or more are recommended), or check the dates file")
    prepare_bams(samples, work, a.threads, log)
    ok(f"{len(samples)} BAM(s) from {len({s['patient'] for s in samples})} patient(s); contigs: "
       + ", ".join(f"{x['name']} ({x['length']} bp)" for x in samples[0]["sq"][:8]))
    say("\n[2] Reference")
    if not a.email and not a.ref_file and not a.genes:
        warn("No --email (or NCBI_EMAIL): NCBI asks for it for downloads; if it fails, add it.")
    ref, kind = build_reference(a, samples[0]["sq"], a.email, work, out, log, interactive)
    ok(f"Reference ready: {kind}")
    rpt = (ref / "REFERENCE_REPORT.txt").read_text() if (ref / "REFERENCE_REPORT.txt").exists() else ""
    for ln in rpt.splitlines():
        if "PARTIAL" in ln or "MISMATCH" in ln or "could not be checked" in ln:
            warn(ln.strip()[:150])
    say("\n[3] Do my BAMs fall where they should in this reference?")
    if any(s.get("frag_bams") for s in samples):
        a.frags_map = read_fragments(a.fragments, gbs=[x for x in (a.ref_file or []) if str(x).lower().endswith((".gb", ".gbk", ".gbff"))])
        rep = check_fragments(samples, ref, a.frags_map, work, log)
        alias, fa = {}, ref / "reference.fna"
    else:
        alias, fa, rep = check_bams(samples, ref, work, a.threads, log, alias)
    if a.check_only:
        say("\n--check-only: all in order. Remove that option to analyze."); return
    t0 = time.time()
    res = pipeline(a, samples, ref, fa, alias, out, log)
    write_summary(out, a, kind, ref, samples, rep, res)
    say(f"\nDone in {(time.time() - t0) / 60:.1f} min. Summary: {out / 'SUMMARY.md'}  ·  Report: {out / 'report.html'}")


# ═════════════════════════════════════════════════════════════════════════════════════════════════
# Command-line interface
# ═════════════════════════════════════════════════════════════════════════════════════════════════
COMMANDS = {
    "run": (main_run, "full pipeline from BAM: reference, checks, counting, analysis and report"),
    "prepare-reference": (main_prepare_reference, "step 0: reference from NCBI (FASTA, genes, reading model)"),
    "transfer-annotation": (main_transfer_annotation, "step 0b: transfer the annotation from NCBI to your consensus"),
    "integrity": (main_integrity, "step 3: coverage, dates and sample names"),
    "build-tables": (cli_build_tables, "step 4: position × time matrix of a patient"),
    "annotate": (main_annotate, "step 5: gene, codon and amino acid of each position"),
    "selection": (main_selection, "step 6: SRASel statistical analysis (slopes, permutations, labels)"),
    "report": (main_report, "step 7: interactive HTML report"),
    "make-genbank": (main_make_genbank, "FASTA + gene list (table or GFF3) → annotated GenBank to use as a reference"),
}


def main():
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        print(__doc__)
        print("Subcommands (each accepts -h):")
        for k, (_, d) in COMMANDS.items():
            print(f"  {k:<20} {d}")
        raise SystemExit(0 if len(sys.argv) >= 2 else 2)
    cmd = sys.argv[1]
    if cmd not in COMMANDS:
        print(f"[ERROR] “{cmd}” is not a subcommand. Available: {', '.join(COMMANDS)}", file=sys.stderr)
        raise SystemExit(2)
    sys.argv = [f"srasel {cmd}"] + sys.argv[2:]
    COMMANDS[cmd][0]()


if __name__ == "__main__":
    main()
