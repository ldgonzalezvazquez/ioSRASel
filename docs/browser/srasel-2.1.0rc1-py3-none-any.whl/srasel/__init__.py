"""SRASel: within-host selection in viral time series from aligned BAM files.

The scientific code lives in `srasel.engine` (the consolidated SRASel 2.0 `srasel.py`); this package only adds the
`srasel` command, the local web interface and packaging.
"""
__version__ = "2.1.0rc1"
